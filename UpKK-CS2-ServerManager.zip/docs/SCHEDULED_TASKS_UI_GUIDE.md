# Scheduled Tasks UI - Visual Guide

## Location
The Scheduled Tasks interface is accessible from the server detail page as a new tab.

## Tab Navigation
```
[Overview] [Configuration] [Actions] [Monitoring] [Console & Logs] [File Manager] [🕐 Scheduled Tasks]
```

## UI Layout

### When No Tasks Exist
```
┌─────────────────────────────────────────────────────────────────┐
│ 🕐 Scheduled Tasks                              [+ Add Task]    │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│                         📅                                       │
│                                                                  │
│              No scheduled tasks configured                       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### With Tasks Configured
```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ 🕐 Scheduled Tasks                                                           [+ Add Task]        │
├─────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                  │
│ Task Name    Action    Schedule           Next Run              Last Run         Status  ⚙️     │
│ ──────────────────────────────────────────────────────────────────────────────────────────────  │
│ Daily        RESTART   Daily: 03:00       Nov 24, 3:00 AM       Nov 23, 3:00 AM  ✓      [✓] ✏️🗑️ │
│ Restart                                                          5 runs                          │
│                                                                                                  │
│ Weekly       UPDATE    Weekly: SUN:04:00  Nov 26, 4:00 AM       Nov 19, 4:00 AM  ✓      [✓] ✏️🗑️ │
│ Update                                                           2 runs                          │
│                                                                                                  │
│ Hourly       VALIDATE  Interval: 3600     Nov 23, 5:00 PM       Nov 23, 4:00 PM  ✗      [✓] ✏️🗑️ │
│ Check                                                            120 runs                        │
│                                                                  Error: Connection failed        │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

## Create/Edit Task Modal
```
┌────────────────────────────────────────────────┐
│  Create Scheduled Task                    ✕    │
├────────────────────────────────────────────────┤
│                                                 │
│  Task Name                                      │
│  ┌──────────────────────────────────────────┐ │
│  │ Daily Server Restart                     │ │
│  └──────────────────────────────────────────┘ │
│                                                 │
│  Action                                         │
│  ┌──────────────────────────────────────────┐ │
│  │ Restart Server                       ▼  │ │
│  └──────────────────────────────────────────┘ │
│                                                 │
│  Schedule Type                                  │
│  ┌──────────────────────────────────────────┐ │
│  │ Daily                                ▼  │ │
│  └──────────────────────────────────────────┘ │
│                                                 │
│  Schedule Value                                 │
│  ┌──────────────────────────────────────────┐ │
│  │ 14:30                                    │ │
│  └──────────────────────────────────────────┘ │
│  Format: HH:MM (e.g., 14:30)                   │
│                                                 │
│  ☑ Enabled                                     │
│                                                 │
├────────────────────────────────────────────────┤
│                      [Cancel]  [Save]          │
└────────────────────────────────────────────────┘
```

## Features Demonstrated

### 1. Task List
- **Name**: Descriptive task name
- **Action Badge**: Color-coded action type (Restart, Start, Stop, Update, Validate)
- **Schedule**: Shows type and value clearly
- **Next/Last Run**: Formatted date/time with run count badge
- **Status**: Visual indicators (✓ Success, ✗ Failed, ⚠ Running)
- **Error Display**: Shows error messages when tasks fail
- **Toggle Switch**: Enable/disable tasks without deleting
- **Actions**: Edit (pencil) and Delete (trash) buttons

### 2. Empty State
- Helpful icon and message
- Encourages users to create their first task
- Clear call-to-action

### 3. Modal Form
- All fields clearly labeled
- Dynamic placeholders based on schedule type
- Help text showing format examples
- Validation feedback
- Loading state during save

### 4. User Experience
- **Real-time Updates**: No page refresh needed
- **Instant Feedback**: Success/error messages
- **Confirmation Dialogs**: For destructive actions
- **Loading States**: Visual feedback during API calls
- **Responsive Design**: Works on all screen sizes
- **Localized**: Full English and Chinese support

## Keyboard Shortcuts
- **Enter**: Save modal (when in input field)
- **Escape**: Close modal
- **Tab**: Navigate between form fields

## Color Coding
- **Green** (Success): Task executed successfully
- **Red** (Failed): Task execution failed
- **Yellow** (Running): Task is currently executing
- **Blue** (Info): Run count badges
- **Gray** (Secondary): Action type badges
