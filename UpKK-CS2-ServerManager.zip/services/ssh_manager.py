"""
SSH connection and server management utilities (Async)
"""
import asyncssh
import asyncio
import contextlib
import ipaddress
import inspect
import os
import posixpath
import re
import shlex
import logging
import socket
import tempfile
import uuid
import shutil
import anyio
from email.message import Message
from email.utils import collapse_rfc2231_value
from typing import AsyncIterator, Awaitable, Callable, Optional, Tuple, List, Dict, Any
from datetime import datetime
from urllib.parse import unquote, urljoin, urlsplit
from modules.models import Server
from services.game_session import (
    availability_command,
    cleanup_command,
    find_running_session_managers,
    force_stop_session_command,
    normalize_session_manager,
    session_name,
    start_session_command,
    stop_session_command,
)
from services.server_monitor import server_monitor
from services.ssh_connection_pool import ssh_connection_pool

logger = logging.getLogger(__name__)
_status_update_tasks: set[asyncio.Task] = set()


def _schedule_status_update(server_id: int, success: bool) -> None:
    task = asyncio.create_task(update_ssh_connection_status(server_id, success))
    _status_update_tasks.add(task)
    task.add_done_callback(_status_update_tasks.discard)


async def shutdown_background_tasks() -> None:
    """Await pending SSH status writes before the database engine is disposed."""
    tasks = list(_status_update_tasks)
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    _status_update_tasks.clear()


async def _cleanup_local_download_dir(download_dir: str, panel_temp_dir: str) -> None:
    """Delete a potentially large local download tree without blocking the event loop."""
    def cleanup() -> tuple[bool, bool]:
        if not os.path.exists(download_dir):
            return False, False
        shutil.rmtree(download_dir)
        parent_removed = False
        try:
            if os.path.exists(panel_temp_dir) and not os.listdir(panel_temp_dir):
                os.rmdir(panel_temp_dir)
                parent_removed = True
        except OSError:
            pass
        return True, parent_removed

    try:
        download_removed, parent_removed = await anyio.to_thread.run_sync(cleanup)
        if download_removed:
            logger.info("Cleaned up panel temp directory: %s", download_dir)
        if parent_removed:
            logger.info("Cleaned up empty parent directory: %s", panel_temp_dir)
    except Exception as exc:
        logger.warning("Failed to clean up panel temp directory %s: %s", download_dir, exc)


async def update_ssh_connection_status(server_id: int, success: bool):
    """
    Update SSH connection status tracking in database
    
    This is a fire-and-forget background task that should never block SSH operations.
    All exceptions are caught and logged to prevent blocking the caller.
    
    Args:
        server_id: Server ID
        success: Whether the SSH connection was successful
    """
    from modules.database import async_session_maker
    from modules.utils import get_current_time
    from sqlalchemy import update as sql_update
    from modules.models import Server as ServerModel
    
    try:
        # Use a short timeout to prevent blocking
        async with asyncio.timeout(5):
            async with async_session_maker() as db:
                server = await db.get(ServerModel, server_id)
                if not server:
                    logger.warning(f"Cannot update SSH status: server {server_id} not found")
                    return
                
                now = get_current_time()
                
                if success:
                    # Reset failure tracking on successful connection
                    await db.execute(
                        sql_update(ServerModel)
                        .where(ServerModel.id == server_id)
                        .values(
                            last_ssh_success=now,
                            consecutive_ssh_failures=0,
                            is_ssh_down=False
                        )
                    )
                    logger.debug(f"SSH connection successful for server {server_id} - reset failure tracking")
                else:
                    # Increment failure count
                    new_failure_count = server.consecutive_ssh_failures + 1
                    
                    # Mark as down after 3 consecutive failures (immediate, not days-based)
                    # This prevents repeated connection attempts to offline servers
                    is_down = new_failure_count >= 3
                    
                    await db.execute(
                        sql_update(ServerModel)
                        .where(ServerModel.id == server_id)
                        .values(
                            last_ssh_failure=now,
                            consecutive_ssh_failures=new_failure_count,
                            is_ssh_down=is_down
                        )
                    )
                    if is_down:
                        logger.warning(f"Server {server_id} marked as SSH down after {new_failure_count} consecutive failures")
                
                await db.commit()
    except asyncio.TimeoutError:
        logger.warning(f"Timeout updating SSH status for server {server_id} - database may be busy")
    except Exception as e:
        logger.error(f"Failed to update SSH connection status for server {server_id}: {e}")


class SSHManager:
    """Async SSH manager for remote server operations with connection pooling"""
    
    # Constants for file validation
    MIN_EXPECTED_FILE_SIZE = 1000  # Minimum file size in bytes (1KB) for downloaded packages
    
    # Upload chunk size for SFTP transfers (32KB)
    UPLOAD_CHUNK_SIZE = 32768

    # Download chunk size for streamed browser downloads (256KB)
    DOWNLOAD_CHUNK_SIZE = 262144

    # File-manager archive safety limits. Listing is capped before extraction so
    # a malformed archive cannot produce unbounded command output in the panel.
    ARCHIVE_MAX_ENTRIES = 20000
    ARCHIVE_MAX_FOLDERS = 20000
    ARCHIVE_MAX_MEMBER_PATH_BYTES = 1024
    # TAR inspection streams one C-quoted verbose listing instead of collecting
    # complete command results in memory. Keep the timeout aligned with
    # extraction because listing a compressed TAR must still decompress the
    # entire input, even when the archive contains only a handful of members.
    ARCHIVE_INSPECT_TIMEOUT = 3600
    ARCHIVE_EXTRACT_TIMEOUT = 3600
    ARCHIVE_LISTING_READ_BYTES = 64 * 1024
    ARCHIVE_LISTING_MAX_LINE_BYTES = (ARCHIVE_MAX_MEMBER_PATH_BYTES * 4) + 4096
    ARCHIVE_LISTING_ERROR_BYTES = 8192
    ARCHIVE_LISTING_STOP_TIMEOUT = 5
    REMOTE_DOWNLOAD_TIMEOUT = 1800
    REMOTE_DOWNLOAD_MAX_BYTES = 20 * 1024 * 1024 * 1024
    REMOTE_DOWNLOAD_METADATA_MAX_BYTES = 256 * 1024
    REMOTE_DOWNLOAD_FILENAME_MAX_BYTES = 255
    REMOTE_DOWNLOAD_URL_MAX_LENGTH = 4096
    REMOTE_DOWNLOAD_MAX_REDIRECTS = 10
    REMOTE_DOWNLOAD_REDIRECT_CODES = frozenset((301, 302, 303, 307, 308))
    
    # SteamCMD retry configuration
    STEAMCMD_MAX_RETRIES = 5  # Maximum number of retry attempts (not counting the initial attempt)
    STEAMCMD_RETRY_DELAY = 5  # Initial delay in seconds between retries (will use exponential backoff)
    CS2_EXECUTABLE_RELATIVE_PATH = "cs2/game/bin/linuxsteamrt64/cs2"
    
    # Metamod:Source CS2 dev builds live on the sourcemm dev page and GitHub prereleases.
    METAMOD_DOWNLOADS_URL = "https://www.sourcemm.net/downloads.php?branch=dev"
    METAMOD_GITHUB_RELEASES_API = "https://api.github.com/repos/alliedmodders/metamod-source/releases?per_page=50"
    METAMOD_LINUX_DOWNLOAD_PATTERN = (
        r"https://github\.com/alliedmodders/metamod-source/releases/download/"
        r"2\.0\.0\.[0-9]+/mmsource-2\.0\.0-git[0-9]+-linux\.tar\.gz"
    )
    
    # SteamCMD retryable error patterns
    # These error keywords indicate temporary issues that are worth retrying
    STEAMCMD_RETRYABLE_ERRORS = [
        "timeout",
        "timed out", 
        "connection",
        "network",
        "failed to download",
        "download failed",
        "corrupt",
        "error downloading",
        "unable to download",
        "http error",
        "failed to install",
        "no connection"
    ]
    
    def __init__(self, use_pool: bool = True):
        """
        Initialize SSH Manager
        
        Args:
            use_pool: Whether to use connection pooling (default: True)
        """
        self.conn: Optional[asyncssh.SSHClientConnection] = None
        self.use_pool = use_pool
        self.current_server: Optional[Server] = None
        self.last_plugin_backup: Optional[Dict[str, Any]] = None

    @staticmethod
    def archive_type_from_path(path: str) -> Optional[str]:
        """Return a normalized archive type from a local or remote filename."""
        lower_path = path.lower()
        for suffix, archive_type in (
            ('.tar.gz', 'tar.gz'),
            ('.tar.bz2', 'tar.bz2'),
            ('.tar.xz', 'tar.xz'),
            ('.tgz', 'tar.gz'),
            ('.tbz2', 'tar.bz2'),
            ('.txz', 'tar.xz'),
            ('.zip', 'zip'),
            ('.7z', '7z'),
            ('.tar', 'tar'),
            ('.gz', 'gz'),
            ('.bz2', 'bz2'),
        ):
            if lower_path.endswith(suffix):
                return archive_type
        return None

    @staticmethod
    def _filename_from_content_disposition(value: str) -> Optional[str]:
        """Decode a Content-Disposition filename, preferring RFC 5987 filename*."""
        if not value:
            return None
        message = Message()
        try:
            message["Content-Disposition"] = value
            params = message.get_params(
                header="content-disposition",
                unquote=True,
            ) or []
        except (TypeError, ValueError):
            return None

        regular_names: List[str] = []
        extended_names: List[str] = []
        for key, raw_value in params[1:]:
            if key.lower() != "filename" or raw_value is None:
                continue
            if isinstance(raw_value, tuple):
                try:
                    decoded = collapse_rfc2231_value(raw_value, errors="strict")
                except (LookupError, UnicodeError, TypeError, ValueError):
                    continue
                extended_names.append(decoded)
            elif isinstance(raw_value, str):
                regular_names.append(raw_value)

        candidates = extended_names or regular_names
        return candidates[0] if candidates else None

    @classmethod
    def _validate_download_filename(cls, filename: str) -> Tuple[Optional[str], str]:
        """Return a safe direct-child archive filename or a public error."""
        if not isinstance(filename, str):
            return None, "Download response did not provide a valid filename"
        filename = filename.strip()
        if (
            not filename
            or filename in ('.', '..')
            or '/' in filename
            or '\\' in filename
            or posixpath.basename(filename) != filename
            or any(ord(char) < 32 or ord(char) == 127 for char in filename)
        ):
            return None, "Download response filename is unsafe"
        if len(filename.encode('utf-8')) > cls.REMOTE_DOWNLOAD_FILENAME_MAX_BYTES:
            return None, "Download response filename is too long"
        if cls.archive_type_from_path(filename) is None:
            return None, "Download response filename does not use a supported archive extension"
        return filename, ""

    @classmethod
    def _filename_from_download_response(
        cls,
        raw_headers: str,
        effective_url: str,
    ) -> Tuple[Optional[str], str]:
        """Resolve a safe filename from the final headers, then effective URL."""
        normalized_headers = raw_headers.replace('\r\n', '\n').replace('\r', '\n')
        content_disposition = None
        for block in reversed(re.split(r'\n\s*\n', normalized_headers)):
            lines = block.splitlines()
            if not lines or not lines[0].lstrip().upper().startswith('HTTP/'):
                continue

            unfolded: List[str] = []
            for line in lines[1:]:
                if line[:1] in (' ', '\t') and unfolded:
                    unfolded[-1] += ' ' + line.strip()
                else:
                    unfolded.append(line)
            for line in unfolded:
                name, separator, value = line.partition(':')
                if separator and name.strip().lower() == 'content-disposition':
                    content_disposition = value.strip()
            break

        candidates: List[str] = []
        if content_disposition:
            header_filename = cls._filename_from_content_disposition(content_disposition)
            if header_filename:
                candidates.append(header_filename)

        try:
            raw_url_filename = posixpath.basename(urlsplit(effective_url.strip()).path)
            if raw_url_filename:
                candidates.append(unquote(raw_url_filename))
        except ValueError:
            pass

        last_error = "Download response did not provide an archive filename"
        for candidate in candidates:
            filename, error = cls._validate_download_filename(candidate)
            if filename is not None:
                return filename, ""
            last_error = error
        return None, last_error

    @classmethod
    def _validate_remote_download_url(cls, url: str) -> Tuple[Optional[Any], str]:
        """Validate one URL hop before it is resolved on the SSH host."""
        if (
            not isinstance(url, str)
            or not url
            or len(url) > cls.REMOTE_DOWNLOAD_URL_MAX_LENGTH
        ):
            return None, "Download URL is missing or too long"
        if any(ord(char) < 32 or ord(char) == 127 for char in url):
            return None, "Download URL contains control characters"

        try:
            parsed = urlsplit(url)
            port = parsed.port
        except (TypeError, ValueError):
            return None, "Download URL is malformed"

        if parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
            return None, "Only absolute HTTP and HTTPS download URLs are supported"
        if parsed.username is not None or parsed.password is not None:
            return None, "Download URLs containing credentials are not supported"
        if parsed.fragment:
            return None, "Download URL fragments are not supported"
        if port is not None and not 1 <= port <= 65535:
            return None, "Download URL port is outside the valid range"

        hostname = parsed.hostname.rstrip('.').lower()
        if not hostname or '%' in hostname:
            return None, "Download URL hostname is invalid"

        try:
            literal_address = ipaddress.ip_address(hostname)
        except ValueError:
            literal_address = None
            try:
                socket.inet_aton(hostname)
            except OSError:
                pass
            else:
                return None, "Non-canonical numeric IPv4 download URLs are not allowed"

            # Keep getent and curl's interpretation of the authority identical.
            # IDNA hostnames can be supplied in their canonical ASCII form.
            if len(hostname) > 253:
                return None, "Download URL hostname is invalid"
            labels = hostname.split('.')
            if any(
                not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label)
                for label in labels
            ):
                return None, "Download URL hostname is invalid"
        else:
            mapped_address = getattr(literal_address, 'ipv4_mapped', None)
            if (
                not literal_address.is_global
                or (mapped_address is not None and not mapped_address.is_global)
            ):
                return None, "Non-public IP address download URLs are not allowed"

        return parsed, ""

    async def _resolve_public_download_address(
        self,
        hostname: str,
        getent_tool: str,
    ) -> Tuple[Optional[str], str]:
        """Resolve a host remotely and choose one address after validating all."""
        literal_hostname = hostname.rstrip('.').lower()
        try:
            literal_address = ipaddress.ip_address(literal_hostname)
        except ValueError:
            literal_address = None

        if literal_address is not None:
            mapped_address = getattr(literal_address, 'ipv4_mapped', None)
            if (
                not literal_address.is_global
                or (mapped_address is not None and not mapped_address.is_global)
            ):
                return None, "Download URL resolves to a non-public IP address"
            return literal_address.compressed, ""

        success, stdout, _ = await self.execute_command(
            f"LC_ALL=C {shlex.quote(getent_tool)} ahosts {shlex.quote(hostname)} 2>/dev/null",
            timeout=15,
        )
        addresses = []
        for line in stdout.splitlines():
            fields = line.split()
            if not fields:
                continue
            try:
                address = ipaddress.ip_address(fields[0])
            except ValueError:
                continue
            mapped_address = getattr(address, 'ipv4_mapped', None)
            if (
                not address.is_global
                or (mapped_address is not None and not mapped_address.is_global)
            ):
                return None, "Download URL resolves to a non-public IP address"
            if '%' in fields[0]:
                return None, "Download URL resolves to an unsupported scoped IP address"
            if address not in addresses:
                addresses.append(address)

        if not success or not addresses:
            return None, "Download host could not be resolved from the managed server"

        # Prefer IPv4 when both families are returned.  getent applies the SSH
        # host's address-family policy, and this avoids choosing an unusable
        # IPv6 route while curl remains pinned to the validated result.
        selected_address = min(addresses, key=lambda item: item.version != 4)
        return selected_address.compressed, ""

    @staticmethod
    def _curl_resolve_entry(hostname: str, port: int, address: str) -> str:
        """Build curl's host:port:address pin, including IPv6 brackets."""
        resolve_host = f'[{hostname}]' if ':' in hostname else hostname
        resolve_address = f'[{address}]' if ':' in address else address
        return f'{resolve_host}:{port}:{resolve_address}'

    @staticmethod
    def _download_response_metadata(
        raw_headers: str,
    ) -> Tuple[Optional[int], Dict[str, str], str]:
        """Return the last HTTP response status and unfolded headers."""
        normalized_headers = raw_headers.replace('\r\n', '\n').replace('\r', '\n')
        for block in reversed(re.split(r'\n\s*\n', normalized_headers)):
            lines = block.splitlines()
            if not lines:
                continue
            status_match = re.match(r'^\s*HTTP/\S+\s+([0-9]{3})(?:\s|$)', lines[0], re.I)
            if status_match is None:
                continue

            unfolded: List[str] = []
            for line in lines[1:]:
                if line[:1] in (' ', '\t') and unfolded:
                    unfolded[-1] += ' ' + line.strip()
                else:
                    unfolded.append(line)
            headers: Dict[str, str] = {}
            for line in unfolded:
                name, separator, value = line.partition(':')
                if separator:
                    headers[name.strip().lower()] = value.strip()
            return int(status_match.group(1)), headers, ""
        return None, {}, "Download response did not include valid HTTP headers"

    @classmethod
    def _redirect_url_from_response(
        cls,
        raw_headers: str,
        current_url: str,
    ) -> Tuple[Optional[str], bool, str]:
        """Resolve and validate a redirect Location from one curl response."""
        status_code, headers, metadata_error = cls._download_response_metadata(raw_headers)
        if status_code is None:
            return None, False, metadata_error
        if status_code in cls.REMOTE_DOWNLOAD_REDIRECT_CODES:
            location = headers.get('location')
            if not location:
                return None, True, "Download redirect did not include a Location header"
            if any(ord(char) < 32 or ord(char) == 127 for char in location):
                return None, True, "Download redirect Location is invalid"
            try:
                redirect_url = urljoin(current_url, location.strip(' '))
            except (TypeError, ValueError):
                return None, True, "Download redirect Location is invalid"
            _, validation_error = cls._validate_remote_download_url(redirect_url)
            if validation_error:
                return None, True, f"Download redirect target is not allowed: {validation_error}"
            return redirect_url, True, ""
        if 300 <= status_code < 400:
            return None, False, f"Download returned unsupported redirect status HTTP {status_code}"
        if not 200 <= status_code < 300:
            return None, False, f"Download failed with HTTP status {status_code}"
        return None, False, ""

    @staticmethod
    def _redact_download_error(message: str) -> str:
        """Remove complete HTTP(S) URLs, including signed query strings."""
        return re.sub(
            r'(?i)https?://[^\s<>"\']+',
            '[redacted URL]',
            message or "Remote command failed",
        )
    
    async def _handle_sftp_error_with_reconnect(self, error: Exception, server: Server, operation_name: str, retry_func):
        """
        Handle SFTP errors with automatic reconnection and retry
        
        Args:
            error: The exception that occurred
            server: Server instance
            operation_name: Name of the operation for logging
            retry_func: Async function to retry after reconnection
        
        Returns:
            Result from retry_func if successful, or raises the error
        """
        error_msg = str(error)
        # Check if this is a connection error that might be fixed by reconnection
        if any(keyword in error_msg.lower() for keyword in ['open failed', 'connection', 'broken pipe', 'reset']):
            logger.warning(f"[SSH Manager] SFTP error detected in {operation_name}, attempting reconnection: {error_msg}")
            # Try to reconnect - use server parameter for consistency
            if self.use_pool:
                success, conn, reconnect_msg = await ssh_connection_pool.reconnect(server)
                if success:
                    self.conn = conn
                    logger.info(f"[SSH Manager] Reconnection successful, retrying {operation_name}")
                    # Retry the operation once after reconnection
                    try:
                        return await retry_func()
                    except Exception as retry_e:
                        logger.error(f"[SSH Manager] Retry {operation_name} after reconnection failed: {str(retry_e)}")
                        raise Exception(f"操作失败（重连后重试仍失败）| Operation failed after reconnection: {str(retry_e)}")
                else:
                    logger.error(f"[SSH Manager] Reconnection failed: {reconnect_msg}")
                    raise Exception(f"连接失败 | Connection failed: {reconnect_msg}")
        raise error
    
    @staticmethod
    def _apply_github_download_proxy(download_url: str, github_proxy: Optional[str]) -> str:
        """Apply a configured GitHub download proxy to release asset URLs."""
        if not github_proxy or not github_proxy.strip():
            return download_url
        
        if not download_url.startswith("https://github.com/"):
            return download_url
        
        proxy_base = github_proxy.strip().rstrip("/")
        github_prefix = "https://github.com"
        if proxy_base.endswith(github_prefix):
            return f"{proxy_base}{download_url[len(github_prefix):]}"
        
        return f"{proxy_base}/{download_url}"
    
    async def _fetch_latest_metamod_url(self, progress_callback=None) -> Tuple[bool, str]:
        """
        Fetch the latest Metamod:Source 2.0 Linux dev build URL.
        
        GitHub marks stable 1.12 releases as latest, so this intentionally
        reads the sourcemm dev page first and falls back to the GitHub releases
        list filtered to 2.0.0 dev assets.
        """
        async def send_progress(message: str):
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        pattern = self.METAMOD_LINUX_DOWNLOAD_PATTERN
        downloads_url = shlex.quote(self.METAMOD_DOWNLOADS_URL)
        releases_api = shlex.quote(self.METAMOD_GITHUB_RELEASES_API)
        
        sourcemm_cmd = (
            f"page=$(curl -fsSL {downloads_url} 2>/dev/null); "
            f"latest=$(printf '%s' \"$page\" | grep -Eo '{pattern}' | sort -V | tail -n 1); "
            "if [ -n \"$latest\" ]; then printf '%s\\n' \"$latest\"; exit 0; fi; "
            "build=$(printf '%s' \"$page\" | sed -n 's/.*Latest downloads for version 2\\.0 - build \\([0-9][0-9]*\\).*/\\1/p' | head -n 1); "
            "if [ -n \"$build\" ]; then "
            "printf 'https://github.com/alliedmodders/metamod-source/releases/download/2.0.0.%s/mmsource-2.0.0-git%s-linux.tar.gz\\n' \"$build\" \"$build\"; "
            "exit 0; fi; "
            "exit 1"
        )
        
        github_cmd = (
            f"latest=$(curl -fsSL {releases_api} 2>/dev/null | grep -Eo '{pattern}' | sort -V | tail -n 1); "
            "if [ -n \"$latest\" ]; then printf '%s\\n' \"$latest\"; exit 0; fi; "
            "exit 1"
        )
        
        for source_name, command in (
            ("sourcemm dev downloads page", sourcemm_cmd),
            ("GitHub releases API", github_cmd),
        ):
            success, url, _ = await self.execute_command(command, timeout=30)
            metamod_url = url.strip().splitlines()[-1].strip() if url.strip() else ""
            
            if success and metamod_url and re.fullmatch(pattern, metamod_url):
                await send_progress(f"Found latest Metamod dev build from {source_name}: {metamod_url}")
                return True, metamod_url
        
        return False, (
            "Failed to determine the latest Metamod:Source 2.0 dev build. "
            "Please check access to sourcemm.net and api.github.com."
        )
    
    async def _fetch_github_release_url(self, repo: str, pattern: str, progress_callback=None, github_proxy: Optional[str] = None) -> Tuple[bool, str]:
        """
        Helper function to fetch the latest release URL from GitHub
        
        Args:
            repo: Repository in format "owner/repo" (e.g., "Source2ZE/CS2Fixes")
                  Supports alphanumeric, hyphens, underscores, and periods
            pattern: Grep pattern to match the browser_download_url (basic grep pattern, not regex)
                    Example: '\"browser_download_url\": \"[^\"]*CS2Fixes-[^\"]*-linux\\.tar\\.gz\"'
                    NOTE: This pattern is used in shell command - ensure it comes from trusted source
            progress_callback: Optional callback for progress messages
            github_proxy: Optional GitHub proxy URL (e.g., https://ghfast.top/https://github.com)
        
        Returns:
            Tuple[bool, str]: (success, download_url or error_message)
        """
        async def send_progress(message: str):
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        # Validate repo parameter to prevent command injection
        # Repository should only contain alphanumeric, hyphens, underscores, periods, and one slash
        # Supports names like "jquery/jquery.ui"
        if not re.match(r'^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+$', repo):
            return False, f"Invalid repository format: {repo}. Expected format: owner/repo"
        
        # Note: pattern parameter is used in shell command and should be from trusted source only
        # In this codebase, it's called with hardcoded patterns from install_cs2fixes method
        
        # GitHub API URL - DO NOT use proxy for API requests
        # Proxy services like ghfast.top only work for file downloads, not API
        api_url = f"https://api.github.com/repos/{repo}/releases/latest"
        # Note: github_proxy parameter exists but is NOT used for API requests
        # because proxy services don't support GitHub API endpoints
        
        # Primary method: Use grep pattern
        # Use basic grep without -P flag for better portability
        get_url_cmd = f"curl -sL {api_url} | grep -o '{pattern}' | grep -o 'https://[^\"]*' | head -1"
        success, url, stderr = await self.execute_command(get_url_cmd, timeout=30)
        
        if success and url.strip():
            return True, url.strip()
        
        # Fallback 1: Try to find any download URL from browser_download_url
        # This is a broader search when specific pattern fails
        await send_progress("⚠ Trying alternative API query...")
        alt_cmd = f"curl -sL {api_url} | grep '\"browser_download_url\"' | grep -o 'https://[^\"]*' | head -1"
        success, url, _ = await self.execute_command(alt_cmd, timeout=30)
        
        if success and url.strip():
            # Verify the URL is a valid GitHub release URL
            # Must start with https://github.com/owner/repo/releases/download/
            url_stripped = url.strip()
            expected_prefix = f"https://github.com/{repo}/releases/download/"
            if url_stripped.startswith(expected_prefix):
                return True, url_stripped
        
        # Fallback 2: Get tag with proper semantic version matching
        await send_progress("⚠ Could not fetch from GitHub API, trying tag-based approach...")
        # Match semantic versioning: v1.2.3 or v1.2 format
        tag_cmd = f"curl -sL {api_url} | grep '\"tag_name\"' | grep -o 'v[0-9]\\+\\(\\.[0-9]\\+\\)*' | head -1"
        tag_success, tag, _ = await self.execute_command(tag_cmd, timeout=30)
        
        if tag_success and tag.strip():
            return False, f"Found tag {tag.strip()} but could not construct download URL automatically. Please check the repository."
        
        return False, f"Failed to fetch latest release from GitHub repository {repo}. Please check your internet connection."
    
    async def connect(self, server: Server) -> Tuple[bool, str]:
        """
        Connect to server via SSH (uses connection pool by default)
        Returns: (success: bool, message: str)
        """
        self.current_server = server
        
        if self.use_pool:
            # Use connection pool
            success, conn, msg = await ssh_connection_pool.get_connection(server)
            self.conn = conn
            
            # Track SSH connection status in background (don't block on DB update)
            _schedule_status_update(server.id, success)
            
            return success, msg
        else:
            # Direct connection (legacy mode)
            try:
                if server.is_password_auth:
                    # Password authentication
                    self.conn = await asyncssh.connect(
                        host=server.host,
                        port=server.ssh_port,
                        username=server.ssh_user,
                        password=server.ssh_password,
                        known_hosts=None,
                        connect_timeout=15
                    )
                elif server.is_key_auth:
                    # Key file authentication
                    self.conn = await asyncssh.connect(
                        host=server.host,
                        port=server.ssh_port,
                        username=server.ssh_user,
                        client_keys=[server.ssh_key_path],
                        known_hosts=None,
                        connect_timeout=15
                    )
                else:
                    return False, f"Unsupported auth type: {server.auth_type}"
                
                # Track successful connection
                _schedule_status_update(server.id, True)
                
                return True, "Connected successfully"
            except asyncssh.PermissionDenied:
                _schedule_status_update(server.id, False)
                return False, "Authentication failed"
            except asyncio.TimeoutError:
                _schedule_status_update(server.id, False)
                return False, "SSH connection timeout - server may be unreachable or too slow to respond"
            except asyncssh.Error as e:
                _schedule_status_update(server.id, False)
                return False, f"SSH error: {str(e)}"
            except Exception as e:
                _schedule_status_update(server.id, False)
                return False, f"Connection error: {str(e)}"
    
    async def execute_command(self, command: str, timeout: int = 30) -> Tuple[bool, str, str]:
        """
        Execute command on remote server
        Returns: (success: bool, stdout: str, stderr: str)
        """
        if not self.conn:
            return False, "", "Not connected"
        
        async def _do_execute():
            result = await asyncio.wait_for(
                self.conn.run(command, check=False),
                timeout=timeout
            )
            
            stdout_text = result.stdout
            stderr_text = result.stderr
            exit_status = result.exit_status
            
            return exit_status == 0, stdout_text, stderr_text
        
        try:
            return await _do_execute()
        except asyncio.TimeoutError:
            return False, "", "Command timeout"
        except (asyncssh.ConnectionLost, asyncssh.DisconnectError, asyncssh.ChannelOpenError) as e:
            # SSH connection errors that can be fixed by reconnection
            error_msg = str(e)
            logger.warning(f"[SSH Manager] SSH connection error in execute_command: {error_msg}")
            if self.use_pool and self.current_server:
                try:
                    success, conn, reconnect_msg = await ssh_connection_pool.reconnect(self.current_server)
                    if success:
                        self.conn = conn
                        logger.info("[SSH Manager] Reconnection successful, retrying execute_command")
                        # Retry once after reconnection
                        return await _do_execute()
                    else:
                        logger.error(f"[SSH Manager] Reconnection failed: {reconnect_msg}")
                        return False, "", f"连接失败 | Connection failed: {reconnect_msg}"
                except Exception as retry_e:
                    logger.error(f"[SSH Manager] Retry execute_command after reconnection failed: {str(retry_e)}")
                    return False, "", f"操作失败（重连后重试仍失败）| Operation failed after reconnection: {str(retry_e)}"
            return False, "", str(e)
        except Exception as e:
            return False, "", str(e)
    
    async def execute_command_streaming(self, command: str, output_callback=None, timeout: int = 1800) -> Tuple[bool, str, str]:
        """
        Execute command on remote server with real-time output streaming
        
        Args:
            command: Command to execute
            output_callback: Optional async callback function to receive output lines in real-time
            timeout: Command timeout in seconds (default: 1800 = 30 minutes)
        
        Returns: (success: bool, stdout: str, stderr: str)
        """
        if not self.conn:
            return False, "", "Not connected"
        
        stdout_lines = []
        stderr_lines = []
        
        async def _execute():
            # Create the process
            process = await self.conn.create_process(command)
            
            # Helper to send output via callback
            async def send_output(line: str):
                if output_callback:
                    if asyncio.iscoroutinefunction(output_callback):
                        await output_callback(line)
                    else:
                        output_callback(line)
            
            # Read stdout and stderr concurrently
            async def read_stream(stream, lines_list, prefix=""):
                """Read from a stream and collect lines"""
                try:
                    async for line in stream:
                        line = line.rstrip('\n\r')
                        if line:  # Only process non-empty lines
                            lines_list.append(line)
                            # Send to callback with prefix
                            await send_output(f"{prefix}{line}" if prefix else line)
                except Exception as e:
                    await send_output(f"Stream read error: {str(e)}")
            
            # Read both stdout and stderr concurrently
            await asyncio.gather(
                read_stream(process.stdout, stdout_lines),
                read_stream(process.stderr, stderr_lines, "[STDERR] "),
                return_exceptions=True
            )
            
            # AsyncSSH returns an SSHCompletedProcess here, not the numeric
            # exit status itself. Comparing that result object directly with
            # zero makes every streaming command look like a failure.
            completed = await process.wait()
            
            stdout_text = '\n'.join(stdout_lines)
            stderr_text = '\n'.join(stderr_lines)
            
            return completed.exit_status == 0, stdout_text, stderr_text
        
        try:
            return await asyncio.wait_for(_execute(), timeout=timeout)
        except asyncio.TimeoutError:
            return False, '\n'.join(stdout_lines), "Command timeout"
        except (asyncssh.ConnectionLost, asyncssh.DisconnectError, asyncssh.ChannelOpenError) as e:
            # SSH connection errors that can be fixed by reconnection
            error_msg = str(e)
            logger.warning(f"[SSH Manager] SSH connection error in execute_command_streaming: {error_msg}")
            if self.use_pool and self.current_server:
                try:
                    success, conn, reconnect_msg = await ssh_connection_pool.reconnect(self.current_server)
                    if success:
                        self.conn = conn
                        logger.info("[SSH Manager] Reconnection successful, retrying execute_command_streaming")
                        # Retry once after reconnection (clear accumulated output)
                        stdout_lines.clear()
                        stderr_lines.clear()
                        return await asyncio.wait_for(_execute(), timeout=timeout)
                    else:
                        logger.error(f"[SSH Manager] Reconnection failed: {reconnect_msg}")
                        return False, '\n'.join(stdout_lines), f"连接失败 | Connection failed: {reconnect_msg}"
                except Exception as retry_e:
                    logger.error(f"[SSH Manager] Retry execute_command_streaming after reconnection failed: {str(retry_e)}")
                    return False, '\n'.join(stdout_lines), f"操作失败（重连后重试仍失败）| Operation failed after reconnection: {str(retry_e)}"
            return False, '\n'.join(stdout_lines), str(e)
        except Exception as e:
            return False, '\n'.join(stdout_lines), f"Execution error: {str(e)}"
    
    async def execute_sudo_command(self, command: str, sudo_password: Optional[str] = None, 
                                   timeout: int = 30) -> Tuple[bool, str, str]:
        """
        Execute command with sudo on remote server
        Returns: (success: bool, stdout: str, stderr: str)
        """
        if not self.conn:
            return False, "", "Not connected"
        
        try:
            if sudo_password:
                # Use -S option to read password from stdin
                full_command = f"echo '{sudo_password}' | sudo -S {command}"
            else:
                # Try passwordless sudo
                full_command = f"sudo {command}"
            
            result = await asyncio.wait_for(
                self.conn.run(full_command, check=False),
                timeout=timeout
            )
            
            stdout_text = result.stdout
            stderr_text = result.stderr
            exit_status = result.exit_status
            
            return exit_status == 0, stdout_text, stderr_text
        except asyncio.TimeoutError:
            return False, "", "Command timeout"
        except Exception as e:
            return False, "", str(e)
    
    async def disconnect(self):
        """Release or close SSH connection"""
        if self.conn:
            if self.use_pool and self.current_server:
                # Release connection back to pool
                await ssh_connection_pool.release_connection(self.current_server)
            else:
                # Direct connection - close it
                self.conn.close()
                await self.conn.wait_closed()
            
            self.conn = None
            self.current_server = None
    
    async def deploy_cs2_server(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Deploy CS2 server on Ubuntu 24.04+ without requiring sudo
        Similar to LinuxGSM approach - works entirely in user space
        
        Prerequisites (must be installed by system administrator):
        - lib32gcc-s1, lib32stdc++6, curl, wget, tar, screen or tmux, unzip
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)

        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        try:
            # Check if environment is initialized (cs2server user exists)
            await send_progress("Checking environment initialization...")
            
            # Check if game_directory path suggests we need cs2server user
            if '/home/cs2server' in server.game_directory:
                # Check if cs2server user exists
                check_user_cmd = "id cs2server > /dev/null 2>&1 && echo 'exists' || echo 'missing'"
                user_success, user_stdout, _ = await self.execute_command(check_user_cmd)
                
                if 'missing' in user_stdout or not user_success:
                    await send_progress("✗ Environment not initialized: cs2server user does not exist")
                    return False, (
                        "Environment not initialized. Please create cs2server user first:\n"
                        "sudo useradd -m -s /bin/bash cs2server\n"
                        "sudo passwd cs2server\n"
                        "sudo usermod -aG sudo cs2server  # Optional: for installing dependencies\n\n"
                        "Or use a different game_directory path that the current user can access."
                    )
                
                await send_progress("✓ cs2server user exists")
                
                # Verify cs2server home directory has correct permissions
                check_perms_cmd = "test -w /home/cs2server && echo 'writable' || echo 'not_writable'"
                perm_success, perm_stdout, _ = await self.execute_command(check_perms_cmd)
                
                if 'not_writable' in perm_stdout or not perm_success:
                    await send_progress("✗ /home/cs2server directory is not writable")
                    
                    # Try to fix permissions if we have sudo password
                    if server.sudo_password:
                        await send_progress("Attempting to fix permissions...")
                        fix_perms_cmd = f"echo '{server.sudo_password}' | sudo -S chown -R cs2server:cs2server /home/cs2server && echo '{server.sudo_password}' | sudo -S chmod 755 /home/cs2server"
                        fix_success, _, fix_stderr = await self.execute_command(fix_perms_cmd)
                        
                        if fix_success:
                            await send_progress("✓ Permissions fixed for /home/cs2server")
                        else:
                            return False, (
                                "Cannot create directory in /home/cs2server: Permission denied.\n"
                                "Please ensure the directory has correct permissions:\n"
                                "sudo chown -R cs2server:cs2server /home/cs2server\n"
                                "sudo chmod 755 /home/cs2server"
                            )
                    else:
                        return False, (
                            "Cannot create directory in /home/cs2server: Permission denied.\n"
                            "Please ensure the directory has correct permissions:\n"
                            "sudo chown -R cs2server:cs2server /home/cs2server\n"
                            "sudo chmod 755 /home/cs2server"
                        )
                else:
                    await send_progress("✓ /home/cs2server is writable")
            
            # Check if required tools are available
            await send_progress("Checking system prerequisites...")
            session_manager = normalize_session_manager(server.session_manager)
            required_tools = ["wget", "tar", session_manager, "unzip"]
            missing_tools = []
            for tool in required_tools:
                success, stdout, stderr = await self.execute_command(f"command -v {tool}")
                if not success:
                    await send_progress(f"⚠ Warning: {tool} not found")
                    missing_tools.append(tool)
                else:
                    await send_progress(f"✓ Found {tool}: {stdout.strip()}")
            
            # Try to install missing tools
            if missing_tools:
                await send_progress(f"Attempting to install missing tools: {', '.join(missing_tools)}")
                # Check package manager
                check_apt = "command -v apt-get > /dev/null && echo 'apt' || echo 'none'"
                _, pkg_mgr, _ = await self.execute_command(check_apt)
                
                if 'apt' in pkg_mgr:
                    # Try to install without sudo first (user might have passwordless sudo)
                    install_cmd = f"apt-get update && apt-get install -y {' '.join(missing_tools)}"
                    success, stdout, stderr = await self.execute_command(install_cmd, timeout=120)
                    
                    if not success:
                        # Try with sudo
                        if server.sudo_password:
                            await send_progress("Trying to install with sudo...")
                            install_cmd = f"echo '{server.sudo_password}' | sudo -S apt-get update && echo '{server.sudo_password}' | sudo -S apt-get install -y {' '.join(missing_tools)}"
                            success, stdout, stderr = await self.execute_command(install_cmd, timeout=120)
                            
                            if success:
                                await send_progress(f"✓ Successfully installed: {', '.join(missing_tools)}")
                            else:
                                await send_progress(f"⚠ Could not install tools. Please run: sudo apt-get install {' '.join(missing_tools)}")
                        else:
                            await send_progress(f"⚠ Could not install tools (no sudo password). Please run: sudo apt-get install {' '.join(missing_tools)}")
                    else:
                        await send_progress(f"✓ Successfully installed: {', '.join(missing_tools)}")
                else:
                    await send_progress(f"⚠ Please manually install: {', '.join(missing_tools)}")
            
            # Create directory
            await send_progress(f"Creating game directory: {server.game_directory}")
            success, stdout, stderr = await self.execute_command(f"mkdir -p {server.game_directory}")
            if not success:
                return False, f"Directory creation failed: {stderr}"
            await send_progress("✓ Game directory created successfully")
            
            # Download and install SteamCMD
            steamcmd_dir = f"{server.game_directory}/steamcmd"
            await send_progress("Setting up SteamCMD...")
            
            # Create SteamCMD directory
            await send_progress("Creating SteamCMD directory...")
            success, stdout, stderr = await self.execute_command(f"mkdir -p {steamcmd_dir}")
            if not success:
                return False, f"SteamCMD directory creation failed: {stderr}"
            await send_progress("✓ SteamCMD directory created")
            
            # Download SteamCMD with streaming output
            await send_progress("Downloading SteamCMD...")
            
            # Check if panel proxy mode is enabled
            if server.use_panel_proxy:
                # Panel Proxy Mode: Download to panel server first, then upload via SFTP
                await send_progress("Using panel server proxy mode for SteamCMD download...")
                
                steamcmd_url = "https://steamcdn-a.akamaihd.net/client/installer/steamcmd_linux.tar.gz"
                steamcmd_local_path = None
                
                try:
                    # Create temp directory on panel server
                    panel_temp_dir = os.path.join(tempfile.gettempdir(), f"cs2_panel_proxy_steamcmd_{server.user_id}")
                    os.makedirs(panel_temp_dir, exist_ok=True)
                    
                    # Create unique subdirectory
                    download_id = str(uuid.uuid4())
                    download_dir = os.path.join(panel_temp_dir, download_id)
                    os.makedirs(download_dir, exist_ok=True)
                    
                    steamcmd_local_path = os.path.join(download_dir, "steamcmd_linux.tar.gz")
                    
                    # Download to panel server
                    from modules.http_helper import http_helper
                    
                    last_progress = 0
                    async def download_progress_callback(bytes_downloaded, total_bytes):
                        nonlocal last_progress
                        if total_bytes > 0:
                            percent = int((bytes_downloaded / total_bytes) * 100)
                            if percent >= last_progress + 10 or percent == 100:
                                last_progress = percent
                                size_mb = bytes_downloaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Download progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    success_download, error = await http_helper.download_file(
                        steamcmd_url,
                        steamcmd_local_path,
                        timeout=600,
                        progress_callback=download_progress_callback
                    )
                    
                    if not success_download:
                        raise Exception(f"Failed to download SteamCMD: {error}")
                    
                    # Verify file size
                    file_size = os.path.getsize(steamcmd_local_path)
                    if file_size < 1000:
                        raise Exception("Downloaded SteamCMD file is too small or empty")
                    
                    await send_progress(f"Download complete ({file_size / (1024 * 1024):.2f} MB), uploading to server...")
                    
                    # Upload to remote server via SFTP
                    remote_steamcmd_path = f"{steamcmd_dir}/steamcmd_linux.tar.gz"
                    
                    last_upload = 0
                    async def upload_progress_callback(bytes_uploaded, total_bytes):
                        nonlocal last_upload
                        if total_bytes > 0:
                            percent = int((bytes_uploaded / total_bytes) * 100)
                            if percent >= last_upload + 10 or percent == 100:
                                last_upload = percent
                                size_mb = bytes_uploaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Upload progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    success_upload, error = await self.upload_file_with_progress(
                        steamcmd_local_path,
                        remote_steamcmd_path,
                        server,
                        progress_callback=upload_progress_callback
                    )
                    
                    if not success_upload:
                        raise Exception(f"Failed to upload SteamCMD: {error}")
                    
                    await send_progress("✓ SteamCMD uploaded successfully")
                    
                finally:
                    # Clean up panel temp directory
                    if steamcmd_local_path:
                        await _cleanup_local_download_dir(download_dir, panel_temp_dir)
            else:
                # Original Mode: Download directly on remote server
                download_cmd = f"wget --progress=dot:mega https://steamcdn-a.akamaihd.net/client/installer/steamcmd_linux.tar.gz -O {steamcmd_dir}/steamcmd_linux.tar.gz"
                success, stdout, stderr = await self.execute_command_streaming(
                    download_cmd,
                    output_callback=send_progress,
                    timeout=300
                )
                if not success:
                    # Check if file was downloaded successfully despite non-zero exit code
                    check_cmd = f"test -f {steamcmd_dir}/steamcmd_linux.tar.gz && echo 'exists'"
                    check_success, check_stdout, _ = await self.execute_command(check_cmd)
                    if not check_success or 'exists' not in check_stdout:
                        return False, f"SteamCMD download failed: {stderr if stderr else 'Download incomplete'}"
                    # File exists, continue despite wget exit code
                    await send_progress("✓ SteamCMD download completed (file verified)")
                else:
                    await send_progress("✓ SteamCMD downloaded successfully")
            
            # Extract SteamCMD
            await send_progress("Extracting SteamCMD...")
            success, stdout, stderr = await self.execute_command(
                f"tar -xzf {steamcmd_dir}/steamcmd_linux.tar.gz -C {steamcmd_dir}",
                timeout=120
            )
            if not success:
                return False, f"SteamCMD extraction failed: {stderr}"
            await send_progress("✓ SteamCMD extracted successfully")
            
            # Install CS2 server (App ID: 730) with streaming output and automatic retry
            await send_progress("=" * 60)
            await send_progress("Installing CS2 server via SteamCMD...")
            await send_progress("This will download approximately 30GB and may take 15-30 minutes")
            await send_progress(
                "Auto-retry is enabled: up to 5 retries whenever the required "
                "CS2 executable is still missing"
            )
            await send_progress("Please be patient, you will see real-time progress below:")
            await send_progress("=" * 60)
            
            install_cs2 = (
                f"cd {steamcmd_dir} && "
                f"./steamcmd.sh "
                f"+force_install_dir {server.game_directory}/cs2 "
                f"+login anonymous "
                f"+app_update 730 validate "
                f"+quit"
            )
            
            # Display command preview before execution
            await send_progress("")
            await send_progress("即将执行的命令 / Commands to be executed:")
            await send_progress("=" * 60)
            await send_progress("📝 SteamCMD Install Command:")
            await send_progress(f"   {install_cs2}")
            await send_progress("=" * 60)
            await send_progress("")
            
            async def verify_cs2_installation() -> bool:
                executable_exists, executable_path = (
                    await self._cs2_executable_exists_connected(server)
                )
                if executable_exists:
                    await send_progress(
                        f"✓ CS2 executable verified: {executable_path}"
                    )
                else:
                    await send_progress(
                        f"✗ CS2 executable is still missing: {executable_path}"
                    )
                return executable_exists

            # A SteamCMD zero exit code is not sufficient: interrupted downloads
            # can leave an incomplete tree. Verify the actual server executable
            # after every attempt and retry even for otherwise non-retryable exits.
            success, stdout, stderr = await self._execute_steamcmd_with_retry(
                install_cs2,
                server,
                progress_callback=send_progress,
                timeout=1800,  # 30 minutes per attempt
                max_retries=self.STEAMCMD_MAX_RETRIES,
                completion_check=verify_cs2_installation,
            )
            
            if not success:
                executable_path = self._cs2_executable_path(server)
                error_detail = stderr.strip() if stderr else "Installation incomplete"
                alarm_message = (
                    "🚨 CS2 部署失败报警：SteamCMD 初次执行及 5 次自动重试后，"
                    f"仍未找到文件 {executable_path}。部署已中断；请重新部署或运行修复。"
                    f" 错误详情：{error_detail}"
                )
                await send_progress(alarm_message)
                logger.error(
                    "CS2 deployment aborted for server %s: executable missing at %s "
                    "after %s retries",
                    server.id,
                    executable_path,
                    self.STEAMCMD_MAX_RETRIES,
                )
                return False, alarm_message
            
            # Fix steamclient.so symlink issue (required for CS2 to start)
            # See: https://developer.valvesoftware.com/wiki/Counter-Strike_2/Dedicated_Servers#Troubleshooting
            await send_progress("=" * 60)
            await send_progress("Fixing steamclient.so symlink (required for server startup)...")
            await send_progress("=" * 60)
            
            # Create ~/.steam/sdk64 directory if it doesn't exist
            steam_sdk_dir = f"/home/{server.ssh_user}/.steam/sdk64"
            mkdir_cmd = f"mkdir -p {steam_sdk_dir}"
            await self.execute_command(mkdir_cmd)
            
            # Create symlink to steamclient.so
            # This fixes: "Failed to load module '/home/user/.steam/sdk64/steamclient.so'"
            steamclient_source = f"{steamcmd_dir}/linux64/steamclient.so"
            steamclient_target = f"{steam_sdk_dir}/steamclient.so"
            symlink_cmd = f"ln -sf {steamclient_source} {steamclient_target}"
            symlink_success, _, _ = await self.execute_command(symlink_cmd)
            
            if symlink_success:
                await send_progress("✓ steamclient.so symlink created successfully")
            else:
                await send_progress("⚠ Warning: Could not create steamclient.so symlink (may cause startup issues)")
                
                # CS2 executable exists, installation successful despite exit code
                await send_progress("=" * 60)
                await send_progress("✓ CS2 server installed successfully (verified)")
                await send_progress("=" * 60)
                return True, "CS2 server deployed successfully"
            
            await send_progress("=" * 60)
            await send_progress("✓ CS2 server installed successfully!")
            await send_progress("=" * 60)
            
            # Deploy auto-restart wrapper script
            await send_progress("=" * 60)
            await send_progress("Deploying auto-restart wrapper script...")
            await send_progress("=" * 60)
            
            autorestart_script_path = f"{server.game_directory}/cs2_autorestart.sh"
            
            # Read the autorestart script content
            script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            local_script_path = os.path.join(script_dir, "scripts", "cs2_autorestart.sh")
            
            try:
                async with await anyio.open_file(local_script_path, "r") as script_file:
                    script_content = await script_file.read()
                
                # Create the script on remote server
                create_script_cmd = f"cat > {autorestart_script_path} << 'EOFSCRIPT'\n{script_content}\nEOFSCRIPT"
                success, stdout, stderr = await self.execute_command(create_script_cmd, timeout=10)
                
                if not success:
                    await send_progress(f"⚠ Warning: Could not deploy autorestart script: {stderr}")
                else:
                    # Make script executable
                    chmod_script_cmd = f"chmod +x {autorestart_script_path}"
                    await self.execute_command(chmod_script_cmd)
                    await send_progress("✓ Auto-restart wrapper script deployed successfully")
            except Exception as e:
                await send_progress(f"⚠ Warning: Could not deploy autorestart script: {str(e)}")
            
            await send_progress("=" * 60)
            await send_progress("✓ Deployment completed successfully!")
            await send_progress("=" * 60)
            
            return True, "CS2 server deployed successfully"
        
        except Exception as e:
            await send_progress(f"Deployment error: {str(e)}")
            return False, f"Deployment error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def perform_server_selfcheck(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Perform universal self-checks on the CS2 server and automatically fix common issues.
        
        Checks performed:
        - CS2 executable exists and has proper permissions
        - steamclient.so symlink exists and is valid
        - gameinfo.gi is properly configured for Metamod (if installed)
        - Auto-restart script is deployed
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        
        Returns:
            Tuple[bool, str]: (success, message)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        try:
            await send_progress("=" * 60)
            await send_progress("Performing server self-check and auto-fix...")
            await send_progress("=" * 60)
            
            issues_found = []
            issues_fixed = []
            
            # Check 1: CS2 executable exists and has proper permissions
            await send_progress("Checking CS2 executable...")
            cs2_executable = f"{server.game_directory}/cs2/game/bin/linuxsteamrt64/cs2"
            verify_cmd = f"test -f {cs2_executable} && echo 'exists'"
            verify_success, verify_stdout, _ = await self.execute_command(verify_cmd)
            
            if not verify_success or 'exists' not in verify_stdout:
                issues_found.append("CS2 executable not found")
                await send_progress("✗ CS2 executable not found - server may not be deployed")
            else:
                # Ensure executable has proper permissions
                chmod_cmd = f"chmod +x {cs2_executable}"
                chmod_success, _, _ = await self.execute_command(chmod_cmd)
                if chmod_success:
                    await send_progress("✓ CS2 executable found and permissions set")
                else:
                    await send_progress("⚠ CS2 executable found but could not set permissions")
            
            # Check 2: steamclient.so symlink
            await send_progress("Checking steamclient.so symlink...")
            steam_sdk_dir = f"/home/{server.ssh_user}/.steam/sdk64"
            steamclient_target = f"{steam_sdk_dir}/steamclient.so"
            
            check_cmd = f"test -L {steamclient_target} && test -e {steamclient_target} && echo 'valid' || echo 'missing'"
            check_success, check_stdout, _ = await self.execute_command(check_cmd)
            
            if 'missing' in check_stdout or not check_success:
                issues_found.append("steamclient.so symlink missing or broken")
                await send_progress("✗ steamclient.so symlink missing or broken - attempting to fix...")
                
                # Create directory
                mkdir_cmd = f"mkdir -p {steam_sdk_dir}"
                await self.execute_command(mkdir_cmd)
                
                # Find steamclient.so source
                steamcmd_dir = f"{server.game_directory}/steamcmd"
                steamclient_source = f"{steamcmd_dir}/linux64/steamclient.so"
                
                source_check = f"test -f {steamclient_source} && echo 'found' || echo 'notfound'"
                source_success, source_stdout, _ = await self.execute_command(source_check)
                
                if 'found' in source_stdout:
                    # Create symlink
                    symlink_cmd = f"ln -sf {steamclient_source} {steamclient_target}"
                    symlink_success, _, _ = await self.execute_command(symlink_cmd)
                    
                    if symlink_success:
                        issues_fixed.append("steamclient.so symlink")
                        await send_progress("✓ steamclient.so symlink created successfully")
                    else:
                        await send_progress("✗ Failed to create steamclient.so symlink")
                else:
                    await send_progress(f"✗ steamclient.so source not found at {steamclient_source}")
            else:
                await send_progress("✓ steamclient.so symlink is valid")
            
            # Check 3: gameinfo.gi for Metamod
            await send_progress("Checking gameinfo.gi configuration...")
            cs2_dir = f"{server.game_directory}/cs2"
            gameinfo_path = f"{cs2_dir}/game/csgo/gameinfo.gi"
            metamod_dir = f"{cs2_dir}/game/csgo/addons/metamod"
            
            # Check if Metamod is installed
            check_mm_cmd = f"test -d {metamod_dir} && echo 'exists'"
            mm_exists_success, mm_exists_stdout, _ = await self.execute_command(check_mm_cmd)
            
            if mm_exists_success and 'exists' in mm_exists_stdout:
                # Check if gameinfo.gi exists
                check_gi_cmd = f"test -f {gameinfo_path} && echo 'exists'"
                gi_exists_success, gi_exists_stdout, _ = await self.execute_command(check_gi_cmd)
                
                if gi_exists_success and 'exists' in gi_exists_stdout:
                    # Check if Metamod is configured in gameinfo.gi
                    check_mm_line = f"grep -q 'addons/metamod' {gameinfo_path} && echo 'found' || echo 'notfound'"
                    check_line_success, check_line_stdout, _ = await self.execute_command(check_mm_line)
                    
                    if 'notfound' in check_line_stdout:
                        issues_found.append("Metamod not configured in gameinfo.gi")
                        await send_progress("✗ Metamod installed but not configured in gameinfo.gi - attempting to fix...")
                        
                        # Backup gameinfo.gi
                        backup_cmd = f"cp {gameinfo_path} {gameinfo_path}.backup.$(date +%Y%m%d_%H%M%S)"
                        await self.execute_command(backup_cmd)
                        
                        # Add Metamod to gameinfo.gi
                        sed_cmd = f"sed -i '/Game_LowViolence/a\\			Game\\tcsgo/addons/metamod' {gameinfo_path}"
                        sed_success, _, _ = await self.execute_command(sed_cmd)
                        
                        if sed_success:
                            issues_fixed.append("gameinfo.gi Metamod configuration")
                            await send_progress("✓ Metamod added to gameinfo.gi successfully")
                        else:
                            await send_progress("✗ Failed to update gameinfo.gi automatically")
                    else:
                        await send_progress("✓ Metamod is properly configured in gameinfo.gi")
                else:
                    await send_progress("⚠ gameinfo.gi not found (Metamod installed but game not deployed)")
            else:
                await send_progress("✓ Metamod not installed - gameinfo.gi check skipped")
            
            # Check 4: Auto-restart script
            await send_progress("Checking auto-restart script...")
            autorestart_script_path = f"{server.game_directory}/cs2_autorestart.sh"
            
            check_script_cmd = f"test -f {autorestart_script_path} && test -x {autorestart_script_path} && echo 'exists'"
            script_success, script_stdout, _ = await self.execute_command(check_script_cmd)
            
            if not script_success or 'exists' not in script_stdout:
                issues_found.append("Auto-restart script not found or not executable")
                await send_progress("✗ Auto-restart script missing - attempting to deploy...")
                
                # Deploy the script
                script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                local_script_path = os.path.join(script_dir, "scripts", "cs2_autorestart.sh")
                
                try:
                    async with await anyio.open_file(local_script_path, "r") as script_file:
                        script_content = await script_file.read()
                    
                    create_script_cmd = f"cat > {autorestart_script_path} << 'EOFSCRIPT'\n{script_content}\nEOFSCRIPT"
                    deploy_success, _, _ = await self.execute_command(create_script_cmd, timeout=10)
                    
                    if deploy_success:
                        chmod_script_cmd = f"chmod +x {autorestart_script_path}"
                        await self.execute_command(chmod_script_cmd)
                        issues_fixed.append("auto-restart script")
                        await send_progress("✓ Auto-restart script deployed successfully")
                    else:
                        await send_progress("✗ Failed to deploy auto-restart script")
                except Exception as e:
                    await send_progress(f"✗ Error deploying auto-restart script: {str(e)}")
            else:
                await send_progress("✓ Auto-restart script is deployed and executable")
            
            # Summary
            await send_progress("=" * 60)
            await send_progress("Self-check completed!")
            await send_progress("=" * 60)
            
            if issues_found:
                await send_progress(f"Issues found: {len(issues_found)}")
                for issue in issues_found:
                    await send_progress(f"  - {issue}")
            
            if issues_fixed:
                await send_progress(f"Issues fixed: {len(issues_fixed)}")
                for fix in issues_fixed:
                    await send_progress(f"  ✓ {fix}")
            
            if not issues_found:
                await send_progress("✓ No issues found - server is ready to start")
                return True, "Server self-check passed"
            elif len(issues_fixed) == len(issues_found):
                await send_progress("✓ All issues were automatically fixed")
                return True, "Server self-check completed with auto-fixes"
            else:
                unfixed = len(issues_found) - len(issues_fixed)
                await send_progress(f"⚠ {unfixed} issue(s) could not be automatically fixed")
                return False, f"{unfixed} issues remain"
        
        except Exception as e:
            await send_progress(f"Self-check error: {str(e)}")
            return False, f"Self-check error: {str(e)}"

    async def _running_server_session_managers(
        self,
        server: Server,
        timeout: int = 10,
    ) -> List[str]:
        """Find configured and legacy sessions for a server on this connection."""
        return await find_running_session_managers(
            self.execute_command,
            server.session_manager,
            session_name(server.id),
            timeout=timeout,
        )

    async def _configured_session_manager_available_connected(
        self,
        server: Server,
        timeout: int = 10,
    ) -> Tuple[bool, str]:
        """Check the selected manager without changing any existing session."""
        manager = normalize_session_manager(server.session_manager)
        available, _, _ = await self.execute_command(
            availability_command(manager),
            timeout=timeout,
        )
        if available:
            return True, f"{manager} is available"
        return False, (
            f"Selected session manager '{manager}' is not installed on the remote host"
        )

    @classmethod
    def _cs2_executable_path(cls, server: Server) -> str:
        """Return the required Linux CS2 executable path for a server."""
        return posixpath.join(
            server.game_directory.rstrip("/"),
            cls.CS2_EXECUTABLE_RELATIVE_PATH,
        )

    async def _cs2_executable_exists_connected(
        self,
        server: Server,
        timeout: int = 10,
    ) -> Tuple[bool, str]:
        """Check the required executable using the current SSH connection."""
        executable_path = self._cs2_executable_path(server)
        success, stdout, _ = await self.execute_command(
            f"test -f {shlex.quote(executable_path)} && echo exists",
            timeout=timeout,
        )
        return success and stdout.strip() == "exists", executable_path

    @staticmethod
    def _missing_cs2_executable_message(executable_path: str) -> str:
        return (
            f"CS2 可执行文件不存在：{executable_path}。"
            "请重新部署服务器或运行修复/验证。"
        )

    async def check_session_manager_available(
        self,
        server: Server,
        timeout: int = 10,
    ) -> Tuple[bool, str]:
        """Check start/restart prerequisites before stopping a live server."""
        success, message = await self.connect(server)
        if not success:
            return False, f"Connection failed during start/restart preflight: {message}"

        try:
            executable_exists, executable_path = (
                await self._cs2_executable_exists_connected(server, timeout=timeout)
            )
            if not executable_exists:
                return False, self._missing_cs2_executable_message(executable_path)

            return await self._configured_session_manager_available_connected(
                server,
                timeout=timeout,
            )
        finally:
            await self.disconnect()

    async def _stop_server_sessions_connected(
        self,
        server: Server,
        progress_callback=None,
        retries: int = 3,
    ) -> Tuple[bool, List[str]]:
        """Stop every matching screen/tmux session without closing SSH.

        Checking both managers is intentional: a user may change the preferred
        manager while a legacy session is still running.  tmux force-stop is
        session-scoped by ``game_session`` and never kills its shared server.

        Returns ``(all_stopped, managers_found_before_stop)``.
        """
        name = session_name(server.id)
        initial_managers = await self._running_server_session_managers(server)
        if not initial_managers:
            return True, []

        await self._send_progress_if_callback(
            progress_callback,
            "Found existing game session(s): " + ", ".join(initial_managers),
        )

        remaining = initial_managers
        for attempt in range(max(1, retries)):
            for manager in remaining:
                await self.execute_command(
                    stop_session_command(manager, name),
                    timeout=10,
                )

            await asyncio.sleep(1)
            remaining = await self._running_server_session_managers(server)
            if not remaining:
                return True, initial_managers

            if attempt < max(1, retries) - 1:
                await self._send_progress_if_callback(
                    progress_callback,
                    f"Waiting for {', '.join(remaining)} session(s) to terminate...",
                )

        await self._send_progress_if_callback(
            progress_callback,
            "Session shutdown timed out; applying manager-scoped force stop...",
        )
        for manager in remaining:
            await self.execute_command(
                force_stop_session_command(manager, name),
                timeout=10,
            )

        await asyncio.sleep(1)
        remaining = await self._running_server_session_managers(server)
        return not remaining, initial_managers
    
    async def start_server(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Start CS2 server with LGSM-style configuration and real-time output streaming
        
        This method includes defensive checks to ensure no duplicate screen or
        tmux sessions.  It also cleans up a legacy session when the configured
        manager has changed.
        """
        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                await progress_callback(message)
        
        def sanitize_sensitive_value(cmd: str, value: str, replacement: str) -> str:
            """
            Helper to sanitize a sensitive value from a command string.
            Handles single quotes, double quotes, and unquoted occurrences.
            Processes quoted occurrences first, then unquoted to avoid partial exposure.
            Uses regex escaping to handle special characters safely.
            """
            if value is None or value == '':
                return cmd
            # Escape the value for safe string replacement (handles special characters)
            escaped_value = re.escape(value)
            # Replace quoted occurrences first (more specific matches)
            cmd = re.sub(f'"{escaped_value}"', f'"{replacement}"', cmd)
            cmd = re.sub(f"'{escaped_value}'", f"'{replacement}'", cmd)
            # Replace unquoted occurrences last (more general match)
            cmd = re.sub(escaped_value, replacement, cmd)
            return cmd
        
        try:
            executable_exists, executable_path = (
                await self._cs2_executable_exists_connected(server)
            )
            if not executable_exists:
                message = self._missing_cs2_executable_message(executable_path)
                await send_progress(f"✗ {message}")
                return False, message

            manager = normalize_session_manager(server.session_manager)
            name = session_name(server.id)
            await send_progress(f"Using {manager} as the game session manager")

            manager_available, manager_message = (
                await self._configured_session_manager_available_connected(server)
            )
            if not manager_available:
                return False, (
                    f"Cannot start server: {manager_message}. "
                    "Please install it on the remote host first."
                )

            # GNU screen can leave dead sockets. tmux removes dead sessions
            # itself, so it deliberately has no equivalent global cleanup.
            stale_cleanup = cleanup_command("screen")
            if stale_cleanup:
                await self.execute_command(stale_cleanup, timeout=10)

            sessions_stopped, previous_managers = (
                await self._stop_server_sessions_connected(
                    server,
                    progress_callback=progress_callback,
                    retries=3,
                )
            )
            if not sessions_stopped:
                return False, (
                    "Cannot start server because an existing screen/tmux "
                    "session could not be terminated safely"
                )
            if previous_managers:
                await send_progress("✓ Existing game session(s) terminated")

            # Kill any stray CS2 processes which no longer have a live session.
            # This is an additional safety check to prevent duplicate processes
            await self._kill_stray_cs2_processes(server, progress_callback)
            
            # Perform universal self-check and auto-fix common issues
            selfcheck_success, selfcheck_msg = await self.perform_server_selfcheck(server, progress_callback)
            if not selfcheck_success:
                await send_progress(f"⚠ Warning: Self-check found issues: {selfcheck_msg}")
                await send_progress("Continuing with server start...")
            
            # Build start command with LGSM-style parameters
            cs2_executable = "./cs2"  # Use relative path when in correct directory
            
            # Get configuration with safe defaults
            default_map = server.default_map or "de_dust2"
            max_players = server.max_players or 32
            server_name = server.server_name or f"CS2 Server {server.id}"
            
            # Game mode mapping: convert string names to numeric values
            # Reference: https://developer.valvesoftware.com/wiki/Counter-Strike:_Global_Offensive/Game_Modes
            # Format: (game_type, game_mode)
            game_mode_str = server.game_mode or "competitive"
            
            # Correct mapping from Valve documentation
            # Each mode maps to (game_type, game_mode) tuple
            mode_mapping = {
                "casual": ("0", "0"),
                "competitive": ("0", "1"),
                "wingman": ("0", "2"),
                "arms_race": ("1", "0"),
                "armsrace": ("1", "0"),  # Alternative spelling
                "demolition": ("1", "1"),
                "deathmatch": ("2", "0"),
                "custom": ("3", "0"),
            }
            
            # Convert game_mode string to numeric values
            if game_mode_str:
                game_mode_lower = game_mode_str.lower()
                # Check if it's in the mapping
                if game_mode_lower in mode_mapping:
                    mapped_game_type, mapped_game_mode = mode_mapping[game_mode_lower]
                    game_mode = mapped_game_mode
                    # Use mapped game_type if user hasn't explicitly set one
                    if not server.game_type:
                        game_type = mapped_game_type
                    else:
                        game_type = server.game_type
                # Check if it's already a numeric string
                elif game_mode_str.isdigit():
                    game_mode = game_mode_str
                    game_type = server.game_type or "0"
                else:
                    # Unknown string value, default to competitive and log warning
                    await send_progress(f"⚠ Warning: Unknown game_mode '{game_mode_str}', defaulting to competitive")
                    game_mode = "1"
                    game_type = "0"  # Competitive uses game_type 0
            else:
                game_mode = "1"  # Default to competitive
                game_type = server.game_type or "0"
            
            # Core parameters
            # Note: -tickrate is no longer supported in CS2
            params = [
                "-dedicated",
                f"-port {server.game_port}",
                f"+map {default_map}",
                f"-maxplayers {max_players}",
                f'+hostname "{server_name}"',
            ]
            
            # Optional IP binding
            if server.ip_address:
                params.append(f"-ip {server.ip_address}")
            
            # Client port (usually game_port + 1)
            if server.client_port:
                params.append(f"+clientport {server.client_port}")
            elif server.game_port:
                params.append(f"+clientport {server.game_port + 1}")
            
            # Steam account token (GSLT) - required for public servers
            if server.steam_account_token:
                params.append(f'+sv_setsteamaccount "{server.steam_account_token}"')
            
            # Server password
            if server.server_password:
                params.append(f'+sv_password "{server.server_password}"')
            
            # RCON password
            if server.rcon_password:
                params.append(f'+rcon_password "{server.rcon_password}"')
            
            # Game mode and type
            params.append(f"+game_mode {game_mode}")
            params.append(f"+game_type {game_type}")
            
            # SourceTV configuration
            if server.tv_enable and server.tv_port:
                params.extend([
                    "+tv_enable 1",
                    f"+tv_port {server.tv_port}",
                    '+tv_name "GOTV"',
                ])
            
            # Additional custom parameters
            if server.additional_parameters:
                params.append(server.additional_parameters.strip())
            
            # Combine all parameters
            params_str = " ".join(params)
            
            # Get backend URL and API key for status reporting
            # Use server's backend_url if set, otherwise use global setting
            from modules.config import settings
            backend_url = server.backend_url or settings.BACKEND_URL
            api_key = server.api_key or ""
            
            # Check if autorestart script exists (should have been deployed during deployment)
            autorestart_script_path = f"{server.game_directory}/cs2_autorestart.sh"
            check_script_cmd = f"test -f {autorestart_script_path} && echo 'exists'"
            script_exists_success, script_exists_stdout, _ = await self.execute_command(check_script_cmd)
            
            # If script doesn't exist, deploy it now
            if not script_exists_success or 'exists' not in script_exists_stdout:
                await send_progress("Auto-restart script not found, deploying now...")
                
                # Read the autorestart script content
                script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                local_script_path = os.path.join(script_dir, "scripts", "cs2_autorestart.sh")
                
                try:
                    async with await anyio.open_file(local_script_path, "r") as script_file:
                        script_content = await script_file.read()
                    
                    # Create the script on remote server
                    create_script_cmd = f"cat > {autorestart_script_path} << 'EOFSCRIPT'\n{script_content}\nEOFSCRIPT"
                    success, stdout, stderr = await self.execute_command(create_script_cmd, timeout=10)
                    
                    if not success:
                        await send_progress(f"⚠ Warning: Could not deploy autorestart script: {stderr}")
                        await send_progress("Server will start without auto-restart protection")
                        use_autorestart = False
                    else:
                        # Make script executable
                        chmod_script_cmd = f"chmod +x {autorestart_script_path}"
                        await self.execute_command(chmod_script_cmd)
                        await send_progress("✓ Auto-restart wrapper script deployed")
                        use_autorestart = True
                except Exception as e:
                    await send_progress(f"⚠ Warning: Could not read autorestart script: {str(e)}")
                    await send_progress("Server will start without auto-restart protection")
                    use_autorestart = False
            else:
                await send_progress("✓ Auto-restart script found")
                use_autorestart = True
            
            # LGSM-style startup: Set working directory, library path, and redirect output
            # Working directory must be the bin directory for CS2 to find its libraries
            game_bin_dir = f"{server.game_directory}/cs2/game/bin/linuxsteamrt64"
            
            # Build the CS2 command independently of its session manager.
            cs2_start_cmd = (
                f"cd {shlex.quote(game_bin_dir)} && "
                f"export LD_LIBRARY_PATH={shlex.quote(game_bin_dir)}:"
                f"\"${{LD_LIBRARY_PATH:-}}\" && "
                f"{cs2_executable} {params_str}"
            )
            
            # CPU affinity belongs to the payload, not the tmux client.  A
            # long-lived tmux daemon would otherwise retain its old affinity.
            cpu_affinity = None
            if server.cpu_affinity:
                affinity = server.cpu_affinity.strip()
                if re.fullmatch(r'[\d,\-\s]+', affinity):
                    cpu_affinity = affinity
                    await send_progress(f"✓ CPU affinity configured: cores {affinity}")
                else:
                    await send_progress(f"⚠ Warning: Invalid CPU affinity format '{server.cpu_affinity}', ignoring")
            
            if use_autorestart and api_key:
                payload = (
                    f"bash {shlex.quote(autorestart_script_path)} "
                    f"{server.id} {shlex.quote(api_key)} "
                    f"{shlex.quote(backend_url)} {shlex.quote(server.game_directory)} "
                    f"{shlex.quote(cs2_start_cmd)}"
                )
                start_cmd = start_session_command(
                    manager,
                    name,
                    payload,
                    cpu_affinity,
                )
                await send_progress("✓ Starting with auto-restart protection enabled")
            else:
                console_log = f"{server.game_directory}/cs2/game/csgo/console.log"
                shell_payload = (
                    f"cd {shlex.quote(game_bin_dir)} && "
                    f"export LD_LIBRARY_PATH={shlex.quote(game_bin_dir)}:"
                    f"\"${{LD_LIBRARY_PATH:-}}\" && "
                    f"{cs2_executable} {params_str} 2>&1 | "
                    f"tee {shlex.quote(console_log)}"
                )
                payload = f"bash -c {shlex.quote(shell_payload)}"
                start_cmd = start_session_command(
                    manager,
                    name,
                    payload,
                    cpu_affinity,
                )
                if not api_key:
                    await send_progress("⚠ Warning: No API key configured, auto-restart reporting disabled")

            
            # Send startup information
            await send_progress("=" * 60)
            await send_progress("Starting CS2 Server...")
            await send_progress("=" * 60)
            await send_progress(f"Server ID: {server.id}")
            await send_progress(f"Port: {server.game_port}")
            await send_progress(f"Map: {default_map}")
            await send_progress(f"Max Players: {max_players}")
            await send_progress(f"Game Mode: {game_mode_str} (game_type: {game_type}, game_mode: {game_mode})")
            await send_progress("=" * 60)
            await send_progress("Startup Command:")
            # Sanitize sensitive information before displaying
            sanitized_cmd = start_cmd
            sanitized_cmd = sanitize_sensitive_value(sanitized_cmd, api_key, "***API_KEY***")
            sanitized_cmd = sanitize_sensitive_value(sanitized_cmd, server.server_password, "***PASSWORD***")
            sanitized_cmd = sanitize_sensitive_value(sanitized_cmd, server.rcon_password, "***RCON_PASSWORD***")
            sanitized_cmd = sanitize_sensitive_value(sanitized_cmd, server.steam_account_token, "***STEAM_TOKEN***")
            await send_progress(sanitized_cmd)
            await send_progress("=" * 60)
            
            success, stdout, stderr = await self.execute_command(start_cmd, timeout=10)
            
            if not success:
                await send_progress(f"Start command failed: {stderr}")
                return False, f"Start command failed: {stderr}"
            
            await send_progress("Server process started, streaming console output...")
            await send_progress("=" * 60)
            
            # Stream console output in real-time for first few seconds
            console_log_path = f"{server.game_directory}/cs2/game/csgo/console.log"
            
            # Wait a moment for log file to be created
            await asyncio.sleep(0.3)
            
            # Stream console output using tail -f with timeout
            # This will show the actual server startup messages (like srcds)
            stream_cmd = f"timeout 4 tail -f {console_log_path} 2>/dev/null || true"
            
            # Use execute_command_streaming to show real-time output
            try:
                await self.execute_command_streaming(stream_cmd, output_callback=progress_callback, timeout=5)
            except Exception:
                # Timeout is expected - just continue
                pass
            
            await send_progress("=" * 60)
            await send_progress("Initial startup output complete, verifying server status...")
            await send_progress("=" * 60)
            
            # Early check: verify the configured session was created.
            # Wait a bit longer as initialization can take time
            await asyncio.sleep(0.8)
            running_managers = await self._running_server_session_managers(server)
            
            if manager not in running_managers:
                # The selected session never started or exited during initialization.
                log_check = f"test -f {server.game_directory}/cs2/game/csgo/console.log && tail -150 {server.game_directory}/cs2/game/csgo/console.log || echo 'No log file'"
                _, immediate_log, _ = await self.execute_command(log_check, timeout=10)
                
                # Check if auto-restart is available
                can_restart, restart_msg = server_monitor.can_restart(server.id)
                
                # Check for specific errors in the log
                error_analysis = []
                auto_restart_possible = True
                
                if immediate_log and immediate_log != 'No log file':
                    if 'map' in immediate_log.lower() and 'load' in immediate_log.lower() and 'fail' in immediate_log.lower():
                        error_analysis.append("⚠ Map loading failed - the specified map may not exist or is corrupted")
                        auto_restart_possible = False  # Map issue won't be fixed by restart
                    if 'error' in immediate_log.lower():
                        error_analysis.append("⚠ Server reported errors during initialization")
                    if 'quit' in immediate_log.lower() or 'exit' in immediate_log.lower():
                        error_analysis.append("⚠ Server exited during startup")
                    if 'segmentation' in immediate_log.lower() or 'sigsegv' in immediate_log.lower():
                        error_analysis.append("⚠ Server crashed (segmentation fault)")
                    if 'bind' in immediate_log.lower() or 'address already in use' in immediate_log.lower():
                        error_analysis.append("⚠ Port binding failed - port may already be in use")
                        auto_restart_possible = False  # Port issue won't be fixed by restart
                    if 'steamclient.so' in immediate_log.lower() and 'fail' in immediate_log.lower():
                        error_analysis.append("⚠ CRITICAL: steamclient.so loading failed - may need to re-deploy server")
                        auto_restart_possible = False
                
                # Attempt auto-restart if applicable
                if can_restart and auto_restart_possible and progress_callback:
                    await send_progress("\n" + "=" * 60)
                    await send_progress("AUTO-RESTART: Server crashed, attempting automatic restart...")
                    await send_progress(f"Restart status: {restart_msg}")
                    await send_progress("=" * 60)
                    
                    server_monitor.record_restart(server.id)
                    
                    # Log auto-restart to Redis for monitoring audit trail
                    # Local import to avoid circular dependency with services/__init__.py
                    try:
                        from services import redis_manager
                        await redis_manager.append_monitoring_log(
                            server_id=server.id,
                            event_type='auto_restart',
                            status='info',
                            message='Auto-restart triggered after immediate crash detection during start_server'
                        )
                    except Exception as e:
                        logger.error(f"Failed to log auto-restart to Redis: {e}")
                    
                    # Wait a bit before restart
                    await asyncio.sleep(2)
                    
                    # Retry starting the server (recursive call with same callback)
                    restart_success, restart_result_msg = await self.start_server(server, progress_callback)
                    server_monitor.queue_restart_notification(
                        server,
                        success=restart_success,
                        title=f"Immediate crash auto-restart {'completed' if restart_success else 'failed'}",
                        message=restart_result_msg,
                        trigger="immediate crash detection during start_server",
                        details={
                            "Detected Issues": "\n".join(error_analysis) if error_analysis else "Process exited during initialization",
                            "Restart Status": restart_msg,
                        },
                    )
                    return restart_success, restart_result_msg
                
                # If auto-restart not available or not applicable, return error
                error_msg = "Server failed to start - process exited during initialization.\n\n"
                if error_analysis:
                    error_msg += "Detected Issues:\n" + "\n".join(error_analysis) + "\n\n"
                if not can_restart:
                    error_msg += f"Auto-restart: {restart_msg}\n\n"
                elif not auto_restart_possible:
                    error_msg += "Auto-restart: Disabled due to configuration issues detected\n\n"
                error_msg += f"Console output (last 150 lines):\n{immediate_log[:3000]}"
                server_monitor.queue_restart_notification(
                    server,
                    success=False,
                    title="Immediate crash detected",
                    message=error_msg,
                    trigger="immediate crash detection during start_server",
                    details={
                        "Detected Issues": "\n".join(error_analysis) if error_analysis else "Process exited during initialization",
                        "Restart Status": restart_msg,
                    },
                )
                return False, error_msg
            
            # Wait 1 second and check if server is still alive (detect immediate crashes)
            await asyncio.sleep(1)
            running_managers = await self._running_server_session_managers(server)
            
            if manager not in running_managers:
                # Server crashed within 1 second - get logs immediately
                log_check = f"test -f {server.game_directory}/cs2/game/csgo/console.log && tail -100 {server.game_directory}/cs2/game/csgo/console.log || echo 'No log file'"
                _, crash_log, _ = await self.execute_command(log_check, timeout=10)
                
                # Check for core dumps
                core_check = f"ls -lt {server.game_directory}/cs2/game/bin/linuxsteamrt64/core* 2>/dev/null | head -1 || echo 'No core dump'"
                _, core_output, _ = await self.execute_command(core_check)
                
                crash_info = "Server crashed within 1 second of starting.\n\n"
                crash_info += f"=== Console Log (last 100 lines) ===\n{crash_log[:3000]}\n\n"
                if 'No core dump' not in core_output:
                    crash_info += f"=== Core Dump Found ===\n{core_output}\n"
                server_monitor.queue_restart_notification(
                    server,
                    success=False,
                    title="Immediate crash detected",
                    message=crash_info,
                    trigger="post-start quick check",
                    details={
                        "Core Dump": "Detected" if 'No core dump' not in core_output else "Not detected",
                    },
                )
                return False, crash_info
            
            # Wait additional time for server to fully initialize (CS2 can take time)
            await asyncio.sleep(3)
            
            # Check if server is running - try multiple methods
            # Method 1: check the configured detached session.
            running_managers = await self._running_server_session_managers(server)
            
            if manager in running_managers:
                # Server started successfully, refresh steam.inf version cache
                try:
                    from services.steam_inf_service import steam_inf_service
                    success, version = await steam_inf_service.refresh_version_cache(server)
                    if success and version:
                        await send_progress(f"✓ Server version: {version}")
                except Exception as e:
                    # Non-critical, just log
                    await send_progress(f"Note: Could not refresh version cache: {str(e)}")
                
                return True, "Server started successfully"
            
            # Method 2: Check if CS2 process is running
            process_check = f"pgrep -f 'cs2.*-port {server.game_port}' && echo 'running' || echo 'not running'"
            proc_success, proc_stdout, _ = await self.execute_command(process_check)
            
            if 'running' in proc_stdout:
                # Server started successfully, refresh steam.inf version cache
                try:
                    from services.steam_inf_service import steam_inf_service
                    success, version = await steam_inf_service.refresh_version_cache(server)
                    if success and version:
                        await send_progress(f"✓ Server version: {version}")
                except Exception as e:
                    # Non-critical, just log
                    await send_progress(f"Note: Could not refresh version cache: {str(e)}")
                
                return True, "Server started successfully (process verified)"
            
            # Method 3: Check if port is listening
            port_check = f"netstat -tuln | grep ':{server.game_port} ' || ss -tuln | grep ':{server.game_port} ' || echo 'not listening'"
            port_success, port_stdout, _ = await self.execute_command(port_check)
            
            if 'not listening' not in port_stdout and port_stdout.strip():
                # Server started successfully, refresh steam.inf version cache
                try:
                    from services.steam_inf_service import steam_inf_service
                    success, version = await steam_inf_service.refresh_version_cache(server)
                    if success and version:
                        await send_progress(f"✓ Server version: {version}")
                except Exception as e:
                    # Non-critical, just log
                    await send_progress(f"Note: Could not refresh version cache: {str(e)}")
                
                return True, "Server started successfully (port listening)"
            
            # If no check confirms the server is running, it likely failed to start
            # Gather comprehensive diagnostic information
            diagnostics = []
            
            # Check console log with more lines
            log_check = f"test -f {server.game_directory}/cs2/game/csgo/console.log && tail -100 {server.game_directory}/cs2/game/csgo/console.log || echo 'No log file found'"
            log_success, log_output, _ = await self.execute_command(log_check, timeout=10)
            
            # Check for core dumps (indicates crash)
            core_check = f"ls -lt {server.game_directory}/cs2/game/bin/linuxsteamrt64/core* 2>/dev/null | head -1 || echo 'No core dump'"
            _, core_output, _ = await self.execute_command(core_check)
            
            # Check for common errors in the log
            error_indicators = []
            if log_output and log_output != 'No log file found':
                if 'bind:' in log_output.lower() or 'address already in use' in log_output.lower():
                    error_indicators.append("Port binding issue - port may be in use")
                if 'permission denied' in log_output.lower():
                    error_indicators.append("Permission denied - check file permissions")
                if 'map' in log_output.lower() and ('not found' in log_output.lower() or 'failed' in log_output.lower()):
                    error_indicators.append("Map loading failed - check if map exists")
                if 'library' in log_output.lower() or '.so' in log_output.lower():
                    error_indicators.append("Missing library dependency")
                if 'segmentation fault' in log_output.lower() or 'sigsegv' in log_output.lower() or 'core dumped' in log_output.lower():
                    error_indicators.append("Segmentation fault - server crashed")
                if 'failed to load' in log_output.lower():
                    error_indicators.append("Failed to load required resources")
                if 'error' in log_output.lower():
                    # Count how many errors
                    error_count = log_output.lower().count('error')
                    if error_count > 0:
                        error_indicators.append(f"Found {error_count} error(s) in console log")
            
            diagnostics.append("=== Startup Diagnostics ===")
            diagnostics.append(
                f"{manager} session: "
                f"{'Found but process may have exited' if manager in running_managers else 'NOT FOUND'}"
            )
            diagnostics.append(f"Process running: {'NO' if 'not running' in proc_stdout else 'UNKNOWN'}")
            diagnostics.append(f"Port {server.game_port} listening: {'NO' if 'not listening' in port_stdout or not port_stdout.strip() else 'UNKNOWN'}")
            
            if 'No core dump' not in core_output:
                diagnostics.append(f"Core dump: FOUND - {core_output.strip()[:200]}")
            
            if error_indicators:
                diagnostics.append("\n=== Detected Issues ===")
                for indicator in error_indicators:
                    diagnostics.append(f"⚠ {indicator}")
            
            # Check working directory and binary
            binary_check = f"test -f {server.game_directory}/cs2/game/bin/linuxsteamrt64/cs2 && echo 'exists' || echo 'missing'"
            binary_success, binary_stdout, _ = await self.execute_command(binary_check)
            if 'missing' in binary_stdout:
                diagnostics.append("\n⚠ CS2 executable not found - deployment may have failed")
            
            # Check library dependencies
            lib_check = f"cd {server.game_directory}/cs2/game/bin/linuxsteamrt64 && ldd ./cs2 2>&1 | grep 'not found' || echo 'all libraries found'"
            lib_success, lib_stdout, _ = await self.execute_command(lib_check, timeout=10)
            if 'not found' in lib_stdout:
                diagnostics.append("\n=== Missing Libraries ===")
                diagnostics.append(lib_stdout.strip())
            
            # Check if steamclient.so exists (required)
            steamclient_check = f"test -f {server.game_directory}/cs2/game/bin/linuxsteamrt64/steamclient.so && echo 'found' || echo 'MISSING steamclient.so'"
            _, steamclient_output, _ = await self.execute_command(steamclient_check)
            if 'MISSING' in steamclient_output:
                diagnostics.append("\n⚠ CRITICAL: steamclient.so not found - SteamCMD installation may be incomplete")
            
            diagnostics.append("\n=== Console Log (last 100 lines) ===")
            diagnostics.append(log_output[:3000] if log_output else 'No log output available')
            
            # Add troubleshooting suggestions
            diagnostics.append("\n=== Troubleshooting Suggestions ===")
            if error_indicators:
                diagnostics.append("1. Check the detected issues above")
            diagnostics.append("2. Verify all files were installed: Check deployment logs")
            diagnostics.append("3. Ensure ports are available: netstat -tuln | grep " + str(server.game_port))
            diagnostics.append("4. Check server permissions: ls -la " + server.game_directory + "/cs2/game/bin/linuxsteamrt64/cs2")
            
            diagnostic_message = '\n'.join(diagnostics)
            
            return False, f"Server failed to start after multiple checks.\n\n{diagnostic_message}"
        
        except Exception as e:
            return False, f"Start error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def stop_server(self, server: Server) -> Tuple[bool, str]:
        """Stop CS2 server with retry logic to ensure complete termination"""
        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        try:
            all_stopped, managers = await self._stop_server_sessions_connected(
                server,
                retries=5,
            )

            # A pane/session shutdown should terminate its children.  Retain the
            # existing exact-port cleanup as a final guard for detached CS2
            # processes, regardless of which manager owned the session.
            await self._kill_stray_cs2_processes(server)

            if not managers:
                return True, "Server is not running (no screen/tmux session found)"
            if all_stopped:
                return True, (
                    "Server stopped successfully "
                    f"({', '.join(managers)} session terminated)"
                )
            return False, "Server failed to stop all screen/tmux sessions"
        
        except Exception as e:
            return False, f"Stop error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def _send_progress_if_callback(self, progress_callback, message: str):
        """
        Shared helper to send progress updates if callback is provided
        
        Args:
            progress_callback: Optional callback for progress messages
            message: Progress message to send
        """
        if progress_callback:
            if asyncio.iscoroutinefunction(progress_callback):
                await progress_callback(message)
            else:
                progress_callback(message)
    
    async def _kill_steamcmd_processes(self, server: Server, progress_callback=None) -> None:
        """
        Kill any existing steamcmd processes for this server to prevent concurrent updates
        
        Args:
            server: Server instance
            progress_callback: Optional callback for progress messages
        """
        try:
            # Find steamcmd processes related to this server's directory
            # We look for processes that contain both "steamcmd" and the server's game directory path
            game_dir = server.game_directory
            
            # First, check if there are any steamcmd processes running for this server
            check_cmd = f"pgrep -f 'steamcmd.*{game_dir}' || true"
            success, stdout, stderr = await self.execute_command(check_cmd, timeout=10)
            
            if stdout.strip():
                pids = stdout.strip().split('\n')
                await self._send_progress_if_callback(progress_callback, f"⚠ Found {len(pids)} existing steamcmd process(es), terminating...")
                
                # Kill the processes
                for pid in pids:
                    if pid:
                        kill_cmd = f"kill -9 {pid} 2>/dev/null || true"
                        await self.execute_command(kill_cmd, timeout=5)
                
                # Give a moment for processes to terminate
                await asyncio.sleep(0.5)
                
                # Verify they're gone
                verify_cmd = f"pgrep -f 'steamcmd.*{game_dir}' || true"
                success, verify_output, _ = await self.execute_command(verify_cmd, timeout=10)
                
                if verify_output.strip():
                    await self._send_progress_if_callback(progress_callback, "⚠ Some steamcmd processes may still be running")
                else:
                    await self._send_progress_if_callback(progress_callback, "✓ All existing steamcmd processes terminated")
            
        except Exception as e:
            # Non-critical error, log but continue
            await self._send_progress_if_callback(progress_callback, f"Note: Error checking for existing steamcmd processes: {str(e)}")
    
    async def _kill_stray_cs2_processes(self, server: Server, progress_callback=None) -> None:
        """
        Kill any CS2 server processes left outside managed screen/tmux sessions
        
        This prevents duplicate processes when starting/updating/validating servers.
        Only kills CS2 processes matching this server's port to avoid affecting other servers.
        Uses word boundary matching to ensure exact port matching (e.g., port 27015 won't match 270).
        
        Args:
            server: Server instance
            progress_callback: Optional callback for progress messages
        """
        try:
            # Find CS2 processes for this server's port with exact matching
            # Use word boundary \b to prevent matching ports as substrings (e.g., 270 matching in 27015)
            # The pattern 'cs2.*-port\s+{port}\b' ensures we match "-port 27015" but not "-port 270159"
            check_cmd = f"pgrep -f 'cs2.*-port\\s+{server.game_port}\\b' || true"
            success, stdout, stderr = await self.execute_command(check_cmd, timeout=10)
            
            if stdout.strip():
                pids = stdout.strip().split('\n')
                await self._send_progress_if_callback(progress_callback, f"⚠ Found {len(pids)} stray CS2 process(es) on port {server.game_port}, terminating...")
                
                # Kill the processes
                for pid in pids:
                    if pid:
                        kill_cmd = f"kill -9 {pid} 2>/dev/null || true"
                        await self.execute_command(kill_cmd, timeout=5)
                
                # Give a moment for processes to terminate
                await asyncio.sleep(0.5)
                
                # Verify they're gone using the same precise pattern
                verify_cmd = f"pgrep -f 'cs2.*-port\\s+{server.game_port}\\b' || true"
                success, verify_output, _ = await self.execute_command(verify_cmd, timeout=10)
                
                if verify_output.strip():
                    await self._send_progress_if_callback(progress_callback, "⚠ Some CS2 processes may still be running")
                else:
                    await self._send_progress_if_callback(progress_callback, "✓ All stray CS2 processes terminated")
            
        except Exception as e:
            # Non-critical error, log but continue
            await self._send_progress_if_callback(progress_callback, f"Note: Error checking for stray CS2 processes: {str(e)}")
    
    async def _execute_steamcmd_with_retry(
        self,
        command: str,
        server: Server,
        progress_callback=None,
        timeout: int = 1800,
        max_retries: int = None,
        completion_check: Optional[Callable[[], Awaitable[bool]]] = None,
    ) -> Tuple[bool, str, str]:
        """
        Execute SteamCMD with retry and optional artifact verification.

        When ``completion_check`` is supplied, its result is authoritative. This
        handles both interrupted downloads with a zero exit code and completed
        installs where SteamCMD returns a non-zero status after self-updating.
        
        Args:
            command: SteamCMD command to execute
            server: Server instance
            progress_callback: Optional async callback for progress updates
            timeout: Command timeout in seconds
            max_retries: Maximum number of retries (default: STEAMCMD_MAX_RETRIES, must be >= 0)
            completion_check: Async check run after every exit/error. A false
                result forces a retry regardless of SteamCMD's exit status.
        
        Returns:
            Tuple[bool, str, str]: (success, stdout, stderr)
        """
        # Validate and set max_retries
        if max_retries is None:
            max_retries = self.STEAMCMD_MAX_RETRIES
        
        # Ensure max_retries is a non-negative integer
        if not isinstance(max_retries, int):
            logger.warning(f"Invalid max_retries type: {type(max_retries)}. Using default: {self.STEAMCMD_MAX_RETRIES}")
            max_retries = self.STEAMCMD_MAX_RETRIES
        elif max_retries < 0:
            logger.warning(f"Negative max_retries: {max_retries}. Using 0 (no retries)")
            max_retries = 0
        
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        async def completion_is_verified() -> Optional[bool]:
            if completion_check is None:
                return None
            try:
                return bool(await completion_check())
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning(
                    "SteamCMD completion check failed for server %s: %s",
                    server.id,
                    exc,
                )
                await send_progress(
                    f"⚠ Could not verify SteamCMD completion: {exc}"
                )
                return False

        # Attempt counter (0 = initial attempt, 1+ = retries)
        for attempt in range(max_retries + 1):
            stdout = ""
            stderr = ""
            retry_reason = ""
            retryable = False

            try:
                if attempt > 0:
                    await self._kill_steamcmd_processes(server, progress_callback)
                    delay = self.STEAMCMD_RETRY_DELAY * (2 ** (attempt - 1))
                    await send_progress(
                        f"⏳ Retry attempt {attempt}/{max_retries} - "
                        f"waiting {delay} seconds before retry..."
                    )
                    await asyncio.sleep(delay)
                    await send_progress(
                        f"🔄 Starting retry attempt {attempt}/{max_retries}..."
                    )

                success, stdout, stderr = await self.execute_command_streaming(
                    command,
                    output_callback=progress_callback,
                    timeout=timeout,
                )

                if not success:
                    output_lower = " ".join(
                        filter(None, [(stderr or "").lower(), (stdout or "").lower()])
                    )
                    retryable = any(
                        error in output_lower
                        for error in self.STEAMCMD_RETRYABLE_ERRORS
                    )
                    retry_reason = stderr or stdout or "Unknown error"
            except asyncio.TimeoutError:
                success = False
                stderr = "Command timeout"
                retry_reason = stderr
                retryable = True
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                success = False
                stderr = str(exc)
                retry_reason = f"Unexpected error: {exc}"
                retryable = True

            completion_verified = await completion_is_verified()
            if completion_verified is True:
                if not success:
                    await send_progress(
                        "✓ SteamCMD exited with an error, but the required "
                        "deployment file was verified"
                    )
                elif attempt > 0:
                    await send_progress(
                        f"✓ SteamCMD command succeeded on retry attempt "
                        f"{attempt}/{max_retries}"
                    )
                return True, stdout, stderr

            if completion_verified is False:
                retryable = True
                retry_reason = "Required deployment file is missing"
                artifact_error = (
                    "Required deployment file is missing after SteamCMD exit"
                )
                stderr = f"{stderr}; {artifact_error}" if stderr else artifact_error
            elif success:
                if attempt > 0:
                    await send_progress(
                        f"✓ SteamCMD command succeeded on retry attempt "
                        f"{attempt}/{max_retries}"
                    )
                return True, stdout, stderr

            error_snippet = retry_reason[:200] if retry_reason else "Unknown error"
            if attempt < max_retries and retryable:
                await send_progress(
                    f"⚠ SteamCMD attempt {attempt + 1}/{max_retries + 1} "
                    f"did not complete: {error_snippet}"
                )
                logger.warning(
                    "SteamCMD attempt %s failed for server %s: %s",
                    attempt + 1,
                    server.id,
                    error_snippet,
                )
                continue

            if attempt >= max_retries:
                await send_progress(
                    f"✗ SteamCMD failed after {max_retries} retry attempts"
                )
                logger.error(
                    "SteamCMD failed for server %s after %s retries",
                    server.id,
                    max_retries,
                )
            else:
                await send_progress("✗ SteamCMD failed with non-retryable error")
                logger.error(
                    "SteamCMD failed for server %s with non-retryable error",
                    server.id,
                )
            return False, stdout, stderr

        raise RuntimeError("SteamCMD retry loop ended unexpectedly")
    
    async def update_server(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """Update CS2 server using SteamCMD (without validation)"""
        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        try:
            await send_progress("Starting server update...")
            
            # Kill any existing steamcmd processes for this server
            await self._kill_steamcmd_processes(server, progress_callback)
            
            # Detect both the configured manager and a possible legacy session.
            running_managers = await self._running_server_session_managers(server)
            was_running = bool(running_managers)
            if was_running:
                manager_available, manager_message = (
                    await self._configured_session_manager_available_connected(server)
                )
                if not manager_available:
                    return False, (
                        f"Server update aborted before stopping: {manager_message}. "
                        "The existing game session was left running."
                    )
                await send_progress(
                    "Server is running in "
                    f"{', '.join(running_managers)}, stopping before update..."
                )
                all_stopped, _ = await self._stop_server_sessions_connected(
                    server,
                    progress_callback=progress_callback,
                    retries=3,
                )
                if not all_stopped:
                    return False, (
                        "Server update aborted because the existing "
                        "screen/tmux session could not be stopped"
                    )
                await send_progress("✓ Server stopped successfully")
            
            # Kill any stray CS2 processes left outside the managed session.
            await self._kill_stray_cs2_processes(server, progress_callback)
            
            # Navigate to game directory
            game_dir = server.game_directory
            steamcmd_dir = f"{game_dir}/steamcmd"
            
            # Run SteamCMD update command (without validate) with automatic retry
            update_cmd = (
                f"cd {steamcmd_dir} && "
                f"./steamcmd.sh "
                f"+force_install_dir {game_dir}/cs2 "
                f"+login anonymous "
                f"+app_update 730 "
                f"+quit"
            )
            
            # Display command preview before execution
            await send_progress("=" * 60)
            await send_progress("即将执行的命令 / Commands to be executed:")
            await send_progress("=" * 60)
            await send_progress("📝 SteamCMD Update Command:")
            await send_progress(f"   {update_cmd}")
            await send_progress("=" * 60)
            await send_progress("Updating CS2 server files via SteamCMD...")
            await send_progress(
                f"Auto-retry is enabled: up to {self.STEAMCMD_MAX_RETRIES} "
                "automatic retries on network errors"
            )
            
            # Use retry mechanism for SteamCMD update
            success, stdout, stderr = await self._execute_steamcmd_with_retry(
                update_cmd,
                server,
                progress_callback=send_progress,
                timeout=1800  # 30 minutes per attempt
            )
            
            if not success:
                # SteamCMD's launcher writes benign startup diagnostics to
                # stderr. Preserve both streams so that line doesn't hide a
                # useful success/error message from stdout.
                error_parts = []
                if stderr and stderr.strip():
                    error_parts.append(f"stderr: {stderr.strip()[-1000:]}")
                if stdout and stdout.strip():
                    error_parts.append(f"stdout: {stdout.strip()[-1000:]}")
                error_detail = "; ".join(error_parts) or "SteamCMD returned a failure status"
                await send_progress(f"CS2 server update failed: {error_detail}")
                recovery_detail = ""
                if was_running:
                    await send_progress("Attempting to restore the previously running server...")
                    recovery_success, recovery_message = await self.start_server(server, progress_callback)
                    recovery_detail = f"; recovery start {'succeeded' if recovery_success else 'failed'}: {recovery_message}"
                return False, f"SteamCMD update failed: {error_detail}{recovery_detail}"

            await send_progress("CS2 server updated successfully")
            
            # Refresh steam.inf version cache after update
            try:
                await send_progress("Refreshing version cache...")
                from services.steam_inf_service import steam_inf_service
                success, version = await steam_inf_service.refresh_version_cache(server)
                if success and version:
                    await send_progress(f"✓ Updated to version: {version}")
            except Exception as e:
                # Non-critical, just log
                await send_progress(f"Note: Could not refresh version cache: {str(e)}")
            
            # Restart server if it was running before
            if was_running:
                await send_progress("Restarting server...")
                # Actually restart the server instead of just suggesting it
                restart_success, restart_msg = await self.start_server(server, progress_callback)
                if restart_success:
                    await send_progress("✓ Server restarted successfully after update")
                else:
                    await send_progress(f"✗ Failed to restart server after update: {restart_msg}")
                    return False, f"Server files updated, but failed to restore the running server: {restart_msg}"
            
            if was_running:
                return True, "Server updated and restored to running state successfully"
            return True, "Server updated successfully; server remained stopped"
        
        except Exception as e:
            await send_progress(f"Update error: {str(e)}")
            return False, f"Update error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def validate_server(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """Update and validate CS2 server files using SteamCMD"""
        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        try:
            await send_progress("Starting server update and validation...")
            
            # Kill any existing steamcmd processes for this server
            await self._kill_steamcmd_processes(server, progress_callback)
            
            # Detect both the configured manager and a possible legacy session.
            running_managers = await self._running_server_session_managers(server)
            was_running = bool(running_managers)
            if was_running:
                manager_available, manager_message = (
                    await self._configured_session_manager_available_connected(server)
                )
                if not manager_available:
                    return False, (
                        f"Server validation aborted before stopping: {manager_message}. "
                        "The existing game session was left running."
                    )
                await send_progress(
                    "Server is running in "
                    f"{', '.join(running_managers)}, stopping before validation..."
                )
                all_stopped, _ = await self._stop_server_sessions_connected(
                    server,
                    progress_callback=progress_callback,
                    retries=3,
                )
                if not all_stopped:
                    return False, (
                        "Server validation aborted because the existing "
                        "screen/tmux session could not be stopped"
                    )
                await send_progress("✓ Server stopped successfully")
            
            # Kill any stray CS2 processes left outside the managed session.
            await self._kill_stray_cs2_processes(server, progress_callback)
            
            # Navigate to game directory
            game_dir = server.game_directory
            steamcmd_dir = f"{game_dir}/steamcmd"
            
            # Run SteamCMD update command with validation and automatic retry
            update_cmd = (
                f"cd {steamcmd_dir} && "
                f"./steamcmd.sh "
                f"+force_install_dir {game_dir}/cs2 "
                f"+login anonymous "
                f"+app_update 730 validate "
                f"+quit"
            )
            
            # Display command preview before execution
            await send_progress("=" * 60)
            await send_progress("即将执行的命令 / Commands to be executed:")
            await send_progress("=" * 60)
            await send_progress("📝 SteamCMD Update + Validate Command:")
            await send_progress(f"   {update_cmd}")
            await send_progress("=" * 60)
            await send_progress("Updating and validating CS2 server files via SteamCMD...")
            await send_progress("This may take a while as all files will be validated...")
            await send_progress(
                f"Auto-retry is enabled: up to {self.STEAMCMD_MAX_RETRIES} "
                "automatic retries on network errors"
            )
            
            # Use retry mechanism for SteamCMD validation
            success, stdout, stderr = await self._execute_steamcmd_with_retry(
                update_cmd,
                server,
                progress_callback=send_progress,
                timeout=10800  # 3h per attempt
            )
            
            if not success and stderr and "error" in stderr.lower():
                await send_progress(f"Validation completed with warnings: {stderr}")
            else:
                await send_progress("CS2 server updated and validated successfully")
            
            # Refresh steam.inf version cache after validation
            try:
                await send_progress("Refreshing version cache...")
                from services.steam_inf_service import steam_inf_service
                success, version = await steam_inf_service.refresh_version_cache(server)
                if success and version:
                    await send_progress(f"✓ Validated version: {version}")
            except Exception as e:
                # Non-critical, just log
                await send_progress(f"Note: Could not refresh version cache: {str(e)}")
            
            # Restart server if it was running before
            if was_running:
                await send_progress("Restarting server...")
                # Actually restart the server instead of just suggesting it
                restart_success, restart_msg = await self.start_server(server, progress_callback)
                if restart_success:
                    await send_progress("✓ Server restarted successfully after validation")
                else:
                    await send_progress(f"⚠ Warning: Failed to restart server after validation: {restart_msg}")
                    await send_progress("You may need to manually start the server")
            
            return True, "Server updated and validated successfully"
        
        except Exception as e:
            await send_progress(f"Validation error: {str(e)}")
            return False, f"Validation error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def get_server_status(self, server: Server) -> Tuple[bool, str]:
        """Get server status"""
        success, msg = await self.connect(server)
        if not success:
            return False, "offline"
        
        try:
            running_managers = await self._running_server_session_managers(server)
            if running_managers:
                return True, "running"
            return True, "stopped"
        
        except Exception:
            return False, "unknown"
        finally:
            await self.disconnect()
    
    async def install_metamod(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Install Metamod:Source 2.0 for CS2 server
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)

        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        try:
            await send_progress("=" * 60)
            await send_progress("Installing Metamod:Source 2.0 for CS2...")
            await send_progress("=" * 60)
            
            # Check if CS2 is installed
            cs2_dir = f"{server.game_directory}/cs2"
            check_cmd = f"test -d {cs2_dir} && echo 'exists'"
            check_success, check_stdout, _ = await self.execute_command(check_cmd)
            
            if not check_success or 'exists' not in check_stdout:
                return False, "CS2 server not found. Please deploy the server first."
            
            await send_progress("✓ CS2 server directory found")
            
            # Get latest Metamod dev build from sourcemm/GitHub.
            await send_progress("Fetching latest Metamod:Source dev build...")
            fetch_success, metamod_url = await self._fetch_latest_metamod_url(send_progress)
            
            if not fetch_success:
                return False, metamod_url
            
            metamod_url = metamod_url.strip()
            await send_progress(f"✓ Found latest version: {metamod_url}")
            
            # Create temp directory for download
            temp_dir = f"/tmp/metamod_install_{server.id}"
            await send_progress(f"Creating temporary directory: {temp_dir}")
            await self.execute_command(f"mkdir -p {temp_dir}")
            
            # Check if panel proxy mode is enabled
            if server.use_panel_proxy:
                # Panel Proxy Mode: Download to panel server first, then upload via SFTP
                await send_progress("Using panel server proxy mode for Metamod download...")
                
                panel_archive_path = None
                try:
                    # Create temp directory on panel server
                    panel_temp_dir = os.path.join(tempfile.gettempdir(), f"cs2_panel_proxy_metamod_{server.user_id}")
                    os.makedirs(panel_temp_dir, exist_ok=True)
                    
                    # Create unique subdirectory
                    download_id = str(uuid.uuid4())
                    download_dir = os.path.join(panel_temp_dir, download_id)
                    os.makedirs(download_dir, exist_ok=True)
                    
                    panel_archive_path = os.path.join(download_dir, "metamod.tar.gz")
                    
                    # Download to panel server
                    from modules.http_helper import http_helper
                    
                    last_progress = 0
                    async def download_progress_callback(bytes_downloaded, total_bytes):
                        nonlocal last_progress
                        if total_bytes > 0:
                            percent = int((bytes_downloaded / total_bytes) * 100)
                            if percent >= last_progress + 10 or percent == 100:
                                last_progress = percent
                                size_mb = bytes_downloaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Download progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    actual_download_url = self._apply_github_download_proxy(metamod_url, server.github_proxy)
                    if actual_download_url != metamod_url:
                        await send_progress("Using GitHub proxy for download")
                    
                    success_download, error = await http_helper.download_file(
                        actual_download_url,
                        panel_archive_path,
                        timeout=180,
                        progress_callback=download_progress_callback
                    )
                    
                    if not success_download:
                        raise Exception(f"Failed to download Metamod: {error}")
                    
                    # Verify file size
                    file_size = os.path.getsize(panel_archive_path)
                    if file_size < 1000:
                        raise Exception("Downloaded file is too small or empty")
                    
                    await send_progress(f"Download complete ({file_size / (1024 * 1024):.2f} MB), uploading to server...")
                    
                    # Upload to remote server via SFTP
                    remote_archive_path = f"{temp_dir}/metamod.tar.gz"
                    
                    last_upload = 0
                    async def upload_progress_callback(bytes_uploaded, total_bytes):
                        nonlocal last_upload
                        if total_bytes > 0:
                            percent = int((bytes_uploaded / total_bytes) * 100)
                            if percent >= last_upload + 10 or percent == 100:
                                last_upload = percent
                                size_mb = bytes_uploaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Upload progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    success_upload, error = await self.upload_file_with_progress(
                        panel_archive_path,
                        remote_archive_path,
                        server,
                        progress_callback=upload_progress_callback
                    )
                    
                    if not success_upload:
                        raise Exception(f"Failed to upload Metamod: {error}")
                    
                    await send_progress("✓ Metamod uploaded successfully")
                    
                finally:
                    # Clean up panel temp directory
                    if panel_archive_path:
                        await _cleanup_local_download_dir(download_dir, panel_temp_dir)
            else:
                # Original Mode: Download directly on remote server
                actual_download_url = self._apply_github_download_proxy(metamod_url, server.github_proxy)
                if actual_download_url != metamod_url:
                    await send_progress("Using GitHub proxy for download")
                
                # Download Metamod
                await send_progress(f"Downloading Metamod from {metamod_url}...")
                # Use curl as fallback if wget doesn't work well, with better error handling
                download_url_arg = shlex.quote(actual_download_url)
                download_cmd = f"curl -L -o {temp_dir}/metamod.tar.gz {download_url_arg} || wget --no-check-certificate -O {temp_dir}/metamod.tar.gz {download_url_arg}"
                success, stdout, stderr = await self.execute_command_streaming(
                    download_cmd,
                    output_callback=send_progress,
                    timeout=180
                )
                
                # Always verify the file was downloaded regardless of exit code
                check_cmd = f"test -f {temp_dir}/metamod.tar.gz && echo 'exists'"
                check_success, check_stdout, _ = await self.execute_command(check_cmd)
                
                if not check_success or 'exists' not in check_stdout:
                    await self.execute_command(f"rm -rf {temp_dir}")
                    error_detail = f"Download failed. stderr: {stderr[:500] if stderr else 'No error output'}"
                    return False, f"Metamod download failed: {error_detail}"
                
                # Check file size to ensure it's not empty
                size_cmd = f"stat -f%z {temp_dir}/metamod.tar.gz 2>/dev/null || stat -c%s {temp_dir}/metamod.tar.gz 2>/dev/null"
                size_success, size_out, _ = await self.execute_command(size_cmd)
                if size_success and size_out.strip():
                    file_size = int(size_out.strip())
                    if file_size < 1000:  # Less than 1KB is probably an error
                        await self.execute_command(f"rm -rf {temp_dir}")
                        return False, f"Downloaded file is too small ({file_size} bytes). Download may have failed."
                    await send_progress(f"✓ Downloaded {file_size} bytes")
                
                await send_progress("✓ Metamod downloaded successfully")
            
            # Extract Metamod to CS2 csgo directory (tar contains addons/metamod structure)
            csgo_dir = f"{cs2_dir}/game/csgo"
            await send_progress(f"Extracting Metamod to {csgo_dir}...")
            extract_cmd = f"tar -xzf {temp_dir}/metamod.tar.gz -C {csgo_dir}"
            success, stdout, stderr = await self.execute_command(extract_cmd, timeout=60)
            
            if not success:
                await self.execute_command(f"rm -rf {temp_dir}")
                return False, f"Metamod extraction failed: {stderr}"
            
            await send_progress("✓ Metamod extracted successfully")
            
            # Modify gameinfo.gi to add Metamod
            gameinfo_path = f"{cs2_dir}/game/csgo/gameinfo.gi"
            await send_progress("Updating gameinfo.gi...")
            
            # Check if gameinfo.gi exists
            check_cmd = f"test -f {gameinfo_path} && echo 'exists'"
            check_success, check_stdout, _ = await self.execute_command(check_cmd)
            
            if not check_success or 'exists' not in check_stdout:
                await self.execute_command(f"rm -rf {temp_dir}")
                return False, "gameinfo.gi not found. Server may not be properly installed."
            
            # Check if Metamod is already in gameinfo.gi
            check_mm_cmd = f"grep -q 'addons/metamod' {gameinfo_path} && echo 'found' || echo 'notfound'"
            check_success, check_stdout, _ = await self.execute_command(check_mm_cmd)
            
            if 'found' in check_stdout:
                await send_progress("✓ Metamod already configured in gameinfo.gi")
            else:
                # Backup gameinfo.gi
                backup_cmd = f"cp {gameinfo_path} {gameinfo_path}.backup"
                await self.execute_command(backup_cmd)
                await send_progress("✓ Created backup of gameinfo.gi")
                
                # Add Metamod to gameinfo.gi
                # We need to add "Game csgo/addons/metamod" after the Game_LowViolence line
                sed_cmd = (
                    f"sed -i '/Game_LowViolence/a\\			Game\\tcsgo/addons/metamod' {gameinfo_path}"
                )
                success, stdout, stderr = await self.execute_command(sed_cmd)
                
                if not success:
                    await send_progress("⚠ Warning: Could not automatically update gameinfo.gi")
                    await send_progress("You may need to manually add 'Game csgo/addons/metamod' to gameinfo.gi")
                else:
                    await send_progress("✓ gameinfo.gi updated successfully")
            
            # Clean up temp directory
            await self.execute_command(f"rm -rf {temp_dir}")
            
            # Verify installation
            metamod_dir = f"{cs2_dir}/game/csgo/addons/metamod"
            verify_cmd = f"test -d {metamod_dir} && echo 'installed'"
            verify_success, verify_stdout, _ = await self.execute_command(verify_cmd)
            
            if verify_success and 'installed' in verify_stdout:
                await send_progress("=" * 60)
                await send_progress("✓ Metamod:Source installed successfully!")
                await send_progress("=" * 60)
                await send_progress("NOTE: You may need to restart your server for changes to take effect.")
                await send_progress("After server updates, you may need to re-add the Metamod line to gameinfo.gi")
                return True, "Metamod:Source installed successfully"
            else:
                return False, "Metamod installation verification failed"
        
        except Exception as e:
            await send_progress(f"Installation error: {str(e)}")
            return False, f"Installation error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def install_counterstrikesharp(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Install CounterStrikeSharp for CS2 server
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        try:
            await send_progress("=" * 60)
            await send_progress("Installing CounterStrikeSharp for CS2...")
            await send_progress("=" * 60)
            
            # Check if CS2 is installed
            cs2_dir = f"{server.game_directory}/cs2"
            check_cmd = f"test -d {cs2_dir} && echo 'exists'"
            check_success, check_stdout, _ = await self.execute_command(check_cmd)
            
            if not check_success or 'exists' not in check_stdout:
                return False, "CS2 server not found. Please deploy the server first."
            
            await send_progress("✓ CS2 server directory found")
            
            # Check if Metamod is installed (required for CounterStrikeSharp)
            metamod_dir = f"{cs2_dir}/game/csgo/addons/metamod"
            check_mm_cmd = f"test -d {metamod_dir} && echo 'exists'"
            check_mm_success, check_mm_stdout, _ = await self.execute_command(check_mm_cmd)
            
            if not check_mm_success or 'exists' not in check_mm_stdout:
                await send_progress("⚠ Warning: Metamod not found. Installing Metamod first...")
                mm_success, mm_msg = await self.install_metamod(server, progress_callback)
                if not mm_success:
                    return False, f"Metamod installation failed: {mm_msg}"
            else:
                await send_progress("✓ Metamod already installed")
            
            # Get latest CounterStrikeSharp release from GitHub
            await send_progress("Fetching latest CounterStrikeSharp release from GitHub...")
            
            # GitHub API URL - DO NOT use proxy for API requests
            # Proxy services like ghfast.top only work for file downloads, not API
            api_url = "https://api.github.com/repos/roflmuffin/CounterStrikeSharp/releases/latest"
            # Note: server.github_proxy exists but is NOT used for API requests
            
            # Use GitHub API to get the latest release - specifically look for with-runtime-linux
            api_cmd = (
                f"curl -s {api_url} | "
                "grep -oP '\"browser_download_url\": \"\\K[^\"]*counterstrikesharp-with-runtime-linux[^\"]*\\.zip' | head -1"
            )
            success, css_url, stderr = await self.execute_command(api_cmd, timeout=30)
            
            if not success or not css_url.strip():
                # Fallback: try to get any linux zip and filter
                await send_progress("⚠ Trying alternative API query...")
                alt_cmd = (
                    f"curl -s {api_url} | "
                    "grep '\"browser_download_url\"' | grep 'with-runtime-linux' | grep -oP 'https://[^\"]*\\.zip' | head -1"
                )
                success, css_url, _ = await self.execute_command(alt_cmd, timeout=30)
                
                if not success or not css_url.strip():
                    # Last fallback - construct URL from version tag
                    await send_progress("⚠ Could not fetch from GitHub API, constructing fallback URL...")
                    # Get the latest tag version
                    tag_cmd = f"curl -s {api_url} | grep '\"tag_name\"' | grep -oP 'v[0-9.]+' | head -1"
                    tag_success, tag, _ = await self.execute_command(tag_cmd, timeout=30)
                    
                    if tag_success and tag.strip():
                        version = tag.strip().lstrip('v')
                        css_url = f"https://github.com/roflmuffin/CounterStrikeSharp/releases/download/{tag.strip()}/counterstrikesharp-with-runtime-linux-{version}.zip"
                        await send_progress(f"Using constructed URL for version {version}")
                    else:
                        return False, "Could not determine CounterStrikeSharp version from GitHub API"
            else:
                css_url = css_url.strip()
            
            await send_progress(f"Download URL: {css_url}")
            
            # Create temp directory for download
            temp_dir = f"/tmp/css_install_{server.id}"
            await send_progress(f"Creating temporary directory: {temp_dir}")
            await self.execute_command(f"mkdir -p {temp_dir}")
            
            # Check if panel proxy mode is enabled
            if server.use_panel_proxy:
                # Panel Proxy Mode: Download to panel server first, then upload via SFTP
                await send_progress("Using panel server proxy mode for CounterStrikeSharp download...")
                
                panel_archive_path = None
                try:
                    # Create temp directory on panel server
                    panel_temp_dir = os.path.join(tempfile.gettempdir(), f"cs2_panel_proxy_css_{server.user_id}")
                    os.makedirs(panel_temp_dir, exist_ok=True)
                    
                    # Create unique subdirectory
                    download_id = str(uuid.uuid4())
                    download_dir = os.path.join(panel_temp_dir, download_id)
                    os.makedirs(download_dir, exist_ok=True)
                    
                    panel_archive_path = os.path.join(download_dir, "counterstrikesharp.zip")
                    
                    # Download to panel server
                    from modules.http_helper import http_helper
                    
                    last_progress = 0
                    async def download_progress_callback(bytes_downloaded, total_bytes):
                        nonlocal last_progress
                        if total_bytes > 0:
                            percent = int((bytes_downloaded / total_bytes) * 100)
                            if percent >= last_progress + 10 or percent == 100:
                                last_progress = percent
                                size_mb = bytes_downloaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Download progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    success_download, error = await http_helper.download_file(
                        css_url,
                        panel_archive_path,
                        timeout=300,
                        progress_callback=download_progress_callback
                    )
                    
                    if not success_download:
                        raise Exception(f"Failed to download CounterStrikeSharp: {error}")
                    
                    # Verify file size
                    file_size = os.path.getsize(panel_archive_path)
                    if file_size < 10000:
                        raise Exception(f"Downloaded file is too small ({file_size} bytes)")
                    
                    await send_progress(f"Download complete ({file_size / (1024 * 1024):.2f} MB), uploading to server...")
                    
                    # Upload to remote server via SFTP
                    remote_archive_path = f"{temp_dir}/counterstrikesharp.zip"
                    
                    last_upload = 0
                    async def upload_progress_callback(bytes_uploaded, total_bytes):
                        nonlocal last_upload
                        if total_bytes > 0:
                            percent = int((bytes_uploaded / total_bytes) * 100)
                            if percent >= last_upload + 10 or percent == 100:
                                last_upload = percent
                                size_mb = bytes_uploaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Upload progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    success_upload, error = await self.upload_file_with_progress(
                        panel_archive_path,
                        remote_archive_path,
                        server,
                        progress_callback=upload_progress_callback
                    )
                    
                    if not success_upload:
                        raise Exception(f"Failed to upload CounterStrikeSharp: {error}")
                    
                    await send_progress("✓ CounterStrikeSharp uploaded successfully")
                    
                finally:
                    # Clean up panel temp directory
                    if panel_archive_path:
                        await _cleanup_local_download_dir(download_dir, panel_temp_dir)
            else:
                # Original Mode: Download directly on remote server (use GitHub proxy if configured)
                # Apply GitHub proxy to download URL if configured
                actual_download_url = css_url
                if server.github_proxy and server.github_proxy.strip():
                    proxy_base = server.github_proxy.strip().rstrip('/')
                    actual_download_url = f"{proxy_base}/{css_url}"
                    await send_progress("Using GitHub proxy for download")
                
                # Download CounterStrikeSharp
                await send_progress("Downloading CounterStrikeSharp...")
                # Use curl as fallback if wget doesn't work well
                download_cmd = f"curl -L -o {temp_dir}/counterstrikesharp.zip {actual_download_url} || wget --no-check-certificate -O {temp_dir}/counterstrikesharp.zip {actual_download_url}"
                success, stdout, stderr = await self.execute_command_streaming(
                    download_cmd,
                    output_callback=send_progress,
                    timeout=300  # 5 minutes for larger download
                )
                
                # Always verify the file was downloaded
                check_cmd = f"test -f {temp_dir}/counterstrikesharp.zip && echo 'exists'"
                check_success, check_stdout, _ = await self.execute_command(check_cmd)
                
                if not check_success or 'exists' not in check_stdout:
                    await self.execute_command(f"rm -rf {temp_dir}")
                    error_detail = f"Download failed. stderr: {stderr[:500] if stderr else 'No error output'}"
                    return False, f"CounterStrikeSharp download failed: {error_detail}"
                
                # Check file size
                size_cmd = f"stat -f%z {temp_dir}/counterstrikesharp.zip 2>/dev/null || stat -c%s {temp_dir}/counterstrikesharp.zip 2>/dev/null"
                size_success, size_out, _ = await self.execute_command(size_cmd)
                if size_success and size_out.strip():
                    file_size = int(size_out.strip())
                    if file_size < 10000:  # Less than 10KB is probably an error
                        await self.execute_command(f"rm -rf {temp_dir}")
                        return False, f"Downloaded file is too small ({file_size} bytes). Download may have failed."
                    await send_progress(f"✓ Downloaded {file_size} bytes")
                
                await send_progress("✓ CounterStrikeSharp downloaded successfully")
            
            # Check if unzip is available and try to install if missing
            check_unzip = "command -v unzip"
            unzip_success, _, _ = await self.execute_command(check_unzip)
            
            if not unzip_success:
                await send_progress("⚠ Warning: unzip not found. Attempting to install...")
                
                # Check package manager
                check_apt = "command -v apt-get > /dev/null && echo 'apt' || echo 'none'"
                _, pkg_mgr, _ = await self.execute_command(check_apt)
                
                if 'apt' in pkg_mgr:
                    # Try to install without sudo first
                    install_cmd = "apt-get update && apt-get install -y unzip"
                    success, stdout, stderr = await self.execute_command(install_cmd, timeout=120)
                    
                    if not success:
                        # Try with sudo if available
                        if server.sudo_password:
                            await send_progress("Trying to install unzip with sudo...")
                            install_cmd = f"echo '{server.sudo_password}' | sudo -S apt-get update && echo '{server.sudo_password}' | sudo -S apt-get install -y unzip"
                            success, stdout, stderr = await self.execute_command(install_cmd, timeout=120)
                            
                            if success:
                                await send_progress("✓ unzip installed successfully")
                            else:
                                await self.execute_command(f"rm -rf {temp_dir}")
                                return False, f"Could not install unzip. Please run: sudo apt-get install unzip\nError: {stderr[:200]}"
                        else:
                            await self.execute_command(f"rm -rf {temp_dir}")
                            return False, "unzip not found and no sudo password provided. Please install unzip: sudo apt-get install unzip"
                    else:
                        await send_progress("✓ unzip installed successfully")
                    
                    # Verify unzip is now available
                    unzip_success, _, _ = await self.execute_command(check_unzip)
                    if not unzip_success:
                        await self.execute_command(f"rm -rf {temp_dir}")
                        return False, "unzip installation completed but command still not found. Please check system PATH."
                else:
                    await self.execute_command(f"rm -rf {temp_dir}")
                    return False, "unzip not found and package manager not detected. Please install unzip manually."
            else:
                await send_progress("✓ unzip is available")
            
            # Extract CounterStrikeSharp to CS2 directory
            # The zip contains an 'addons' folder that should merge with the existing addons
            await send_progress("Extracting CounterStrikeSharp...")
            extract_cmd = f"unzip -o {temp_dir}/counterstrikesharp.zip -d {cs2_dir}/game/csgo/"
            success, stdout, stderr = await self.execute_command(extract_cmd, timeout=120)

            if not success:
                await self.execute_command(f"rm -rf {temp_dir}")
                extraction_error = stderr or stdout or "unzip returned a non-zero status"
                return False, f"CounterStrikeSharp extraction failed: {extraction_error}"
            
            # Check if extraction actually succeeded by checking the directory
            verify_extract = f"test -d {cs2_dir}/game/csgo/addons/counterstrikesharp && echo 'extracted'"
            verify_success, verify_out, _ = await self.execute_command(verify_extract)
            
            if not verify_success or 'extracted' not in verify_out:
                await self.execute_command(f"rm -rf {temp_dir}")
                return False, f"CounterStrikeSharp extraction failed: {stderr if stderr else 'Directory not created'}"
            
            await send_progress("✓ CounterStrikeSharp extracted successfully")
            
            # Clean up temp directory
            await self.execute_command(f"rm -rf {temp_dir}")
            
            # Verify installation
            css_dir = f"{cs2_dir}/game/csgo/addons/counterstrikesharp"
            verify_cmd = f"test -d {css_dir} && echo 'installed'"
            verify_success, verify_stdout, _ = await self.execute_command(verify_cmd)
            
            if verify_success and 'installed' in verify_stdout:
                await send_progress("=" * 60)
                await send_progress("✓ CounterStrikeSharp installed successfully!")
                await send_progress("=" * 60)
                await send_progress("NOTE: You need to restart your server for changes to take effect.")
                await send_progress("After restart, use 'meta list' and 'css_plugins list' to verify.")
                return True, "CounterStrikeSharp installed successfully"
            else:
                return False, "CounterStrikeSharp installation verification failed"
        
        except Exception as e:
            await send_progress(f"Installation error: {str(e)}")
            return False, f"Installation error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def update_metamod(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Update Metamod:Source to the latest version
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        await send_progress("Updating Metamod:Source to latest version...")
        await send_progress("This will reinstall Metamod with the latest version.")
        
        # Just reinstall - this will update to the latest version
        return await self.install_metamod(server, progress_callback)
    
    async def update_counterstrikesharp(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Update CounterStrikeSharp to the latest version
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        await send_progress("Updating CounterStrikeSharp to latest version...")
        await send_progress("This will reinstall CounterStrikeSharp with the latest version.")
        
        # Just reinstall - this will update to the latest version
        return await self.install_counterstrikesharp(server, progress_callback)
    
    async def install_cs2fixes(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Install CS2Fixes for CS2 server
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        try:
            await send_progress("=" * 60)
            await send_progress("Installing CS2Fixes...")
            await send_progress("=" * 60)
            
            # Check if CS2 is installed
            cs2_dir = f"{server.game_directory}/cs2"
            check_cmd = f"test -d {cs2_dir} && echo 'exists'"
            check_success, check_stdout, _ = await self.execute_command(check_cmd)
            
            if not check_success or 'exists' not in check_stdout:
                return False, "CS2 server not found. Please deploy the server first."
            
            await send_progress("✓ CS2 server directory found")
            
            # Check if Metamod is installed (required for CS2Fixes)
            metamod_dir = f"{cs2_dir}/game/csgo/addons/metamod"
            check_mm_cmd = f"test -d {metamod_dir} && echo 'exists'"
            check_mm_success, check_mm_stdout, _ = await self.execute_command(check_mm_cmd)
            
            if not check_mm_success or 'exists' not in check_mm_stdout:
                await send_progress("⚠ Warning: Metamod not found. Installing Metamod first...")
                mm_success, mm_msg = await self.install_metamod(server, progress_callback)
                if not mm_success:
                    return False, f"Metamod installation failed: {mm_msg}"
            else:
                await send_progress("✓ Metamod:Source found")
            
            # Get latest CS2Fixes version from GitHub releases
            await send_progress("Fetching latest CS2Fixes version from GitHub...")
            
            # Use helper function with fallback strategies
            pattern = '\"browser_download_url\": \"[^\"]*CS2Fixes-[^\"]*-linux\\.tar\\.gz\"'
            fetch_success, cs2fixes_url = await self._fetch_github_release_url(
                "Source2ZE/CS2Fixes", 
                pattern, 
                progress_callback,
                server.github_proxy
            )
            
            if not fetch_success:
                return False, cs2fixes_url  # cs2fixes_url contains error message
            
            await send_progress(f"✓ Found latest version: {cs2fixes_url}")
            
            # Create temp directory for download
            temp_dir = f"/tmp/cs2fixes_install_{server.id}"
            await send_progress(f"Creating temporary directory: {temp_dir}")
            await self.execute_command(f"mkdir -p {temp_dir}")
            
            # Check if panel proxy mode is enabled
            if server.use_panel_proxy:
                # Panel Proxy Mode: Download to panel server first, then upload via SFTP
                await send_progress("Using panel server proxy mode for CS2Fixes download...")
                
                panel_archive_path = None
                try:
                    # Create temp directory on panel server
                    panel_temp_dir = os.path.join(tempfile.gettempdir(), f"cs2_panel_proxy_cs2fixes_{server.user_id}")
                    os.makedirs(panel_temp_dir, exist_ok=True)
                    
                    # Create unique subdirectory
                    download_id = str(uuid.uuid4())
                    download_dir = os.path.join(panel_temp_dir, download_id)
                    os.makedirs(download_dir, exist_ok=True)
                    
                    panel_archive_path = os.path.join(download_dir, "cs2fixes.tar.gz")
                    
                    # Download to panel server
                    from modules.http_helper import http_helper
                    
                    last_progress = 0
                    async def download_progress_callback(bytes_downloaded, total_bytes):
                        nonlocal last_progress
                        if total_bytes > 0:
                            percent = int((bytes_downloaded / total_bytes) * 100)
                            if percent >= last_progress + 10 or percent == 100:
                                last_progress = percent
                                size_mb = bytes_downloaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Download progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    # Apply GitHub proxy to download URL if configured
                    actual_download_url = cs2fixes_url
                    if server.github_proxy and server.github_proxy.strip():
                        proxy_base = server.github_proxy.strip().rstrip('/')
                        actual_download_url = f"{proxy_base}/{cs2fixes_url}"
                        await send_progress("Using GitHub proxy for download")
                    
                    success_download, error = await http_helper.download_file(
                        actual_download_url,
                        panel_archive_path,
                        timeout=300,
                        progress_callback=download_progress_callback
                    )
                    
                    if not success_download:
                        raise Exception(f"Failed to download CS2Fixes: {error}")
                    
                    # Verify file size
                    file_size = os.path.getsize(panel_archive_path)
                    if file_size < self.MIN_EXPECTED_FILE_SIZE:
                        raise Exception(f"Downloaded file is too small ({file_size} bytes)")
                    
                    await send_progress(f"Download complete ({file_size / (1024 * 1024):.2f} MB), uploading to server...")
                    
                    # Upload to remote server via SFTP
                    remote_archive_path = f"{temp_dir}/cs2fixes.tar.gz"
                    
                    last_upload = 0
                    async def upload_progress_callback(bytes_uploaded, total_bytes):
                        nonlocal last_upload
                        if total_bytes > 0:
                            percent = int((bytes_uploaded / total_bytes) * 100)
                            if percent >= last_upload + 10 or percent == 100:
                                last_upload = percent
                                size_mb = bytes_uploaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Upload progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    success_upload, error = await self.upload_file_with_progress(
                        panel_archive_path,
                        remote_archive_path,
                        server,
                        progress_callback=upload_progress_callback
                    )
                    
                    if not success_upload:
                        raise Exception(f"Failed to upload CS2Fixes: {error}")
                    
                    await send_progress("✓ CS2Fixes uploaded successfully")
                    
                finally:
                    # Clean up panel temp directory
                    if panel_archive_path:
                        await _cleanup_local_download_dir(download_dir, panel_temp_dir)
            else:
                # Original Mode: Download directly on remote server (use GitHub proxy if configured)
                # Apply GitHub proxy to download URL if configured
                actual_download_url = cs2fixes_url
                if server.github_proxy and server.github_proxy.strip():
                    proxy_base = server.github_proxy.strip().rstrip('/')
                    actual_download_url = f"{proxy_base}/{cs2fixes_url}"
                    await send_progress("Using GitHub proxy for download")
                
                # Download CS2Fixes
                await send_progress(f"Downloading CS2Fixes from {cs2fixes_url}...")
                download_cmd = f"curl -L -o {temp_dir}/cs2fixes.tar.gz {actual_download_url} || wget -O {temp_dir}/cs2fixes.tar.gz {actual_download_url}"
                success, stdout, stderr = await self.execute_command_streaming(
                    download_cmd,
                    output_callback=send_progress,
                    timeout=180
                )
                
                # Verify the file was downloaded
                check_cmd = f"test -f {temp_dir}/cs2fixes.tar.gz && echo 'exists'"
                check_success, check_stdout, _ = await self.execute_command(check_cmd)
                
                if not check_success or 'exists' not in check_stdout:
                    await self.execute_command(f"rm -rf {temp_dir}")
                    error_detail = f"Download failed. stderr: {stderr[:500] if stderr else 'No error output'}"
                    return False, f"CS2Fixes download failed: {error_detail}"
                
                # Check file size to ensure it's not empty
                size_cmd = f"stat -f%z {temp_dir}/cs2fixes.tar.gz 2>/dev/null || stat -c%s {temp_dir}/cs2fixes.tar.gz 2>/dev/null"
                size_success, size_out, _ = await self.execute_command(size_cmd)
                if size_success and size_out.strip():
                    file_size = int(size_out.strip())
                    if file_size < self.MIN_EXPECTED_FILE_SIZE:
                        await self.execute_command(f"rm -rf {temp_dir}")
                        return False, f"Downloaded file is too small ({file_size} bytes). Download may have failed."
                    await send_progress(f"✓ Downloaded {file_size} bytes")
                
                await send_progress("✓ CS2Fixes downloaded successfully")
            
            # Extract CS2Fixes directly to CS2 directory
            csgo_dir = f"{cs2_dir}/game/csgo"
            await send_progress(f"Extracting and installing CS2Fixes to {csgo_dir}...")
            
            # The tar.gz contains multiple directories: addons, cfg, materials, particles, soundevents, sounds
            # Extract directly to csgo directory to install all files
            extract_cmd = f"tar -xzf {temp_dir}/cs2fixes.tar.gz -C {csgo_dir}"
            success, stdout, stderr = await self.execute_command(extract_cmd, timeout=60)
            
            if not success:
                await self.execute_command(f"rm -rf {temp_dir}")
                return False, f"CS2Fixes installation failed: {stderr}"
            
            await send_progress("✓ CS2Fixes files installed successfully")
            
            # Clean up temp directory
            await self.execute_command(f"rm -rf {temp_dir}")
            
            # Verify installation
            cs2fixes_dir = f"{csgo_dir}/addons/cs2fixes"
            verify_cmd = f"test -d {cs2fixes_dir} && echo 'installed'"
            verify_success, verify_stdout, _ = await self.execute_command(verify_cmd)
            
            if verify_success and 'installed' in verify_stdout:
                await send_progress("=" * 60)
                await send_progress("✓ CS2Fixes installed successfully!")
                await send_progress("=" * 60)
                await send_progress("NOTE: You need to restart your server for changes to take effect.")
                await send_progress("Use 'meta list' command to verify CS2Fixes is loaded.")
                return True, "CS2Fixes installed successfully"
            else:
                return False, "CS2Fixes installation verification failed"
        
        except Exception as e:
            await send_progress(f"Installation error: {str(e)}")
            return False, f"Installation error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def update_cs2fixes(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Update CS2Fixes to the latest version
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        await send_progress("Updating CS2Fixes to latest version...")
        await send_progress("This will reinstall CS2Fixes with the latest version.")
        
        # Just reinstall - this will update to the latest version
        return await self.install_cs2fixes(server, progress_callback)
    
    async def install_swiftly(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Install SwiftlyS2 framework for CS2 server
        
        SwiftlyS2 is a C#/Lua plugin framework that can run standalone (loader mode)
        without depending on Metamod updates.
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        try:
            await send_progress("=" * 60)
            await send_progress("Installing SwiftlyS2...")
            await send_progress("=" * 60)
            
            # Check if CS2 is installed
            cs2_dir = f"{server.game_directory}/cs2"
            check_cmd = f"test -d {cs2_dir} && echo 'exists'"
            check_success, check_stdout, _ = await self.execute_command(check_cmd)
            
            if not check_success or 'exists' not in check_stdout:
                return False, "CS2 server not found. Please deploy the server first."
            
            await send_progress("✓ CS2 server directory found")
            
            # Get latest SwiftlyS2 release from GitHub
            await send_progress("Fetching latest SwiftlyS2 release from GitHub...")
            
            # GitHub API URL - DO NOT use proxy for API requests
            api_url = "https://api.github.com/repos/swiftly-solution/swiftlys2/releases/latest"
            
            # Look for the linux with-runtimes zip (recommended for installation)
            api_cmd = (
                f"curl -s {api_url} | "
                "grep '\"browser_download_url\"' | grep 'linux' | grep 'with-runtimes' | grep -o 'https://[^\"]*\\.zip' | head -1"
            )
            success, swiftly_url, stderr = await self.execute_command(api_cmd, timeout=30)
            
            if not success or not swiftly_url.strip():
                # Fallback: try any linux zip
                await send_progress("⚠ Trying alternative API query...")
                alt_cmd = (
                    f"curl -s {api_url} | "
                    "grep '\"browser_download_url\"' | grep 'linux' | grep -o 'https://[^\"]*\\.zip' | head -1"
                )
                success, swiftly_url, _ = await self.execute_command(alt_cmd, timeout=30)
                
                if not success or not swiftly_url.strip():
                    return False, "Could not determine SwiftlyS2 download URL from GitHub API"
            
            swiftly_url = swiftly_url.strip()
            await send_progress(f"Download URL: {swiftly_url}")
            
            # Create temp directory for download
            temp_dir = f"/tmp/swiftly_install_{server.id}"
            await send_progress(f"Creating temporary directory: {temp_dir}")
            await self.execute_command(f"mkdir -p {temp_dir}")
            
            # Check if panel proxy mode is enabled
            if server.use_panel_proxy:
                # Panel Proxy Mode: Download to panel server first, then upload via SFTP
                await send_progress("Using panel server proxy mode for SwiftlyS2 download...")
                
                panel_archive_path = None
                try:
                    # Create temp directory on panel server
                    panel_temp_dir = os.path.join(tempfile.gettempdir(), f"cs2_panel_proxy_swiftly_{server.user_id}")
                    os.makedirs(panel_temp_dir, exist_ok=True)
                    
                    # Create unique subdirectory
                    download_id = str(uuid.uuid4())
                    download_dir = os.path.join(panel_temp_dir, download_id)
                    os.makedirs(download_dir, exist_ok=True)
                    
                    panel_archive_path = os.path.join(download_dir, "swiftly.zip")
                    
                    # Download to panel server
                    from modules.http_helper import http_helper
                    
                    last_progress = 0
                    async def download_progress_callback(bytes_downloaded, total_bytes):
                        nonlocal last_progress
                        if total_bytes > 0:
                            percent = int((bytes_downloaded / total_bytes) * 100)
                            if percent >= last_progress + 10 or percent == 100:
                                last_progress = percent
                                size_mb = bytes_downloaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Download progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    success_download, error = await http_helper.download_file(
                        swiftly_url,
                        panel_archive_path,
                        timeout=300,
                        progress_callback=download_progress_callback
                    )
                    
                    if not success_download:
                        raise Exception(f"Failed to download SwiftlyS2: {error}")
                    
                    # Verify file size
                    file_size = os.path.getsize(panel_archive_path)
                    if file_size < 10000:
                        raise Exception(f"Downloaded file is too small ({file_size} bytes)")
                    
                    await send_progress(f"Download complete ({file_size / (1024 * 1024):.2f} MB), uploading to server...")
                    
                    # Upload to remote server via SFTP
                    remote_archive_path = f"{temp_dir}/swiftly.zip"
                    
                    last_upload = 0
                    async def upload_progress_callback(bytes_uploaded, total_bytes):
                        nonlocal last_upload
                        if total_bytes > 0:
                            percent = int((bytes_uploaded / total_bytes) * 100)
                            if percent >= last_upload + 10 or percent == 100:
                                last_upload = percent
                                size_mb = bytes_uploaded / (1024 * 1024)
                                total_mb = total_bytes / (1024 * 1024)
                                await send_progress(f"Upload progress: {percent}% ({size_mb:.1f}/{total_mb:.1f} MB)")
                    
                    success_upload, error = await self.upload_file_with_progress(
                        panel_archive_path,
                        remote_archive_path,
                        server,
                        progress_callback=upload_progress_callback
                    )
                    
                    if not success_upload:
                        raise Exception(f"Failed to upload SwiftlyS2: {error}")
                    
                    await send_progress("✓ SwiftlyS2 uploaded successfully")
                    
                finally:
                    # Clean up panel temp directory
                    if panel_archive_path:
                        await _cleanup_local_download_dir(download_dir, panel_temp_dir)
            else:
                # Original Mode: Download directly on remote server (use GitHub proxy if configured)
                actual_download_url = swiftly_url
                if server.github_proxy and server.github_proxy.strip():
                    proxy_base = server.github_proxy.strip().rstrip('/')
                    actual_download_url = f"{proxy_base}/{swiftly_url}"
                    await send_progress("Using GitHub proxy for download")
                
                # Download SwiftlyS2
                await send_progress("Downloading SwiftlyS2...")
                download_cmd = f"curl -L -o {temp_dir}/swiftly.zip {actual_download_url} || wget --no-check-certificate -O {temp_dir}/swiftly.zip {actual_download_url}"
                success, stdout, stderr = await self.execute_command_streaming(
                    download_cmd,
                    output_callback=send_progress,
                    timeout=300  # 5 minutes for larger download
                )
                
                # Verify the file was downloaded
                check_cmd = f"test -f {temp_dir}/swiftly.zip && echo 'exists'"
                check_success, check_stdout, _ = await self.execute_command(check_cmd)
                
                if not check_success or 'exists' not in check_stdout:
                    await self.execute_command(f"rm -rf {temp_dir}")
                    error_detail = f"Download failed. stderr: {stderr[:500] if stderr else 'No error output'}"
                    return False, f"SwiftlyS2 download failed: {error_detail}"
                
                # Check file size
                size_cmd = f"stat -f%z {temp_dir}/swiftly.zip 2>/dev/null || stat -c%s {temp_dir}/swiftly.zip 2>/dev/null"
                size_success, size_out, _ = await self.execute_command(size_cmd)
                if size_success and size_out.strip():
                    file_size = int(size_out.strip())
                    if file_size < 10000:  # Less than 10KB is probably an error
                        await self.execute_command(f"rm -rf {temp_dir}")
                        return False, f"Downloaded file is too small ({file_size} bytes). Download may have failed."
                    await send_progress(f"✓ Downloaded {file_size} bytes")
                
                await send_progress("✓ SwiftlyS2 downloaded successfully")
            
            # Check if unzip is available and try to install if missing
            check_unzip = "command -v unzip"
            unzip_success, _, _ = await self.execute_command(check_unzip)
            
            if not unzip_success:
                await send_progress("⚠ Warning: unzip not found. Attempting to install...")
                
                # Check package manager
                check_apt = "command -v apt-get > /dev/null && echo 'apt' || echo 'none'"
                _, pkg_mgr, _ = await self.execute_command(check_apt)
                
                if 'apt' in pkg_mgr:
                    install_cmd = "apt-get update && apt-get install -y unzip"
                    success, stdout, stderr = await self.execute_command(install_cmd, timeout=120)
                    
                    if not success:
                        if server.sudo_password:
                            await send_progress("Trying to install unzip with sudo...")
                            install_cmd = f"echo '{server.sudo_password}' | sudo -S apt-get update && echo '{server.sudo_password}' | sudo -S apt-get install -y unzip"
                            success, stdout, stderr = await self.execute_command(install_cmd, timeout=120)
                            
                            if success:
                                await send_progress("✓ unzip installed successfully")
                            else:
                                await self.execute_command(f"rm -rf {temp_dir}")
                                return False, f"Could not install unzip. Please run: sudo apt-get install unzip\nError: {stderr[:200]}"
                        else:
                            await self.execute_command(f"rm -rf {temp_dir}")
                            return False, "unzip not found and no sudo password provided. Please install unzip: sudo apt-get install unzip"
                    else:
                        await send_progress("✓ unzip installed successfully")
                    
                    # Verify unzip is now available
                    unzip_success, _, _ = await self.execute_command(check_unzip)
                    if not unzip_success:
                        await self.execute_command(f"rm -rf {temp_dir}")
                        return False, "unzip installation completed but command still not found. Please check system PATH."
                else:
                    await self.execute_command(f"rm -rf {temp_dir}")
                    return False, "unzip not found and package manager not detected. Please install unzip manually."
            else:
                await send_progress("✓ unzip is available")
            
            # Extract SwiftlyS2 to CS2 directory
            # The zip contains a version-named top-level directory (e.g. swiftlys2-linux-v1.2.0-with-runtimes/addons/...)
            # We need to strip that top-level directory and copy the contents into csgo/
            csgo_dir = f"{cs2_dir}/game/csgo"
            extract_dir = f"{temp_dir}/extracted"
            await send_progress("Extracting SwiftlyS2...")
            extract_cmd = f"mkdir -p {extract_dir} && unzip -o {temp_dir}/swiftly.zip -d {extract_dir}"
            success, stdout, stderr = await self.execute_command(extract_cmd, timeout=120)
            
            if not success:
                await self.execute_command(f"rm -rf {temp_dir}")
                return False, f"SwiftlyS2 extraction failed: {stderr if stderr else 'unzip failed'}"
            
            # Find the addons directory inside the extracted content
            # maxdepth 2: addons/ may be at root or inside one top-level dir (e.g. swiftlys2-linux-vX/addons/)
            find_addons_cmd = f"find {shlex.quote(extract_dir)} -maxdepth 2 -type d -name 'addons' | head -1"
            _, addons_path, _ = await self.execute_command(find_addons_cmd)
            addons_path = addons_path.strip()
            
            if not addons_path or '/addons' not in addons_path:
                await self.execute_command(f"rm -rf {temp_dir}")
                return False, "SwiftlyS2 extraction failed: 'addons' directory not found in archive"
            
            # The parent of the addons dir contains what we need to copy into csgo_dir
            source_dir = addons_path.rsplit('/addons', 1)[0]
            await send_progress(f"Copying SwiftlyS2 files to {csgo_dir}...")
            copy_cmd = f"cp -rf {shlex.quote(source_dir)}/* {shlex.quote(csgo_dir)}/"
            success, stdout, stderr = await self.execute_command(copy_cmd, timeout=120)
            
            # Check if extraction actually succeeded by checking the directory
            verify_extract = f"test -d {csgo_dir}/addons/swiftlys2 && echo 'extracted'"
            verify_success, verify_out, _ = await self.execute_command(verify_extract)
            
            if not verify_success or 'extracted' not in verify_out:
                await self.execute_command(f"rm -rf {temp_dir}")
                return False, "SwiftlyS2 extraction failed: addons/swiftlys2 directory not created after copy"
            
            await send_progress("✓ SwiftlyS2 extracted successfully")
            
            # Clean up temp directory
            await self.execute_command(f"rm -rf {temp_dir}")
            
            # Verify installation
            swiftly_dir = f"{csgo_dir}/addons/swiftlys2"
            verify_cmd = f"test -d {swiftly_dir} && echo 'installed'"
            verify_success, verify_stdout, _ = await self.execute_command(verify_cmd)
            
            if verify_success and 'installed' in verify_stdout:
                await send_progress("=" * 60)
                await send_progress("✓ SwiftlyS2 installed successfully!")
                await send_progress("=" * 60)
                await send_progress("NOTE: You need to restart your server for changes to take effect.")
                await send_progress("SwiftlyS2 is loaded via Metamod. Make sure Metamod is installed.")
                await send_progress("After restart, use 'sw' command in console to verify installation.")
                return True, "SwiftlyS2 installed successfully"
            else:
                return False, "SwiftlyS2 installation verification failed"
        
        except Exception as e:
            await send_progress(f"Installation error: {str(e)}")
            return False, f"Installation error: {str(e)}"
        finally:
            await self.disconnect()
    
    async def update_swiftly(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Update SwiftlyS2 to the latest version
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)
        
        await send_progress("Updating SwiftlyS2 to latest version...")
        await send_progress("This will reinstall SwiftlyS2 with the latest version.")
        
        # Just reinstall - this will update to the latest version
        return await self.install_swiftly(server, progress_callback)
    
    async def backup_plugins(self, server: Server, progress_callback=None) -> Tuple[bool, str]:
        """
        Backup plugins (addons, cfg folders and gameinfo.gi file) to a timestamped tar.gz archive
        
        Creates backup at: {game_directory}/backups/YYYY-MM-DD-HHMMSS.tar.gz
        Backs up from: {game_directory}/cs2/game/csgo/
        - addons/ folder
        - cfg/ folder
        - gameinfo.gi file
        
        Args:
            server: Server instance
            progress_callback: Optional async callback for progress updates
        Returns: (success: bool, message: str)
        """
        async def send_progress(message: str):
            """Helper to send progress updates"""
            if progress_callback:
                if asyncio.iscoroutinefunction(progress_callback):
                    await progress_callback(message)
                else:
                    progress_callback(message)

        self.last_plugin_backup = None
        
        success, msg = await self.connect(server)
        if not success:
            return False, f"Connection failed: {msg}"
        
        try:
            await send_progress("=" * 60)
            await send_progress("Starting plugin backup...")
            await send_progress("=" * 60)
            
            # Use game_directory as the base for backups
            # For example: if game_directory is /home/cs2server/cs2kz, backups go to /home/cs2server/cs2kz/backups
            game_dir = server.game_directory.rstrip('/')
            
            # Check if CS2 is installed
            csgo_dir = f"{game_dir}/cs2/game/csgo"
            check_cmd = f"test -d {csgo_dir} && echo 'exists'"
            check_success, check_stdout, _ = await self.execute_command(check_cmd)
            
            if not check_success or 'exists' not in check_stdout:
                return False, "CS2 server not found. Please deploy the server first."
            
            await send_progress(f"✓ CS2 server directory found: {csgo_dir}")
            
            # Create backups directory if it doesn't exist
            backups_dir = f"{game_dir}/backups"
            await send_progress(f"Creating backups directory: {backups_dir}")
            mkdir_cmd = f"mkdir -p {shlex.quote(backups_dir)}"
            mkdir_success, _, mkdir_stderr = await self.execute_command(mkdir_cmd)
            
            if not mkdir_success:
                error_msg = mkdir_stderr.strip() if mkdir_stderr and mkdir_stderr.strip() else "Failed to create backups directory"
                await send_progress(f"✗ {error_msg}")
                return False, f"Failed to create backups directory: {error_msg}"
            
            await send_progress(f"✓ Backups directory ready: {backups_dir}")
            
            # Generate timestamp for backup filename
            # Get current time from server
            timestamp_cmd = "date '+%Y-%m-%d-%H%M%S'"
            ts_success, timestamp, _ = await self.execute_command(timestamp_cmd)
            
            if not ts_success or not timestamp.strip():
                # Fallback to local time if server time command fails
                timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
            else:
                timestamp = timestamp.strip()
            
            backup_filename = f"{timestamp}.tar.gz"
            backup_path = f"{backups_dir}/{backup_filename}"
            file_size = None
            
            await send_progress(f"Backup will be saved to: {backup_path}")
            
            # Check which items exist before backing up
            items_to_backup = []
            
            # Check addons folder
            check_addons = f"test -d {csgo_dir}/addons && echo 'exists'"
            addons_success, addons_stdout, _ = await self.execute_command(check_addons)
            if addons_success and 'exists' in addons_stdout:
                items_to_backup.append("addons")
                await send_progress("✓ Found: addons/")
            else:
                await send_progress("⚠ Warning: addons/ folder not found, skipping")
            
            # Check cfg folder
            check_cfg = f"test -d {csgo_dir}/cfg && echo 'exists'"
            cfg_success, cfg_stdout, _ = await self.execute_command(check_cfg)
            if cfg_success and 'exists' in cfg_stdout:
                items_to_backup.append("cfg")
                await send_progress("✓ Found: cfg/")
            else:
                await send_progress("⚠ Warning: cfg/ folder not found, skipping")
            
            # Check gameinfo.gi file
            check_gameinfo = f"test -f {csgo_dir}/gameinfo.gi && echo 'exists'"
            gameinfo_success, gameinfo_stdout, _ = await self.execute_command(check_gameinfo)
            if gameinfo_success and 'exists' in gameinfo_stdout:
                items_to_backup.append("gameinfo.gi")
                await send_progress("✓ Found: gameinfo.gi")
            else:
                await send_progress("⚠ Warning: gameinfo.gi file not found, skipping")
            
            if not items_to_backup:
                return False, "No items found to backup. Please ensure the server is deployed and has plugins installed."
            
            # Create backup archive with the items that exist
            await send_progress(f"Creating backup archive with {len(items_to_backup)} item(s)...")
            
            # Create tar.gz directly in the backup directory
            # This is simpler and avoids issues with /tmp/ or moving files between directories
            tar_items = " ".join(items_to_backup)
            
            await send_progress(f"Creating compressed backup: {backup_path}")
            tar_cmd = f"cd {shlex.quote(csgo_dir)} && tar -czf {shlex.quote(backup_path)} {tar_items}"
            
            # Show the actual command for debugging
            await send_progress(f"[DEBUG] Executing command: {tar_cmd}")
            
            tar_success, tar_stdout, tar_stderr = await self.execute_command_streaming(
                tar_cmd,
                output_callback=send_progress,
                timeout=600  # 10 minutes timeout for large backups
            )
            
            # Check if backup file was actually created (more reliable than exit code)
            # Tar can return non-zero exit codes for warnings (e.g., "file changed as we read it")
            # while still creating a valid backup. File existence is the true indicator of success.
            check_backup_exists = f"test -f {shlex.quote(backup_path)} && echo 'exists'"
            backup_exists_success, backup_exists_out, _ = await self.execute_command(check_backup_exists)
            backup_file_created = backup_exists_success and 'exists' in backup_exists_out
            
            await send_progress(f"[DEBUG] Backup file created: {backup_file_created}")
            await send_progress(f"[DEBUG] Tar exit code successful: {tar_success}")
            
            # Prioritize file creation over exit code - if file exists, backup succeeded
            # This handles cases where tar returns warnings but still creates valid archives
            if not backup_file_created:
                # Provide detailed error message with command and all output
                error_detail = f"Command: {tar_cmd}\n"
                error_detail += f"Exit successful: {tar_success}\n"
                error_detail += f"File created: {backup_file_created}\n"
                error_detail += f"Stderr: {tar_stderr.strip() if tar_stderr and tar_stderr.strip() else '(empty)'}\n"
                error_detail += f"Stdout: {tar_stdout.strip() if tar_stdout and tar_stdout.strip() else '(empty)'}"
                
                await send_progress("✗ Backup creation failed - file not created")
                await send_progress(f"Command: {tar_cmd}")
                await send_progress(f"Exit successful: {tar_success}")
                await send_progress(f"File created: {backup_file_created}")
                await send_progress(f"Stderr: {tar_stderr.strip() if tar_stderr and tar_stderr.strip() else '(empty)'}")
                await send_progress(f"Stdout: {tar_stdout.strip() if tar_stdout and tar_stdout.strip() else '(empty)'}")
                
                # Try to check if tar exists and what version
                check_tar_cmd = "which tar && tar --version | head -1"
                check_success, check_out, _ = await self.execute_command(check_tar_cmd)
                if check_success:
                    await send_progress(f"[INFO] Tar location and version: {check_out.strip()}")
                
                # Check backup directory permissions
                backup_dir_check = f"ls -ld {shlex.quote(backups_dir)}"
                dir_success, dir_out, _ = await self.execute_command(backup_dir_check)
                if dir_success:
                    await send_progress(f"[INFO] Backup directory permissions: {dir_out.strip()}")
                
                return False, f"Backup creation failed:\n{error_detail}"
            
            # File was created - backup succeeded even if tar returned non-zero exit code
            # This is common and usually indicates warnings rather than actual failures
            if not tar_success:
                stderr_info = f" (stderr: {tar_stderr.strip()})" if tar_stderr and tar_stderr.strip() else ""
                await send_progress(f"[WARN] Tar returned non-zero exit code but file was created successfully{stderr_info}")
            
            await send_progress("✓ Backup archive created successfully")
            
            # Get backup file size
            size_cmd = f"stat -f%z {shlex.quote(backup_path)} 2>/dev/null || stat -c%s {shlex.quote(backup_path)} 2>/dev/null"
            size_success, size_out, _ = await self.execute_command(size_cmd)
            
            if size_success and size_out.strip():
                file_size = int(size_out.strip())
                # Convert to human-readable format
                if file_size < 1024:
                    size_str = f"{file_size} bytes"
                elif file_size < 1024 * 1024:
                    size_str = f"{file_size / 1024:.2f} KB"
                elif file_size < 1024 * 1024 * 1024:
                    size_str = f"{file_size / (1024 * 1024):.2f} MB"
                else:
                    size_str = f"{file_size / (1024 * 1024 * 1024):.2f} GB"
                
                await send_progress(f"✓ Backup file size: {size_str}")
            
            await send_progress("=" * 60)
            await send_progress("✓ Plugin backup completed successfully!")
            await send_progress(f"Backup saved to: {backup_path}")
            await send_progress("=" * 60)

            self.last_plugin_backup = {
                "path": backup_path,
                "filename": backup_filename,
                "size": file_size,
                "backups_dir": backups_dir,
                "created_at": timestamp,
            }
            
            return True, f"Plugin backup completed successfully. Saved to: {backup_path}"
        
        except Exception as e:
            await send_progress(f"Backup error: {str(e)}")
            return False, f"Backup error: {str(e)}"
        finally:
            await self.disconnect()
    
    @staticmethod
    def _canonical_path_is_within(base_path: str, target_path: str) -> bool:
        base = posixpath.normpath(base_path)
        target = posixpath.normpath(target_path)
        return target == base or target.startswith(base.rstrip('/') + '/')

    async def validate_path_within_base(
        self,
        base_path: str,
        target_path: str,
        server: Server,
        allow_missing: bool = False,
        require_regular: bool = False,
    ) -> Tuple[bool, str]:
        """Validate a remote path against the canonical server directory.

        Lexical checks alone do not catch a symlink beneath ``base_path`` which
        points outside it. This resolves the nearest existing ancestor and then
        applies any missing suffix components to that canonical path.
        """
        normalized_base = posixpath.normpath(base_path)
        normalized_target = posixpath.normpath(target_path)
        if not self._canonical_path_is_within(normalized_base, normalized_target):
            return False, "Path is outside the server directory"

        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, f"Connection failed: {msg}"

        try:
            async with self.conn.start_sftp_client() as sftp:
                try:
                    base_attrs = await sftp.stat(normalized_base)
                    if base_attrs.type != asyncssh.FILEXFER_TYPE_DIRECTORY:
                        return False, "Server directory is not a directory"
                    canonical_base = posixpath.normpath(str(await sftp.realpath(normalized_base)))
                except asyncssh.SFTPError as exc:
                    return False, f"Cannot resolve server directory: {exc}"

                probe = normalized_target
                missing_parts: List[str] = []
                target_attrs = None
                while True:
                    try:
                        target_attrs = await sftp.lstat(probe)
                        canonical_existing = posixpath.normpath(str(await sftp.realpath(probe)))
                        break
                    except (asyncssh.SFTPNoSuchFile, asyncssh.SFTPNoSuchPath):
                        if not allow_missing:
                            return False, "Remote path does not exist"
                        parent = posixpath.dirname(probe)
                        if parent == probe:
                            return False, "Cannot resolve an existing parent directory"
                        component = posixpath.basename(probe)
                        if not component:
                            return False, "Remote path contains an invalid component"
                        missing_parts.append(component)
                        probe = parent
                    except asyncssh.SFTPError as exc:
                        return False, f"Cannot resolve remote path: {exc}"

                canonical_target = canonical_existing
                for component in reversed(missing_parts):
                    canonical_target = posixpath.join(canonical_target, component)
                canonical_target = posixpath.normpath(canonical_target)
                if not self._canonical_path_is_within(canonical_base, canonical_target):
                    return False, "Remote path resolves outside the server directory"

                if require_regular:
                    if missing_parts:
                        return False, "Archive file does not exist"
                    if target_attrs is None or target_attrs.type != asyncssh.FILEXFER_TYPE_REGULAR:
                        return False, "Archive path must be a regular file and cannot be a symlink"
                return True, ""
        except asyncssh.SFTPError as exc:
            return False, f"SFTP path validation failed: {exc}"
        except Exception as exc:
            return False, f"Path validation failed: {exc}"

    async def _find_remote_tool(self, candidates: Tuple[str, ...]) -> Optional[str]:
        """Return the first available hard-coded executable name."""
        for candidate in candidates:
            success, stdout, _ = await self.execute_command(
                f"command -v {shlex.quote(candidate)}",
                timeout=5,
            )
            if success and stdout.strip():
                return stdout.strip().splitlines()[0]
        return None

    @staticmethod
    def _short_command_error(stdout: str, stderr: str, limit: int = 2000) -> str:
        message = (stderr or stdout or "Remote command failed").strip()
        if len(message) > limit:
            return message[:limit] + "..."
        return message

    async def _stream_archive_listing(
        self,
        command: str,
        line_handler: Callable[[str], Optional[str]],
    ) -> Tuple[bool, str]:
        """Stream a bounded archive listing and handle each line immediately.

        Archive listings can be surprisingly large even when the compressed
        file itself is modest. ``SSHClientConnection.run()`` retains the whole
        stdout value, so use a byte stream here and cap both line length and
        entry count before any output is retained by the panel process.
        """
        if not self.conn:
            return False, "Not connected"

        process = None
        stderr_task = None
        local_error: Optional[str] = None
        process_finished = False

        async def read_stderr(stream) -> str:
            retained = bytearray()
            while True:
                chunk = await stream.read(self.ARCHIVE_LISTING_READ_BYTES)
                if not chunk:
                    break
                if isinstance(chunk, str):
                    chunk = chunk.encode("utf-8", errors="replace")
                remaining = self.ARCHIVE_LISTING_ERROR_BYTES - len(retained)
                if remaining > 0:
                    retained.extend(chunk[:remaining])
            return retained.decode("utf-8", errors="replace")

        async def consume_stdout(stream) -> Optional[str]:
            buffer = bytearray()
            line_count = 0

            async def handle(raw_line: bytes) -> Optional[str]:
                nonlocal line_count
                raw_line = raw_line.rstrip(b"\r")
                if not raw_line:
                    return None
                line_count += 1
                if line_count > self.ARCHIVE_MAX_ENTRIES:
                    return (
                        "Archive contains too many entries "
                        f"(maximum {self.ARCHIVE_MAX_ENTRIES})"
                    )
                if len(raw_line) > self.ARCHIVE_LISTING_MAX_LINE_BYTES:
                    return "Archive contains an excessively long member path"
                try:
                    line = raw_line.decode("utf-8", errors="strict")
                except UnicodeDecodeError:
                    return "Archive contains a member name which is not valid UTF-8"
                return line_handler(line)

            while True:
                chunk = await stream.read(self.ARCHIVE_LISTING_READ_BYTES)
                if not chunk:
                    break
                if isinstance(chunk, str):
                    chunk = chunk.encode("utf-8")
                buffer.extend(chunk)

                while True:
                    newline = buffer.find(b"\n")
                    if newline < 0:
                        break
                    raw_line = bytes(buffer[:newline])
                    del buffer[:newline + 1]
                    error = await handle(raw_line)
                    if error:
                        return error

                if len(buffer) > self.ARCHIVE_LISTING_MAX_LINE_BYTES:
                    return "Archive contains an excessively long member path"

            if buffer:
                return await handle(bytes(buffer))
            return None

        try:
            # Bytes mode lets us enforce limits before decoding potentially
            # attacker-controlled member names.
            process = await self.conn.create_process(command, encoding=None)
            stderr_task = asyncio.create_task(read_stderr(process.stderr))

            async def run_listing() -> Tuple[Any, Optional[str], str]:
                nonlocal process_finished
                handler_error = await consume_stdout(process.stdout)
                if handler_error:
                    process_finished = await self._stop_archive_listing_process(process)
                    return None, handler_error, ""
                result = await process.wait()
                process_finished = True
                stderr = await stderr_task
                return result, handler_error, stderr

            result, local_error, stderr = await asyncio.wait_for(
                run_listing(),
                timeout=self.ARCHIVE_INSPECT_TIMEOUT,
            )
            if local_error:
                return False, local_error
            if result.exit_status != 0:
                return False, self._short_command_error("", stderr)
            return True, ""
        except asyncio.TimeoutError:
            if process is not None:
                process_finished = await self._stop_archive_listing_process(process)
            return False, "Archive inspection timed out"
        except (asyncssh.ConnectionLost, asyncssh.DisconnectError, asyncssh.ChannelOpenError) as exc:
            return False, f"SSH connection lost while inspecting archive: {exc}"
        except Exception as exc:
            return False, f"Unable to inspect archive: {exc}"
        finally:
            if process is not None and not process_finished:
                await self._stop_archive_listing_process(process)
            if stderr_task is not None:
                if not stderr_task.done():
                    stderr_task.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await stderr_task

    @classmethod
    async def _stop_archive_listing_process(cls, process: Any) -> bool:
        """Reap a listing process, escalating from TERM to KILL quickly."""
        with contextlib.suppress(Exception):
            process.terminate()
        try:
            await asyncio.wait_for(
                process.wait(),
                timeout=cls.ARCHIVE_LISTING_STOP_TIMEOUT,
            )
            return True
        except asyncio.TimeoutError:
            with contextlib.suppress(Exception):
                process.kill()
            try:
                await asyncio.wait_for(
                    process.wait(),
                    timeout=cls.ARCHIVE_LISTING_STOP_TIMEOUT,
                )
                return True
            except Exception:
                logger.warning("Archive listing process could not be reaped after SIGKILL")
                return False
        except Exception:
            # A closed SSH channel or already-reaped child also means there is
            # no live listing process left for this connection to retain.
            return True

    @classmethod
    def _normalize_archive_member(
        cls,
        member_name: str,
        *,
        allow_backslash_separators: bool = False,
    ) -> Tuple[Optional[str], Optional[str]]:
        """Normalize one archive member, returning (path, error)."""
        if not isinstance(member_name, str):
            return None, "Archive contains a non-text member name"
        if any(ord(char) < 32 or ord(char) == 127 for char in member_name):
            return None, "Archive contains a member name with control characters"
        original_member_name = member_name
        if '\\' in member_name:
            if not allow_backslash_separators:
                return None, "Archive contains a member name with backslash separators"
            member_name = member_name.replace('\\', '/')
        if len(member_name.encode('utf-8')) > cls.ARCHIVE_MAX_MEMBER_PATH_BYTES:
            return None, "Archive contains an excessively long member path"

        # GNU tar emits the two POSIX root markers; Windows-created TARs can
        # also contain the exact equivalent '.\\'. Do not infer a root marker
        # after rewriting separators or trimming slashes: doing so would
        # silently accept absolute '/', '//' or Windows '\\' members.
        if original_member_name in ('.', './') or (
            allow_backslash_separators and original_member_name == '.\\'
        ):
            return None, None
        if member_name.startswith('/') or re.match(r'^[A-Za-z]:', member_name):
            return None, f"Archive member uses an absolute path: {original_member_name!r}"

        value = member_name.rstrip('/')
        while value.startswith('./'):
            value = value[2:]
        if value in ('', '.'):
            return None, f"Archive member contains an unsafe empty path: {original_member_name!r}"
        if value.startswith('/') or re.match(r'^[A-Za-z]:', value):
            return None, f"Archive member uses an absolute path: {original_member_name!r}"

        components = value.split('/')
        if any(component in ('', '.', '..') for component in components):
            return None, f"Archive member contains an unsafe path component: {member_name!r}"
        normalized = posixpath.normpath(value)
        if normalized == '..' or normalized.startswith('../'):
            return None, f"Archive member escapes the archive root: {member_name!r}"
        return normalized, None

    @staticmethod
    def _decode_tar_listing_name(value: str) -> Tuple[Optional[str], Optional[str]]:
        """Decode the escaped body of one GNU tar C-quoted member name."""
        decoded = bytearray()
        index = 0
        escapes = {
            '\\': ord('\\'),
            '"': ord('"'),
            'a': 7,
            'b': 8,
            'f': 12,
            'n': 10,
            'r': 13,
            't': 9,
            'v': 11,
        }
        while index < len(value):
            char = value[index]
            if char != '\\':
                decoded.extend(char.encode('utf-8'))
                index += 1
                continue

            index += 1
            if index >= len(value):
                return None, "TAR returned a malformed escaped member name"
            escaped = value[index]
            if escaped in escapes:
                decoded.append(escapes[escaped])
                index += 1
                continue
            if escaped in '01234567':
                end = index + 1
                while end < min(index + 3, len(value)) and value[end] in '01234567':
                    end += 1
                decoded_byte = int(value[index:end], 8)
                if decoded_byte > 255:
                    return None, "TAR returned an invalid octal escape in a member name"
                decoded.append(decoded_byte)
                index = end
                continue
            return None, "TAR returned an unsupported escaped member name"
        try:
            return decoded.decode('utf-8', errors='strict'), None
        except UnicodeDecodeError:
            return None, "Archive contains a member name which is not valid UTF-8"

    @classmethod
    def _parse_tar_c_verbose_listing_line(
        cls,
        line: str,
    ) -> Tuple[Optional[Tuple[str, bool]], Optional[str]]:
        """Parse GNU tar's stable numeric, UTC, C-quoted verbose format."""
        fields = line.split(None, 5)
        if len(fields) != 6 or not fields[0]:
            return None, "TAR returned a malformed member listing"

        member_type = fields[0][0]
        if member_type not in ('-', 'd'):
            # Reject links before parsing their ``name -> target`` suffix.
            return None, "Archive contains a link or special TAR member"

        quoted_name = fields[5]
        if (
            len(quoted_name) < 2
            or not quoted_name.startswith('"')
            or not quoted_name.endswith('"')
        ):
            return None, "TAR returned an unquoted or malformed member name"
        decoded_name, decode_error = cls._decode_tar_listing_name(quoted_name[1:-1])
        if decode_error:
            return None, decode_error
        if decoded_name is None:
            return None, "TAR returned a malformed member name"
        return (decoded_name, member_type == 'd'), None

    @classmethod
    def _build_archive_info(
        cls,
        archive_type: str,
        raw_members: List[Tuple[str, bool]],
    ) -> Tuple[bool, Dict[str, Any], str]:
        if len(raw_members) > cls.ARCHIVE_MAX_ENTRIES:
            return False, {}, (
                f"Archive contains too many entries (maximum {cls.ARCHIVE_MAX_ENTRIES})"
            )

        normalize_backslashes = archive_type in ('tar', 'tar.gz', 'tar.bz2', 'tar.xz')
        has_backslash_separators = False
        member_types: Dict[str, bool] = {}
        members: List[Dict[str, Any]] = []
        for raw_name, is_directory in raw_members:
            if '\\' in raw_name:
                has_backslash_separators = True
            normalized, error = cls._normalize_archive_member(
                raw_name,
                allow_backslash_separators=normalize_backslashes,
            )
            if error:
                return False, {}, error
            if normalized is None:
                continue
            if normalized in member_types:
                return False, {}, f"Archive contains a duplicate member path: {normalized}"
            member_types[normalized] = is_directory
            members.append({"path": normalized, "is_dir": is_directory})

        file_paths = {path for path, is_directory in member_types.items() if not is_directory}
        for path in member_types:
            parts = path.split('/')
            for index in range(1, len(parts)):
                ancestor = '/'.join(parts[:index])
                if ancestor in file_paths:
                    return False, {}, (
                        f"Archive member path conflicts with file ancestor: {path}"
                    )

        folders = set()
        for member in members:
            parts = member["path"].split('/')
            folder_depth = len(parts) if member["is_dir"] else len(parts) - 1
            for index in range(1, folder_depth + 1):
                folders.add('/'.join(parts[:index]))
                if len(folders) > cls.ARCHIVE_MAX_FOLDERS:
                    return False, {}, (
                        f"Archive contains too many folders (maximum {cls.ARCHIVE_MAX_FOLDERS})"
                    )

        return True, {
            "archive_type": archive_type,
            "folders": sorted(folders, key=lambda value: (value.count('/'), value.lower())),
            "entry_count": len(members),
            "members": members,
            "has_backslash_separators": has_backslash_separators,
        }, ""

    @staticmethod
    def _tar_extract_command(
        tool: str,
        archive_type: str,
        archive_path: str,
        stage_path: str,
        normalize_backslashes: bool,
    ) -> str:
        extract_flag = {
            'tar': '-xf',
            'tar.gz': '-xzf',
            'tar.bz2': '-xjf',
            'tar.xz': '-xJf',
        }[archive_type]
        transform_option = ''
        if normalize_backslashes:
            # Limit the transform to member names. Uppercase S/H explicitly
            # exclude symbolic/hard-link targets as defence in depth if an
            # archive changes between inspection and extraction.
            transform_expression = shlex.quote(r'flags=rSH;s|\\|/|g')
            transform_option = f" --transform={transform_expression}"
        return (
            f"LC_ALL=C TAR_OPTIONS= {shlex.quote(tool)} {extract_flag} {shlex.quote(archive_path)} "
            f"-C {shlex.quote(stage_path)} --no-same-owner --no-same-permissions"
            f"{transform_option}"
        )

    @staticmethod
    def _parse_7z_listing(output: str) -> Tuple[Optional[List[Tuple[str, bool]]], Optional[str]]:
        """Parse technical 7-Zip listing output after its entry separator."""
        normalized_output = output.replace('\r\n', '\n').replace('\r', '\n')
        separator_match = re.search(r'^-{10,}\s*$', normalized_output, flags=re.MULTILINE)
        if separator_match:
            normalized_output = normalized_output[separator_match.end():]

        raw_members: List[Tuple[str, bool]] = []
        for block in re.split(r'\n\s*\n', normalized_output.strip()):
            if not block.strip():
                continue
            properties: Dict[str, str] = {}
            malformed = False
            for line in block.splitlines():
                if ' = ' not in line:
                    malformed = True
                    continue
                key, value = line.split(' = ', 1)
                properties[key] = value
            path = properties.get('Path')
            if not path:
                # Archive metadata and banner blocks are not members.
                continue
            if malformed:
                return None, "7-Zip returned a malformed technical listing"

            attributes = properties.get('Attributes', '')
            lower_attributes = attributes.lower()
            if (
                properties.get('Symbolic Link')
                or properties.get('Hard Link')
                or properties.get('Anti') == '+'
                or re.search(r'(^|\s)l[rwx-]{9}', lower_attributes)
                or re.search(r'(^|\s)[bcps][rwx-]{9}', lower_attributes)
            ):
                return None, f"Archive contains an unsupported link or special entry: {path}"
            is_directory = properties.get('Folder') == '+' or attributes.startswith('D')
            raw_members.append((path, is_directory))
        return raw_members, None

    async def _inspect_archive_connected(
        self,
        archive_path: str,
        archive_type: str,
    ) -> Tuple[bool, Dict[str, Any], str]:
        """Inspect archive members using only quoted, fixed remote commands."""
        safe_archive = shlex.quote(archive_path)
        raw_members: List[Tuple[str, bool]]

        if archive_type == 'zip':
            unzip_tool = await self._find_remote_tool(('unzip',))
            if not unzip_tool:
                return False, {}, "Required archive tool is missing: install unzip"
            safe_tool = shlex.quote(unzip_tool)
            success, stdout, stderr = await self.execute_command(
                f"LC_ALL=C {safe_tool} -Z1 {safe_archive}",
                timeout=self.ARCHIVE_INSPECT_TIMEOUT,
            )
            if not success:
                return False, {}, f"Invalid ZIP archive: {self._short_command_error(stdout, stderr)}"
            raw_members = [(line, line.endswith('/')) for line in stdout.splitlines() if line]

            verbose_success, verbose_stdout, verbose_stderr = await self.execute_command(
                f"LC_ALL=C {safe_tool} -Z -l {safe_archive}",
                timeout=self.ARCHIVE_INSPECT_TIMEOUT,
            )
            if not verbose_success:
                return False, {}, (
                    "Unable to inspect ZIP member types: "
                    f"{self._short_command_error(verbose_stdout, verbose_stderr)}"
                )
            for line in verbose_stdout.splitlines():
                stripped = line.lstrip()
                if stripped and stripped[0] in 'lhbcps' and re.match(r'^[lhbcps][rwxstST-]{9}', stripped):
                    return False, {}, "Archive contains a link or special ZIP member"

        elif archive_type in ('tar', 'tar.gz', 'tar.bz2', 'tar.xz'):
            tar_tool = await self._find_remote_tool(('tar',))
            if not tar_tool:
                return False, {}, "Required archive tool is missing: install tar"
            safe_tool = shlex.quote(tar_tool)
            verbose_flag = {
                'tar': '-tvf',
                'tar.gz': '-tvzf',
                'tar.bz2': '-tvjf',
                'tar.xz': '-tvJf',
            }[archive_type]
            raw_members: List[Tuple[str, bool]] = []

            def handle_tar_line(line: str) -> Optional[str]:
                parsed_member, parse_error = self._parse_tar_c_verbose_listing_line(line)
                if parse_error:
                    return parse_error
                if parsed_member is not None:
                    raw_members.append(parsed_member)
                return None

            list_success, list_error = await self._stream_archive_listing(
                f"LC_ALL=C TAR_OPTIONS= {safe_tool} {verbose_flag} {safe_archive} "
                "--numeric-owner --full-time --utc --quoting-style=c",
                handle_tar_line,
            )
            if not list_success:
                return False, {}, f"Invalid TAR archive: {list_error}"

        elif archive_type == '7z':
            seven_zip_tool = await self._find_remote_tool(('7zz', '7z', '7za'))
            if not seven_zip_tool:
                return False, {}, "Required archive tool is missing: install 7zz, 7z, or 7za"
            success, stdout, stderr = await self.execute_command(
                f"LC_ALL=C {shlex.quote(seven_zip_tool)} l -slt -sccUTF-8 {safe_archive}",
                timeout=self.ARCHIVE_INSPECT_TIMEOUT,
            )
            if not success:
                return False, {}, f"Invalid 7z archive: {self._short_command_error(stdout, stderr)}"
            parsed_members, parse_error = self._parse_7z_listing(stdout)
            if parse_error:
                return False, {}, parse_error
            raw_members = parsed_members or []

        elif archive_type in ('gz', 'bz2'):
            tool_name = 'gzip' if archive_type == 'gz' else 'bzip2'
            tool = await self._find_remote_tool((tool_name,))
            if not tool:
                return False, {}, f"Required archive tool is missing: install {tool_name}"
            success, stdout, stderr = await self.execute_command(
                f"{shlex.quote(tool)} -t {safe_archive}",
                timeout=self.ARCHIVE_INSPECT_TIMEOUT,
            )
            if not success:
                return False, {}, (
                    f"Invalid {archive_type} archive: {self._short_command_error(stdout, stderr)}"
                )
            suffix_length = 3 if archive_type == 'gz' else 4
            raw_members = [(posixpath.basename(archive_path)[:-suffix_length], False)]
        else:
            return False, {}, "Unsupported archive format"

        return self._build_archive_info(archive_type, raw_members)

    async def inspect_archive(
        self,
        archive_path: str,
        server: Server,
    ) -> Tuple[bool, Dict[str, Any], str]:
        """Validate and list a remote archive for the file-manager UI."""
        archive_type = self.archive_type_from_path(archive_path)
        if archive_type is None:
            return False, {}, (
                "Unsupported archive format. Supported formats: .zip, .7z, .tar, .tar.gz, "
                ".tgz, .tar.bz2, .tbz2, .tar.xz, .txz, .gz, .bz2"
            )
        valid, validation_error = await self.validate_path_within_base(
            server.game_directory,
            archive_path,
            server,
            allow_missing=False,
            require_regular=True,
        )
        if not valid:
            return False, {}, validation_error
        return await self._inspect_archive_connected(archive_path, archive_type)

    async def list_directory(self, path: str, server: Server) -> Tuple[bool, List[Dict[str, Any]], str]:
        """
        List directory contents with file metadata
        
        Args:
            path: Directory path to list
            server: Server instance
        
        Returns:
            Tuple[bool, List[Dict], str]: (success, files_list, error_message)
            Each file dict contains: name, path, type, size, modified, permissions
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, [], f"Connection failed: {msg}"
        
        async def _do_list():
            async with self.conn.start_sftp_client() as sftp:
                files = []
                async for entry in sftp.scandir(path):
                    attrs = entry.attrs
                    file_info = {
                        'name': entry.filename,
                        'path': posixpath.join(path, entry.filename),
                        'type': 'directory' if attrs.type == asyncssh.FILEXFER_TYPE_DIRECTORY else 'file',
                        'size': attrs.size or 0,
                        'modified': attrs.mtime or 0,
                        'permissions': oct(attrs.permissions)[-3:] if attrs.permissions else '000',
                        'is_symlink': attrs.type == asyncssh.FILEXFER_TYPE_SYMLINK
                    }
                    files.append(file_info)
                files.sort(key=lambda x: (x['type'] != 'directory', x['name'].lower()))
                return files
        
        try:
            files = await _do_list()
            return True, files, ""
        except asyncssh.SFTPError as e:
            try:
                files = await self._handle_sftp_error_with_reconnect(e, server, "list_directory", _do_list)
                return True, files, ""
            except Exception as final_e:
                return False, [], str(final_e)
        except Exception as e:
            return False, [], f"Error listing directory: {str(e)}"
    
    async def read_file(self, file_path: str, server: Server, max_size: int = 10*1024*1024) -> Tuple[bool, str, str]:
        """
        Read file contents
        
        Args:
            file_path: Path to file
            server: Server instance
            max_size: Maximum file size to read (default 10MB)
        
        Returns:
            Tuple[bool, str, str]: (success, file_content, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, "", f"Connection failed: {msg}"
        
        async def _do_read():
            async with self.conn.start_sftp_client() as sftp:
                attrs = await sftp.stat(file_path)
                if attrs.size > max_size:
                    raise Exception(f"File too large ({attrs.size} bytes). Maximum size is {max_size} bytes.")
                async with sftp.open(file_path, 'r') as f:
                    content = await f.read()
                    try:
                        if isinstance(content, bytes):
                            text_content = content.decode('utf-8')
                        else:
                            text_content = content
                    except UnicodeDecodeError:
                        if isinstance(content, bytes):
                            text_content = content.decode('latin-1')
                        else:
                            text_content = content
                    return text_content
        
        try:
            content = await _do_read()
            return True, content, ""
        except asyncssh.SFTPError as e:
            try:
                content = await self._handle_sftp_error_with_reconnect(e, server, "read_file", _do_read)
                return True, content, ""
            except Exception as final_e:
                return False, "", str(final_e)
        except Exception as e:
            return False, "", f"Error reading file: {str(e)}"
    
    async def write_file(self, file_path: str, content: str, server: Server) -> Tuple[bool, str]:
        """
        Write content to file
        
        Args:
            file_path: Path to file
            content: Content to write (string)
            server: Server instance
        
        Returns:
            Tuple[bool, str]: (success, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, f"Connection failed: {msg}"
        
        async def _do_write():
            async with self.conn.start_sftp_client() as sftp:
                parent_dir = posixpath.dirname(file_path)
                if parent_dir:
                    try:
                        await sftp.stat(parent_dir)
                    except asyncssh.SFTPNoSuchFile:
                        await sftp.makedirs(parent_dir)
                async with sftp.open(file_path, 'w', encoding='utf-8') as f:
                    await f.write(content)
        
        try:
            await _do_write()
            return True, ""
        except asyncssh.SFTPError as e:
            try:
                await self._handle_sftp_error_with_reconnect(e, server, "write_file", _do_write)
                return True, ""
            except Exception as final_e:
                return False, str(final_e)
        except Exception as e:
            return False, f"Error writing file: {str(e)}"
    
    async def delete_path(self, path: str, server: Server) -> Tuple[bool, str]:
        """
        Delete file or directory
        
        Args:
            path: Path to delete
            server: Server instance
        
        Returns:
            Tuple[bool, str]: (success, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, f"Connection failed: {msg}"
        
        try:
            async with self.conn.start_sftp_client() as sftp:
                attrs = await sftp.stat(path)
                
                if attrs.type == asyncssh.FILEXFER_TYPE_DIRECTORY:
                    # Remove directory recursively
                    await sftp.rmtree(path)
                else:
                    # Remove file
                    await sftp.remove(path)
                
                return True, ""
        except asyncssh.SFTPError as e:
            return False, f"SFTP error: {str(e)}"
        except Exception as e:
            return False, f"Error deleting: {str(e)}"
    
    async def create_directory(self, path: str, server: Server) -> Tuple[bool, str]:
        """
        Create directory
        
        Args:
            path: Directory path to create
            server: Server instance
        
        Returns:
            Tuple[bool, str]: (success, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, f"Connection failed: {msg}"

        valid, validation_error = await self.validate_path_within_base(
            server.game_directory,
            path,
            server,
            allow_missing=True,
        )
        if not valid:
            return False, validation_error
        
        try:
            async with self.conn.start_sftp_client() as sftp:
                await sftp.makedirs(path)
                return True, ""
        except asyncssh.SFTPError as e:
            return False, f"SFTP error: {str(e)}"
        except Exception as e:
            return False, f"Error creating directory: {str(e)}"
    
    async def rename_path(self, old_path: str, new_path: str, server: Server) -> Tuple[bool, str]:
        """
        Rename or move file/directory
        
        Args:
            old_path: Current path
            new_path: New path
            server: Server instance
        
        Returns:
            Tuple[bool, str]: (success, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, f"Connection failed: {msg}"
        
        try:
            async with self.conn.start_sftp_client() as sftp:
                await sftp.rename(old_path, new_path)
                return True, ""
        except asyncssh.SFTPError as e:
            return False, f"SFTP error: {str(e)}"
        except Exception as e:
            return False, f"Error renaming: {str(e)}"
    
    async def download_url_to_file(
        self,
        url: str,
        target_path: Optional[str],
        server: Server,
        overwrite: bool = False,
        *,
        destination_path: Optional[str] = None,
        resolved_target_callback=None,
    ) -> Tuple[bool, str]:
        """Download an HTTP(S) URL to a part file and publish atomically.

        Redirects are followed manually.  Every hop is resolved on the SSH
        host, all returned addresses are required to be public, and curl is
        pinned to one validated address to prevent DNS rebinding.  When
        ``target_path`` is unknown, the final Content-Disposition (including
        RFC 5987 filename*) takes precedence over the final URL.
        """
        if target_path is not None and self.archive_type_from_path(target_path) is None:
            return False, "Target filename does not use a supported archive extension"

        if target_path is not None:
            parent_dir = posixpath.dirname(target_path)
            validation_path = target_path
        elif destination_path:
            parent_dir = posixpath.normpath(destination_path)
            validation_path = parent_dir
        else:
            return False, "Download destination path is required"

        valid, validation_error = await self.validate_path_within_base(
            server.game_directory,
            validation_path,
            server,
            allow_missing=True,
        )
        if not valid:
            return False, validation_error

        curl_tool = await self._find_remote_tool(('curl',))
        if not curl_tool:
            return False, "Required download tool is missing: install curl"
        getent_tool = await self._find_remote_tool(('getent',))
        if not getent_tool:
            return False, "Required DNS resolver is missing: install getent"

        download_id = uuid.uuid4().hex
        part_path = posixpath.join(parent_dir, f".upkk-download-{download_id}.part")
        headers_path = posixpath.join(parent_dir, f".upkk-download-{download_id}.headers")
        safe_parent = shlex.quote(parent_dir)
        safe_part = shlex.quote(part_path)
        safe_headers = shlex.quote(headers_path)

        try:
            success, stdout, stderr = await self.execute_command(
                f"mkdir -p -- {safe_parent}",
                timeout=30,
            )
            if not success:
                return False, f"Failed to create download directory: {self._short_command_error(stdout, stderr)}"

            parent_valid, parent_error = await self.validate_path_within_base(
                server.game_directory,
                parent_dir,
                server,
                allow_missing=False,
            )
            if not parent_valid:
                return False, parent_error

            if target_path is not None:
                async with self.conn.start_sftp_client() as sftp:
                    try:
                        existing_attrs = await sftp.lstat(target_path)
                    except (asyncssh.SFTPNoSuchFile, asyncssh.SFTPNoSuchPath):
                        existing_attrs = None
                    if existing_attrs is not None:
                        if not overwrite:
                            return False, "Target file already exists. Enable overwrite to replace it."
                        if existing_attrs.type != asyncssh.FILEXFER_TYPE_REGULAR:
                            return False, "Existing target must be a regular file and cannot be a symlink"

            current_url = url
            final_url = url
            raw_headers = ""
            seen_urls = set()
            for redirect_count in range(self.REMOTE_DOWNLOAD_MAX_REDIRECTS + 1):
                parsed_url, url_error = self._validate_remote_download_url(current_url)
                if parsed_url is None:
                    return False, url_error
                if current_url in seen_urls:
                    return False, "Download redirect loop detected"
                seen_urls.add(current_url)

                resolved_address, resolve_error = await self._resolve_public_download_address(
                    parsed_url.hostname,
                    getent_tool,
                )
                if resolved_address is None:
                    return False, resolve_error
                request_port = parsed_url.port or (
                    443 if parsed_url.scheme.lower() == 'https' else 80
                )
                resolve_entry = self._curl_resolve_entry(
                    parsed_url.hostname,
                    request_port,
                    resolved_address,
                )

                # Do not use --location: the response is inspected before the
                # next hop is allowed.  --noproxy ensures an HTTP proxy cannot
                # bypass the validated/pinned origin address.
                curl_command = (
                    f"umask 077; {shlex.quote(curl_tool)} --fail --silent --show-error "
                    f"--request GET --noproxy {shlex.quote('*')} "
                    f"--proto {shlex.quote('=http,https')} "
                    f"--connect-timeout 20 --max-time {self.REMOTE_DOWNLOAD_TIMEOUT} "
                    f"--retry 2 --retry-delay 2 --max-filesize {self.REMOTE_DOWNLOAD_MAX_BYTES} "
                    f"--resolve {shlex.quote(resolve_entry)} "
                    f"--dump-header {safe_headers} --output {safe_part} "
                    f"--url {shlex.quote(current_url)}"
                )
                success, stdout, stderr = await self.execute_command(
                    curl_command,
                    timeout=self.REMOTE_DOWNLOAD_TIMEOUT + 30,
                )
                if not success:
                    error_detail = self._redact_download_error(
                        self._short_command_error(stdout, stderr).replace(
                            current_url,
                            "[redacted URL]",
                        )
                    )
                    return False, f"Download failed: {error_detail}"

                async with self.conn.start_sftp_client() as sftp:
                    headers_attrs = await sftp.lstat(headers_path)
                    if headers_attrs.type != asyncssh.FILEXFER_TYPE_REGULAR:
                        return False, "Download response metadata is not a regular file"
                    if headers_attrs.size > self.REMOTE_DOWNLOAD_METADATA_MAX_BYTES:
                        return False, "Download response metadata is too large"
                    async with sftp.open(headers_path, 'rb') as header_file:
                        raw_header_bytes = await header_file.read()
                if isinstance(raw_header_bytes, str):
                    raw_headers = raw_header_bytes
                else:
                    raw_headers = raw_header_bytes.decode('iso-8859-1', errors='replace')

                redirect_url, is_redirect, redirect_error = self._redirect_url_from_response(
                    raw_headers,
                    current_url,
                )
                if redirect_error:
                    return False, redirect_error
                if is_redirect:
                    if redirect_count >= self.REMOTE_DOWNLOAD_MAX_REDIRECTS:
                        return False, "Download exceeded the redirect limit"
                    if redirect_url is None:
                        return False, "Download redirect target could not be resolved"
                    current_url = redirect_url
                    continue

                final_url = current_url
                break

            async with self.conn.start_sftp_client() as sftp:
                attrs = await sftp.lstat(part_path)
                if attrs.type != asyncssh.FILEXFER_TYPE_REGULAR or not attrs.size:
                    return False, "Downloaded archive is empty or is not a regular file"
                if attrs.size > self.REMOTE_DOWNLOAD_MAX_BYTES:
                    return False, "Downloaded archive exceeds the configured size limit"

                if target_path is None:
                    resolved_filename, filename_error = self._filename_from_download_response(
                        raw_headers,
                        final_url,
                    )
                    if resolved_filename is None:
                        return False, filename_error
                    target_path = posixpath.join(parent_dir, resolved_filename)

            if target_path is None:
                return False, "Download response filename could not be resolved"

            target_valid, target_error = await self.validate_path_within_base(
                server.game_directory,
                target_path,
                server,
                allow_missing=True,
            )
            if not target_valid:
                return False, target_error

            if resolved_target_callback is not None:
                callback_result = resolved_target_callback(target_path)
                if inspect.isawaitable(callback_result):
                    await callback_result

            async with self.conn.start_sftp_client() as sftp:
                try:
                    existing_attrs = await sftp.lstat(target_path)
                except (asyncssh.SFTPNoSuchFile, asyncssh.SFTPNoSuchPath):
                    existing_attrs = None
                if existing_attrs is not None:
                    if not overwrite:
                        return False, "Target file already exists. Enable overwrite to replace it."
                    if existing_attrs.type != asyncssh.FILEXFER_TYPE_REGULAR:
                        return False, "Existing target must be a regular file and cannot be a symlink"

            safe_target = shlex.quote(target_path)
            if overwrite:
                publish_command = f"mv -f -- {safe_part} {safe_target}"
            else:
                # A hard-link publish is an atomic no-clobber operation because
                # the part file is created in the destination directory.
                publish_command = f"ln -- {safe_part} {safe_target} && rm -- {safe_part}"
            success, stdout, stderr = await self.execute_command(publish_command, timeout=30)
            if not success:
                return False, f"Failed to publish downloaded archive: {self._short_command_error(stdout, stderr)}"
            return True, ""
        except asyncssh.SFTPError as exc:
            return False, f"SFTP error while downloading archive: {exc}"
        except Exception as exc:
            return False, f"Error downloading archive: {exc}"
        finally:
            # These paths contain only a server-controlled UUID and are quoted.
            await self.execute_command(
                f"rm -f -- {safe_part} {safe_headers}",
                timeout=10,
            )

    async def extract_archive(
        self,
        archive_path: str,
        destination_path: str,
        server: Server,
        overwrite: bool = False,
        source_folder: Optional[str] = None,
        strip_source_folder: bool = False,
    ) -> Tuple[bool, str]:
        """Inspect, stage, and merge a supported archive on the SSH host."""
        archive_type = self.archive_type_from_path(archive_path)
        if archive_type is None:
            return False, (
                "Unsupported archive format. Supported formats: .zip, .7z, .tar, .tar.gz, "
                ".tgz, .tar.bz2, .tbz2, .tar.xz, .txz, .gz, .bz2"
            )

        archive_valid, archive_error = await self.validate_path_within_base(
            server.game_directory,
            archive_path,
            server,
            allow_missing=False,
            require_regular=True,
        )
        if not archive_valid:
            return False, archive_error
        destination_valid, destination_error = await self.validate_path_within_base(
            server.game_directory,
            destination_path,
            server,
            allow_missing=True,
        )
        if not destination_valid:
            return False, destination_error

        inspect_success, archive_info, inspect_error = await self._inspect_archive_connected(
            archive_path,
            archive_type,
        )
        if not inspect_success:
            return False, inspect_error

        normalized_source = None
        if source_folder:
            normalized_source, source_error = self._normalize_archive_member(
                source_folder.rstrip('/'),
                allow_backslash_separators=archive_type in (
                    'tar', 'tar.gz', 'tar.bz2', 'tar.xz'
                ),
            )
            if source_error or normalized_source is None:
                return False, source_error or "Invalid source_folder"
            if normalized_source not in set(archive_info["folders"]):
                return False, f"Selected source folder was not found in archive: {normalized_source}"

        temp_root = posixpath.join(posixpath.normpath(server.game_directory), '.upkk-file-tasks')
        stage_path = posixpath.join(temp_root, f"extract-{uuid.uuid4().hex}")
        safe_archive = shlex.quote(archive_path)
        safe_destination = shlex.quote(destination_path)
        safe_temp_root = shlex.quote(temp_root)
        safe_stage = shlex.quote(stage_path)
        stage_created = False
        temp_root_validated = False

        try:
            temp_root_safe, temp_root_error = await self.validate_path_within_base(
                server.game_directory,
                temp_root,
                server,
                allow_missing=True,
            )
            if not temp_root_safe:
                return False, temp_root_error

            async with self.conn.start_sftp_client() as sftp:
                try:
                    existing_root_attrs = await sftp.lstat(temp_root)
                except (asyncssh.SFTPNoSuchFile, asyncssh.SFTPNoSuchPath):
                    existing_root_attrs = None
                if (
                    existing_root_attrs is not None
                    and existing_root_attrs.type != asyncssh.FILEXFER_TYPE_DIRECTORY
                ):
                    return False, "Extraction task directory cannot be a symlink"
                if existing_root_attrs is not None:
                    canonical_game_dir = posixpath.normpath(
                        str(await sftp.realpath(server.game_directory))
                    )
                    canonical_temp_root = posixpath.normpath(
                        str(await sftp.realpath(temp_root))
                    )
                    expected_temp_root = posixpath.normpath(
                        posixpath.join(canonical_game_dir, '.upkk-file-tasks')
                    )
                    if canonical_temp_root != expected_temp_root:
                        return False, "Extraction task directory resolves to an unexpected path"

            root_success, root_stdout, root_stderr = await self.execute_command(
                f"umask 077; mkdir -p -- {safe_temp_root} && chmod 700 -- {safe_temp_root}",
                timeout=30,
            )
            if not root_success:
                return False, f"Failed to create extraction task directory: {self._short_command_error(root_stdout, root_stderr)}"

            async with self.conn.start_sftp_client() as sftp:
                root_attrs = await sftp.lstat(temp_root)
                if root_attrs.type != asyncssh.FILEXFER_TYPE_DIRECTORY:
                    return False, "Extraction task directory cannot be a symlink"
                canonical_game_dir = posixpath.normpath(
                    str(await sftp.realpath(server.game_directory))
                )
                canonical_temp_root = posixpath.normpath(
                    str(await sftp.realpath(temp_root))
                )
                expected_temp_root = posixpath.normpath(
                    posixpath.join(canonical_game_dir, '.upkk-file-tasks')
                )
                if canonical_temp_root != expected_temp_root:
                    return False, "Extraction task directory resolves to an unexpected path"
            temp_root_safe, temp_root_error = await self.validate_path_within_base(
                server.game_directory,
                temp_root,
                server,
                allow_missing=False,
            )
            if not temp_root_safe:
                return False, temp_root_error
            temp_root_validated = True

            create_success, create_stdout, create_stderr = await self.execute_command(
                f"umask 077; mkdir -- {safe_stage} && chmod 700 -- {safe_stage}",
                timeout=30,
            )
            if not create_success:
                return False, f"Failed to create extraction staging directory: {self._short_command_error(create_stdout, create_stderr)}"
            stage_created = True

            async with self.conn.start_sftp_client() as sftp:
                stage_attrs = await sftp.lstat(stage_path)
                if stage_attrs.type != asyncssh.FILEXFER_TYPE_DIRECTORY:
                    return False, "Extraction staging path cannot be a symlink"

            stage_valid, stage_error = await self.validate_path_within_base(
                server.game_directory,
                stage_path,
                server,
                allow_missing=False,
            )
            if not stage_valid:
                return False, stage_error

            if archive_type == 'zip':
                tool = await self._find_remote_tool(('unzip',))
                if not tool:
                    return False, "Required archive tool is missing: install unzip"
                extract_command = (
                    f"LC_ALL=C {shlex.quote(tool)} -qq -o {safe_archive} -d {safe_stage}"
                )
            elif archive_type in ('tar', 'tar.gz', 'tar.bz2', 'tar.xz'):
                tool = await self._find_remote_tool(('tar',))
                if not tool:
                    return False, "Required archive tool is missing: install tar"
                extract_command = self._tar_extract_command(
                    tool,
                    archive_type,
                    archive_path,
                    stage_path,
                    archive_info["has_backslash_separators"],
                )
            elif archive_type == '7z':
                tool = await self._find_remote_tool(('7zz', '7z', '7za'))
                if not tool:
                    return False, "Required archive tool is missing: install 7zz, 7z, or 7za"
                output_argument = shlex.quote(f"-o{stage_path}")
                extract_command = (
                    f"LC_ALL=C {shlex.quote(tool)} x -y -aoa -bd -bso0 -bsp0 "
                    f"{output_argument} -- {safe_archive}"
                )
            elif archive_type in ('gz', 'bz2'):
                tool_name = 'gzip' if archive_type == 'gz' else 'bzip2'
                tool = await self._find_remote_tool((tool_name,))
                if not tool:
                    return False, f"Required archive tool is missing: install {tool_name}"
                suffix_length = 3 if archive_type == 'gz' else 4
                output_name = posixpath.basename(archive_path)[:-suffix_length]
                safe_output = shlex.quote(posixpath.join(stage_path, output_name))
                extract_command = f"{shlex.quote(tool)} -dc {safe_archive} > {safe_output}"
            else:
                return False, "Unsupported archive format"

            extract_success, extract_stdout, extract_stderr = await self.execute_command(
                extract_command,
                timeout=self.ARCHIVE_EXTRACT_TIMEOUT,
            )
            if not extract_success:
                return False, f"Extraction failed: {self._short_command_error(extract_stdout, extract_stderr)}"

            # Fail closed if the extractor produced any link, hardlink, device,
            # FIFO, or socket despite the preflight member listing.
            special_command = (
                f"find {safe_stage} -xdev \\( -type l -o -type b -o -type c -o "
                "-type p -o -type s \\) -print -quit"
            )
            special_success, special_stdout, special_stderr = await self.execute_command(
                special_command,
                timeout=60,
            )
            if not special_success:
                return False, f"Failed to validate extracted files: {self._short_command_error(special_stdout, special_stderr)}"
            if special_stdout.strip():
                return False, "Archive extraction produced a link or special filesystem entry"

            hardlink_success, hardlink_stdout, hardlink_stderr = await self.execute_command(
                f"find {safe_stage} -xdev -type f -links +1 -print -quit",
                timeout=60,
            )
            if not hardlink_success:
                return False, f"Failed to validate extracted hardlinks: {self._short_command_error(hardlink_stdout, hardlink_stderr)}"
            if hardlink_stdout.strip():
                return False, "Archive extraction produced a hardlinked file"

            mkdir_success, mkdir_stdout, mkdir_stderr = await self.execute_command(
                f"mkdir -p -- {safe_destination}",
                timeout=30,
            )
            if not mkdir_success:
                return False, f"Failed to create extraction destination: {self._short_command_error(mkdir_stdout, mkdir_stderr)}"
            destination_valid, destination_error = await self.validate_path_within_base(
                server.game_directory,
                destination_path,
                server,
                allow_missing=False,
            )
            if not destination_valid:
                return False, destination_error

            cp_tool = await self._find_remote_tool(('cp',))
            if not cp_tool:
                return False, "Required merge tool is missing: install coreutils (cp)"
            copy_options = (
                "-a --no-dereference --remove-destination"
                if overwrite
                else "-a --no-dereference --no-clobber"
            )
            if normalized_source:
                selected_path = posixpath.join(stage_path, normalized_source)
                safe_selected = shlex.quote(selected_path)
                selected_success, _, _ = await self.execute_command(
                    f"test -d {safe_selected} && test ! -L {safe_selected}",
                    timeout=10,
                )
                if not selected_success:
                    return False, "Selected source folder was not extracted as a directory"
                if strip_source_folder:
                    copy_source = shlex.quote(posixpath.join(selected_path, '.'))
                else:
                    # Preserve the selected directory itself (its archive
                    # parents are selection context and are not recreated).
                    copy_source = safe_selected
            else:
                copy_source = shlex.quote(posixpath.join(stage_path, '.'))

            merge_command = (
                f"{shlex.quote(cp_tool)} {copy_options} -- {copy_source} {safe_destination}/"
            )
            merge_success, merge_stdout, merge_stderr = await self.execute_command(
                merge_command,
                timeout=self.ARCHIVE_EXTRACT_TIMEOUT,
            )
            if not merge_success:
                return False, f"Failed to merge extracted files: {self._short_command_error(merge_stdout, merge_stderr)}"
            return True, ""
        except Exception as exc:
            return False, f"Error extracting archive: {exc}"
        finally:
            if stage_created and temp_root_validated:
                await self.execute_command(f"rm -rf -- {safe_stage}", timeout=60)
                await self.execute_command(f"rmdir -- {safe_temp_root} 2>/dev/null || true", timeout=10)
    
    async def upload_file(self, local_path: str, remote_path: str, server: Server) -> Tuple[bool, str]:
        """
        Upload file from local to remote
        
        Args:
            local_path: Local file path
            remote_path: Remote file path
            server: Server instance
        
        Returns:
            Tuple[bool, str]: (success, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, f"Connection failed: {msg}"
        
        try:
            async with self.conn.start_sftp_client() as sftp:
                # Ensure parent directory exists
                parent_dir = posixpath.dirname(remote_path)
                if parent_dir:
                    try:
                        await sftp.stat(parent_dir)
                    except asyncssh.SFTPNoSuchFile:
                        await sftp.makedirs(parent_dir)
                
                # Upload file
                await sftp.put(local_path, remote_path)
                return True, ""
        except asyncssh.SFTPError as e:
            return False, f"SFTP error: {str(e)}"
        except Exception as e:
            return False, f"Error uploading file: {str(e)}"
    
    async def download_file(self, remote_path: str, local_path: str, server: Server) -> Tuple[bool, str]:
        """
        Download file from remote to local
        
        Args:
            remote_path: Remote file path
            local_path: Local file path
            server: Server instance
        
        Returns:
            Tuple[bool, str]: (success, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, f"Connection failed: {msg}"
        
        try:
            async with self.conn.start_sftp_client() as sftp:
                # Ensure local parent directory exists
                os.makedirs(os.path.dirname(local_path), exist_ok=True)
                
                # Download file
                await sftp.get(remote_path, local_path)
                return True, ""
        except asyncssh.SFTPError as e:
            return False, f"SFTP error: {str(e)}"
        except Exception as e:
            return False, f"Error downloading file: {str(e)}"

    async def get_file_size(self, remote_path: str, server: Server) -> Tuple[bool, Optional[int], str]:
        """
        Get remote file size without downloading the file.

        Args:
            remote_path: Remote file path
            server: Server instance

        Returns:
            Tuple[bool, Optional[int], str]: (success, size_bytes, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, None, f"Connection failed: {msg}"

        try:
            async with self.conn.start_sftp_client() as sftp:
                attrs = await sftp.stat(remote_path)
                if attrs.type == asyncssh.FILEXFER_TYPE_DIRECTORY:
                    return False, None, "Cannot download a directory"
                return True, attrs.size or 0, ""
        except asyncssh.SFTPError as e:
            return False, None, f"SFTP error: {str(e)}"
        except Exception as e:
            return False, None, f"Error getting file size: {str(e)}"

    async def stream_file(
        self,
        remote_path: str,
        server: Server,
        chunk_size: int = DOWNLOAD_CHUNK_SIZE,
    ) -> AsyncIterator[bytes]:
        """
        Stream a remote file over SFTP in chunks.

        The caller is responsible for calling disconnect() after iteration
        completes or is cancelled.
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                raise RuntimeError(f"Connection failed: {msg}")

        async with self.conn.start_sftp_client() as sftp:
            async with sftp.open(remote_path, "rb") as remote_file:
                while True:
                    chunk = await remote_file.read(chunk_size)
                    if not chunk:
                        break
                    if isinstance(chunk, str):
                        chunk = chunk.encode()
                    yield chunk
    
    async def upload_file_with_progress(
        self, 
        local_path: str, 
        remote_path: str, 
        server: Server,
        progress_callback=None
    ) -> Tuple[bool, str]:
        """
        Upload file from local to remote with progress tracking
        
        Args:
            local_path: Local file path
            remote_path: Remote file path
            server: Server instance
            progress_callback: Optional async callback function for progress updates
                             Called with (bytes_uploaded, total_bytes)
        
        Returns:
            Tuple[bool, str]: (success, error_message)
        """
        if not self.conn:
            success, msg = await self.connect(server)
            if not success:
                return False, f"Connection failed: {msg}"
        
        try:
            # Get file size
            total_bytes = os.path.getsize(local_path)
            bytes_uploaded = 0
            
            async with self.conn.start_sftp_client() as sftp:
                # Ensure parent directory exists
                parent_dir = posixpath.dirname(remote_path)
                if parent_dir:
                    try:
                        await sftp.stat(parent_dir)
                    except asyncssh.SFTPNoSuchFile:
                        await sftp.makedirs(parent_dir)
                
                # Upload file with progress tracking
                # Read file in chunks and upload
                chunk_size = self.UPLOAD_CHUNK_SIZE
                
                async with await sftp.open(remote_path, 'wb') as remote_file:
                    async with await anyio.open_file(local_path, "rb") as local_file:
                        while True:
                            chunk = await local_file.read(chunk_size)
                            if not chunk:
                                break
                            
                            await remote_file.write(chunk)
                            bytes_uploaded += len(chunk)
                            
                            # Send progress update
                            if progress_callback:
                                if asyncio.iscoroutinefunction(progress_callback):
                                    await progress_callback(bytes_uploaded, total_bytes)
                                else:
                                    progress_callback(bytes_uploaded, total_bytes)
                
                return True, ""
        except asyncssh.SFTPError as e:
            return False, f"SFTP error: {str(e)}"
        except Exception as e:
            return False, f"Error uploading file: {str(e)}"
